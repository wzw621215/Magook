//
//  BaseTableView.m
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableView.h"

@implementation BaseTableView
- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    if (self == [super initWithFrame:frame style:style]) {
        self.tableFooterView = [UIView new];
        self.backgroundColor = kRGBColor(244, 244, 244);
    }
    return self;
}
/** 注册普通的UITableViewCell*/
- (void)registerOfClass:(Class)cellClass forCellReuseIdentifier:(NSString *)identifier {
    if (cellClass && identifier.length) {
         [self registerClass:cellClass forCellReuseIdentifier:identifier];
    }
}
/** 注册一个从xib中加载的UITableViewCell*/
- (void)registerCellNib:(Class)cellNib nibIdentifier:(NSString *)nibIdentifier; {
    if (cellNib && nibIdentifier.length) {
        UINib *nib = [UINib nibWithNibName:[cellNib description] bundle:nil];
        [self registerNib:nib forCellReuseIdentifier:nibIdentifier];
    }
}
/** 注册一个普通的UITableViewHeaderFooterView*/
- (void)registerHeaderFooterClass:(Class)headerFooterClass identifier:(NSString *)identifier {
    if (headerFooterClass && identifier.length) {
        [self registerClass:headerFooterClass forHeaderFooterViewReuseIdentifier:identifier];
    }
}
/** 注册一个从xib中加载的UITableViewHeaderFooterView*/
- (void)registerHeaderFooterNib:(Class)headerFooterNib nibIdentifier:(NSString *)nibIdentifier {
    if (headerFooterNib && nibIdentifier.length) {
        UINib *nib = [UINib nibWithNibName:[headerFooterNib description] bundle:nil];
        [self registerNib:nib forHeaderFooterViewReuseIdentifier:nibIdentifier];
    };
}

- (void)updateWithUptateBlock:(void (^)(BaseTableView *))updateBlock {
    if (updateBlock) {
        [self beginUpdates];
        updateBlock(self);
        [self endUpdates];
    }
}

- (UITableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath == nil) return nil;
    NSInteger sectionNumber = self.numberOfSections;
    NSInteger section = indexPath.section;
    NSInteger rowNumber = [self numberOfRowsInSection:section];
    if (indexPath.section + 1 > sectionNumber || indexPath.section < 0) {// section 越界
        NSLog(@"刷新section: %ld 已经越界, 总组数: %ld", indexPath.section, sectionNumber);
        return nil;
        
    } else if (indexPath.row + 1 > rowNumber || indexPath.row < 0) {// row 越界
        NSLog(@"刷新row: %ld 已经越界, 总行数: %ld 所在section: %ld", indexPath.row, rowNumber, section);
        return nil;
        
    }
    return [self cellForRowAtIndexPath:indexPath];
}
#pragma mark - 只对已经存在的cell进行刷新，没有类似于系统的 如果行不存在，默认insert操作
/** 刷新单行、动画默认*/
- (void)reloadSingleRowAtIndexPath:(NSIndexPath *)indexPath {
    [self reloadSingleRowAtIndexPath:indexPath animation:None];
}
/** 刷新单行、动画自定义*/
- (void)reloadSingleRowAtIndexPath:(NSIndexPath *)indexPath animation:(BaseTableViewRowAnimation)animation {
    if (indexPath == nil) return;
    NSInteger sectionNumber = self.numberOfSections;
    NSInteger section = indexPath.section;
    NSInteger rowNumber = [self numberOfRowsInSection:section];
    if (indexPath.section + 1 > sectionNumber || indexPath.section < 0) { // section 越界
        NSLog(@"刷新section: %ld 已经越界, 总组数: %ld", indexPath.section, sectionNumber);
    } else if (indexPath.row + 1 > rowNumber || indexPath.row < 0) { // row 越界
        NSLog(@"刷新row: %ld 已经越界, 总行数: %ld 所在section: %ld", indexPath.row, rowNumber, section);
    } else {
        [self beginUpdates];
        [self reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:(UITableViewRowAnimation)animation];
        [self endUpdates];
    }
    
    
}
/** 刷新多行、动画默认*/
- (void)reloadRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths {
    [self reloadRowsAtIndexPaths:indexPaths animation:None];
}
/** 刷新多行、动画自定义*/
- (void)reloadRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths animation:(BaseTableViewRowAnimation)animation {
    if (!indexPaths.count) return ;
    __weak __typeof(&*self)weakSelf = self;
    [indexPaths enumerateObjectsUsingBlock:^(NSIndexPath * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:[NSIndexPath class]]) {
            [weakSelf reloadSingleRowAtIndexPath:obj animation:animation];
        }
    }];
    
}
/** 刷新某个section、动画默认*/
- (void)reloadSingleSection:(NSInteger)section {
    
}
/** 刷新某个section、动画自定义*/
- (void)reloadSingleSection:(NSInteger)section animation:(BaseTableViewRowAnimation)animation {
    
}
/** 刷新多个section、动画默认*/
- (void)reloadSections:(NSArray <NSNumber *>*)sections {
    
}
/** 刷新多个section、动画自定义*/
- (void)reloadSections:(NSArray <NSNumber *>*)sections animation:(BaseTableViewRowAnimation)animation {
    
}

#pragma mark - 对cell进行删除操作
/** 删除单行、动画默认*/
- (void)deleteSingleRowAtIndexPath:(NSIndexPath *)indexPath {
    
}
/** 删除单行、动画自定义*/
- (void)deleteSingleRowAtIndexPath:(NSIndexPath *)indexPath animation:(BaseTableViewRowAnimation)animation {
    
}
/** 删除多行、动画默认*/
- (void)deleteRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths {
    
}
/** 删除多行、动画自定义*/
- (void)deleteRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths animation:(BaseTableViewRowAnimation)animation {
    
}
/** 删除某个section、动画默认*/
- (void)deleteSingleSection:(NSInteger)section {
    
}
/** 删除某个section、动画自定义*/
- (void)deleteSingleSection:(NSInteger)section animation:(BaseTableViewRowAnimation)animation {
    
}
/** 删除多个section*/
- (void)deleteSections:(NSArray <NSNumber *>*)sections {
    
}
/** 删除多个section*/
- (void)deleteSections:(NSArray <NSNumber *>*)sections animation:(BaseTableViewRowAnimation)animation {
    
}

#pragma mark - 对cell进行增加操作
/** 增加单行 动画无*/
- (void)insertSingleRowAtIndexPath:(NSIndexPath *)indexPath {
    
}
/** 增加单行，动画自定义*/
- (void)insertSingleRowAtIndexPath:(NSIndexPath *)indexPath animation:(BaseTableViewRowAnimation)animation {
    
}
/** 增加单section，动画无*/
- (void)insertSingleSection:(NSInteger)section {
    
}
/** 增加单section，动画自定义*/
- (void)insertSingleSection:(NSInteger)section animation:(BaseTableViewRowAnimation)animation {
    
}
/** 增加多行，动画无*/
- (void)insertRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths {
    
}
/** 增加多行，动画自定义*/
- (void)insertRowsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths animation:(BaseTableViewRowAnimation)animation {
    
}
/** 增加多section，动画无*/
- (void)insertSections:(NSArray <NSNumber *>*)sections {
    
}
/** 增加多section，动画自定义*/
- (void)insertSections:(NSArray <NSNumber *>*)sections animation:(BaseTableViewRowAnimation)animation {
    
}

/** 当有输入框的时候 点击tableview空白处，隐藏键盘*/
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    id view = [super hitTest:point withEvent:event];
    if (![view isKindOfClass:[UITextField class]]) {
        [self endEditing:YES];
    }
    return view;
}

@end
