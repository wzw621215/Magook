//
//  BaseRequest.h
//  NewRenWang
//
//  Created by YJ on 17/1/13.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BaseRequestReponseDelegate <NSObject>

@required
/** 如果不用block返回数据的话，这个方法必须实现*/
- (void)requestSuccessReponse:(BOOL)success response:(id)response message:(NSString *)message;

@end

/** 请求成功回调 */
typedef void(^APIDicCompletion)(id response, BOOL success, NSString *message);

@interface BaseRequest : NSObject
/** 链接*/
@property (nonatomic, copy) NSString *url;
/** 参数 */
@property (nonatomic, strong) NSDictionary *params;
/** 默认GET*/
@property (nonatomic, assign) BOOL isPost;
/** 图片数组*/
@property (nonatomic, strong) NSArray <UIImage *>*imageArray;
/** 代理 */
@property (nonatomic, weak) id <BaseRequestReponseDelegate> delegate;
/** 构造方法*/
+ (instancetype)request;
+ (instancetype)requestWithUrl:(NSString *)url;
+ (instancetype)requestWithUrl:(NSString *)url isPost:(BOOL)isPost;
+ (instancetype)requestWithUrl:(NSString *)url isPost:(BOOL)isPost delegate:(id<BaseRequestReponseDelegate>)delegate;

/** 开始请求，如果设置了代理，不需要block回调*/
- (void)sendRequest;

/** 开始请求，没有设置代理，或者设置了代理，需要block回调，block回调优先级高于代理*/
- (void)sendRequestWithCompletion:(APIDicCompletion)completion;

@end
