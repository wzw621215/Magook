//
//  BaseRequest.m
//  NewRenWang
//
//  Created by YJ on 17/1/13.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"
#import "RequestManager.h"
#import "NSString+Encrypt.h"
#import "Utils.h"
@implementation BaseRequest

#pragma mark - 构造
+ (instancetype)request {
    return [[self alloc] init];
}

+ (instancetype)requestWithUrl:(NSString *)url {
    return [self requestWithUrl:url isPost:NO];
}

+ (instancetype)requestWithUrl:(NSString *)url isPost:(BOOL)isPost {
    return [self requestWithUrl:url isPost:isPost delegate:nil];
}

+ (instancetype)requestWithUrl:(NSString *)url isPost:(BOOL)isPost delegate:(id <BaseRequestReponseDelegate>)delegate {
    BaseRequest *request = [self request];
    request.url = url;
    request.isPost = isPost;
    request.delegate = delegate;
    return request;
}

#pragma mark - 发送请求
- (void)sendRequest {
    [self sendRequestWithCompletion:nil];
}

- (void)sendRequestWithCompletion:(APIDicCompletion)completion {
    // 链接
    NSString *urlStr = [Utils getNRServerAddress];
    urlStr = [urlStr stringByAppendingString:self.url];
    if (urlStr.length == 0) return ;
    
    if (self.isPost) {
        if (self.params.count == 0) return;
        if (self.imageArray.count == 0) {
            // 开始请求
            [RequestManager POST:[urlStr noWhiteSpaceString] parameters:self.params responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
                
                // 处理数据
                [self handleResponse:responseObject completion:completion];
            } failure:^(NSError *error) {
                // 数据请求失败，暂时不做处理
            }];
        }
    } else {
        [RequestManager GET:[urlStr noWhiteSpaceString] parameters:self.params responseSeializerType:ResponseSeializerTypeJSON success:^(id responseObject) {
            
            [self handleResponse:responseObject completion:completion];
        } failure:^(NSError *error) {
            // 数据请求失败，暂时不做处理
        }];
    }
    
    // 上传图片
    if (self.imageArray.count) {
        [RequestManager POST:[urlStr noWhiteSpaceString] parameters:self.params responseSeializerType:ResponseSeializerTypeJSON constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            NSInteger imgCount = 0;
            for (UIImage *image in self.imageArray) {
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss:SSS";
                NSString *fileName = [NSString stringWithFormat:@"%@%@.png",[formatter stringFromDate:[NSDate date]],@(imgCount)];
                //                [NSString stringWithFormat:@"uploadFile%@",@(imgCount)]
                [formData appendPartWithFileData:UIImagePNGRepresentation(image) name:@"file" fileName:fileName mimeType:@"image/png"];
                imgCount++;
            }
        } success:^(id responseObject) {
            // 处理数据
            [self handleResponse:responseObject completion:completion];
        } failure:^(NSError *error) {
            // 数据请求失败，暂时不做处理
        }];
    }
}

- (void)handleResponse:(id)responseObject completion:(APIDicCompletion)completion {
    // 接口约定，如果message为retry即重试
    if ([responseObject[@"msg"] isEqualToString:@"retry"]) {
        [self sendRequestWithCompletion:completion];
        return  ;
    }
    
    // 数据请求成功回调
    BOOL success = [responseObject[@"code"] isEqualToNumber:[NSNumber numberWithInteger:100]];
    if (completion) {
        completion(responseObject[@"data"], success, responseObject[@"msg"]);
    } else if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(requestSuccessReponse:response:message:)]) {
            [self.delegate requestSuccessReponse:success response:responseObject[@"data"] message:responseObject[@"msg"]];
        }
    }
}

// 设置链接
- (void)seturl:(NSString *)url {
    if (url.length == 0 || [url isKindOfClass:[NSNull class]]) {
        return ;
    }
    _url = url;
}
@end
