//
//  BaseNavigationController.h
//  PingXingWeiKe
//
//  Created by j on 16/11/7.
//  Copyright © 2016年 pingxingshijiie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
