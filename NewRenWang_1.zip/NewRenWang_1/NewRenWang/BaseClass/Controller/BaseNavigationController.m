//
//  BaseNavigationController.m
//  PingXingWeiKe
//
//  Created by j on 16/11/7.
//  Copyright © 2016年 pingxingshijiie. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

+ (void)initialize {
     // 设置为不透明
    [[UINavigationBar appearance] setTranslucent:NO];
    // 设置导航栏背景颜色
    [UINavigationBar appearance].barTintColor = [UIColor blackColor];
    NSMutableDictionary * color = [NSMutableDictionary dictionary];
    color[NSFontAttributeName] = [UIFont systemFontOfSize:17];
    color[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [[UINavigationBar appearance] setTitleTextAttributes:color];
    [[UINavigationBar appearance] setShadowImage:[UIImage new]];
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageWithColor:[StaticKeyProfileManager navigationBackgroundColor]] forBarMetrics:UIBarMetricsDefault];

    
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    /**
     *  如果在堆栈控制器数量大于0 加返回按钮
     */
    if (self.viewControllers.count > 0) {
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
        [btn setImage:[UIImage imageNamed:@"fanhui"] forState:UIControlStateNormal];
        btn.imageEdgeInsets = UIEdgeInsetsMake(0, -30, 0, 0);
        UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
        [btn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        viewController.navigationItem.leftBarButtonItem = leftItem;
        viewController.hidesBottomBarWhenPushed = YES;
    }
      __weak typeof (viewController)Weakself = viewController;
    self.interactivePopGestureRecognizer.delegate = (id)Weakself;
    [super pushViewController:viewController animated:animated];
    
}

- (void)back{
    if ((self.presentedViewController || self.presentingViewController) && self.viewControllers.count == 1){
        [self dismissViewControllerAnimated:YES completion:nil];
        
    } else {
        [self popViewControllerAnimated:YES];
    }
        
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.navigationBar.layer.shadowColor = [UIColor blackColor].CGColor;
//    self.navigationBar.layer.shadowOffset = CGSizeMake(0, 1);
//    self.navigationBar.layer.shadowOpacity = 0.2;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
