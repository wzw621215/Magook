//
//  BaseTableViewController.m
//  NewRenWang
//
//  Created by JopYin on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"
#import <objc/runtime.h>
#import "Utils.h"
#import "BaseTableViewHeaderFooterView.h"
const char BaseTableVcNavRightItemHandleKey;
const char BaseTableVcNavLeftItemHandleKey;
@interface BaseTableViewController ()
@property (nonatomic, copy) TableVcCellSelectedHandle handle;
@end

@implementation BaseTableViewController

@synthesize needCellSepLine = _needCellSepLine;
@synthesize sepLineColor = _sepLineColor;
@synthesize navItemTitle = _navItemTitle;
@synthesize navRightItem = _navRightItem;
@synthesize navLeftItem = _navLeftItem;
@synthesize hiddenStatusBar = _hiddenStatusBar;
@synthesize barStyle = _barStyle;

- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

/**
 *  加载tableview
 */
- (BaseTableView *)tableView {
    if(!_tableView){
        BaseTableView *tab = [[BaseTableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        [self.view addSubview:tab];
        _tableView = tab;
        tab.dataSource = self;
        tab.delegate = self;
        
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }

}

- (void)showLoading {

}

- (void)hiddenLoading {

}

- (void)showTitle:(NSString *)title after:(NSTimeInterval)after {
//    [FDHUD showTitle:title];
//    [FDHUD hideHUDAfterTimeout:after];
}

/** 添加空界面文字*/
- (void)addEmptyPageWithText:(NSString *)text {
   
}

/** 设置导航栏右边的item*/
- (void)setUpNavRightItemTitle:(NSString *)itemTitle handle:(void(^)(NSString *rightItemTitle))handle {
    [self setUpNavItemTitle:itemTitle handle:handle leftFlag:NO];
}

/** 设置导航栏左边的item*/
- (void)setUpNavLeftItemTitle:(NSString *)itemTitle handle:(void(^)(NSString *leftItemTitle))handle {
    [self setUpNavItemTitle:itemTitle handle:handle leftFlag:YES];
}

- (void)navItemHandle:(UIBarButtonItem *)item {
    void (^handle)(NSString *) = objc_getAssociatedObject(self, &BaseTableVcNavRightItemHandleKey);
    if (handle) {
        handle(item.title);
    }
}

- (void)setUpNavItemTitle:(NSString *)itemTitle handle:(void(^)(NSString *itemTitle))handle leftFlag:(BOOL)leftFlag {
    if (itemTitle.length == 0 || !handle) {
        if (itemTitle == nil) {
            itemTitle = @"";
        } else if ([itemTitle isKindOfClass:[NSNull class]]) {
            itemTitle = @"";
        }
        if (leftFlag) {
            self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:itemTitle style:UIBarButtonItemStylePlain target:nil action:nil];
        } else {
            self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:itemTitle style:UIBarButtonItemStylePlain target:nil action:nil];
        }
    } else {
        if (leftFlag) {
            objc_setAssociatedObject(self, &BaseTableVcNavLeftItemHandleKey, handle, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:itemTitle style:UIBarButtonItemStylePlain target:self action:@selector(navItemHandle:)];
        } else {
            objc_setAssociatedObject(self, &BaseTableVcNavRightItemHandleKey, handle, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:itemTitle style:UIBarButtonItemStylePlain target:self action:@selector(navItemHandle:)];
        }
    }
    
}

/** 监听通知*/
- (void)observeNotiWithNotiName:(NSString *)notiName action:(SEL)action {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:action name:notiName object:nil];
}

/** 设置刷新类型*/
- (void)setRefreshType:(BaseTableVcRefreshType)refreshType {
    _refreshType = refreshType;
    switch (refreshType) {
        case BaseTableVcRefreshTypeNone: // 没有刷新
            break ;
        case BaseTableVcRefreshTypeOnlyCanRefresh: { // 只有下拉刷新
            [self addRefresh];
        } break ;
        case BaseTableVcRefreshTypeOnlyCanLoadMore: { // 只有上拉加载
            [self addLoadMore];
        } break ;
        case BaseTableVcRefreshTypeRefreshAndLoadMore: { // 下拉和上拉都有
            [self addRefresh];
            [self addLoadMore];
        } break ;
        default:
            break ;
    }
}

/** 导航栏标题*/
- (void)setNavItemTitle:(NSString *)navItemTitle {
    if ([navItemTitle isKindOfClass:[NSString class]] == NO) return ;
    if ([navItemTitle isEqualToString:_navItemTitle]) return ;
    _navItemTitle = navItemTitle.copy;
    self.navigationItem.title = navItemTitle;
}

- (NSString *)navItemTitle {
    return self.navigationItem.title;
}

/** statusBar是否隐藏*/
- (void)setHiddenStatusBar:(BOOL)hiddenStatusBar {
    _hiddenStatusBar = hiddenStatusBar;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (BOOL)hiddenStatusBar {
    return _hiddenStatusBar;
}

- (void)setBarStyle:(UIStatusBarStyle)barStyle {
    if (_barStyle == barStyle) return ;
    _barStyle = barStyle;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (BOOL)prefersStatusBarHidden {
    return self.hiddenStatusBar;
}

- (void)setShowRefreshIcon:(BOOL)showRefreshIcon {
    _showRefreshIcon = showRefreshIcon;
 
}



- (UIStatusBarStyle)preferredStatusBarStyle {
    return self.barStyle;
}

/** 右边item*/
- (void)setNavRightItem:(UIBarButtonItem *)navRightItem {
    
    _navRightItem = navRightItem;
    self.navigationItem.rightBarButtonItem = navRightItem;
}

- (UIBarButtonItem *)navRightItem {
    return self.navigationItem.rightBarButtonItem;
}
/** 左边item*/
- (void)setNavLeftItem:(UIBarButtonItem *)navLeftItem {
    
    _navLeftItem = navLeftItem;
    self.navigationItem.leftBarButtonItem = navLeftItem;
}

- (UIBarButtonItem *)navLeftItem {
    return self.navigationItem.leftBarButtonItem;
}

/** 需要系统分割线*/
- (void)setNeedCellSepLine:(BOOL)needCellSepLine {
    _needCellSepLine = needCellSepLine;
    self.tableView.separatorStyle = needCellSepLine ? UITableViewCellSeparatorStyleSingleLine : UITableViewCellSeparatorStyleNone;
}

- (BOOL)needCellSepLine {
    return self.tableView.separatorStyle == UITableViewCellSeparatorStyleSingleLine;
}

- (void)addRefresh {
    [Utils addPullRefreshForScrollView:self.tableView pullRefreshCallBack:^{
        [self refresh];
    }];
}

- (void)addLoadMore {
    [Utils addLoadMoreForScrollView:self.tableView loadMoreCallBack:^{
        [self loadMore];
    }];
}

/** 表视图偏移*/
- (void)setTableEdgeInset:(UIEdgeInsets)tableEdgeInset {
    _tableEdgeInset = tableEdgeInset;
    [self.view setNeedsUpdateConstraints];
    [self.view updateConstraintsIfNeeded];
    [self.view layoutIfNeeded];
    [self.view setNeedsLayout];
}


- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
    [self.view sendSubviewToBack:self.tableView];
}
/** 分割线颜色*/
- (void)setSepLineColor:(UIColor *)sepLineColor {
    if (!self.needCellSepLine) return;
    _sepLineColor = sepLineColor;
    
    if (sepLineColor) {
        self.tableView.separatorColor = sepLineColor;
    }
}

- (UIColor *)sepLineColor {
    return _sepLineColor ? _sepLineColor : [UIColor whiteColor];
}

/** 刷新数据*/
- (void)reloadData {
    [self.tableView reloadData];
}

/** 开始下拉*/
- (void)beginRefresh {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanRefresh || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils beginPullRefreshForScrollView:self.tableView];
    }
}

/** 刷新*/
- (void)refresh {
    if (self.refreshType == BaseTableVcRefreshTypeNone || self.refreshType == BaseTableVcRefreshTypeOnlyCanLoadMore) {
        return ;
    }
    self.isRefresh = YES; self.isLoadMore = NO;
}

/** 上拉加载*/
- (void)loadMore {
    if (self.refreshType == BaseTableVcRefreshTypeNone || self.refreshType == BaseTableVcRefreshTypeOnlyCanRefresh) {
        return ;
    }
    if (self.dataArray.count == 0) {
        return ;
    }
    self.isRefresh = NO; self.isLoadMore = YES;
    
}

- (void)commonConfigResponseWithResponse:(id)response isRefresh:(BOOL)isRefresh modelClass:(__unsafe_unretained Class)modelClass {
    [self commonConfigResponseWithResponse:response isRefresh:isRefresh modelClass:modelClass emptyText:nil];
}

- (void)commonConfigResponseWithResponse:(id)response isRefresh:(BOOL)isRefresh modelClass:(__unsafe_unretained Class)modelClass emptyText:(NSString *)emptyText {
    if ([response isKindOfClass:[NSArray class]] == NO) return ;
    if (self.isRefresh) { // 刷新
        
        // 停止刷新
        [self endRefresh];
        
        // 设置模型数组
        [self.dataArray removeAllObjects];
        self.dataArray = [modelClass mj_objectArrayWithKeyValuesArray:response];
        
        // 设置空界面占位文字
        if (emptyText.length) {
            [self addEmptyPageWithText:emptyText];
        }
        // 刷新界面
        [self reloadData];
        
    } else { // 上拉加载
        
        // 停止上拉
        [self endLoadMore];
        
        // 没有数据提示没有更多了
        if ([response count] == 0) {
            [self noticeNoMoreData];
        } else {
            // 设置模型数组
            NSArray *newModels = [modelClass mj_objectArrayWithKeyValuesArray:response];
            if (newModels.count < 50) {
                [self hiddenLoadMore];
            }
            [self.dataArray addObjectsFromArray:newModels];
            
            // 刷新界面
            [self reloadData];
        }
    }
}

/** 停止刷新*/
- (void)endRefresh {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanRefresh || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils endRefreshForScrollView:self.tableView];
    }
}

/** 停止上拉加载*/
- (void)endLoadMore {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanLoadMore || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils endLoadMoreForScrollView:self.tableView];
    }
}

/** 隐藏刷新*/
- (void)hiddenRrefresh {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanRefresh || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils hiddenHeaderForScrollView:self.tableView];
    }
}

/** 隐藏上拉加载*/
- (void)hiddenLoadMore {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanLoadMore || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils hiddenFooterForScrollView:self.tableView];
    }
}

/** 提示没有更多信息*/
- (void)noticeNoMoreData {
    if (self.refreshType == BaseTableVcRefreshTypeOnlyCanLoadMore || self.refreshType == BaseTableVcRefreshTypeRefreshAndLoadMore) {
        [Utils noticeNoMoreDataForScrollView:self.tableView];
    }
}

/** 头部正在刷新*/
- (BOOL)isHeaderRefreshing {
    return [Utils headerIsRefreshForScrollView:self.tableView];
}

//* 尾部正在刷新
- (BOOL)isFooterRefreshing {
    return [Utils footerIsLoadingForScrollView:self.tableView];
}

#pragma mark - <UITableViewDataSource, UITableViewDelegate>
// 分组数量
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if ([self respondsToSelector:@selector(numberOfSections)]) {
        return self.numberOfSections;
    }
    return 0;
}

// 指定组返回的cell数量
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([self respondsToSelector:@selector(numberOfRowsInSection:)]) {
        return [self numberOfRowsInSection:section];
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if ([self respondsToSelector:@selector(headerAtSection:)]) {
        return [self headerAtSection:section];
    }
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if ([self respondsToSelector:@selector(footerAtSection:)]) {
        return [self footerAtSection:section];
    }
    return nil;
}

// 每一行返回指定的cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if ([self respondsToSelector:@selector(cellAtIndexPath:)]) {
        return [self cellAtIndexPath:indexPath];
    }
    // 1. 创建cell
    BaseTableViewCell *cell = [BaseTableViewCell cellWithTableView:self.tableView];
    
    // 2. 返回cell
    return cell;
}

// 点击某一行 触发的事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BaseTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([self respondsToSelector:@selector(didSelectCellAtIndexPath:cell:)]) {
        [self didSelectCellAtIndexPath:indexPath cell:cell];
    }
}

- (UIView *)refreshHeader {
    return self.tableView.mj_header;
}

// 设置分割线偏移间距并适配
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.needCellSepLine) return ;
    UIEdgeInsets edgeInsets = UIEdgeInsetsMake(0, 15, 0, 0);
    if ([self respondsToSelector:@selector(sepEdgeInsetsAtIndexPath:)]) {
        edgeInsets = [self sepEdgeInsetsAtIndexPath:indexPath];
    }
    if ([tableView respondsToSelector:@selector(setSeparatorInset:)]) [tableView setSeparatorInset:edgeInsets];
    if ([tableView respondsToSelector:@selector(setLayoutMargins:)]) [tableView setLayoutMargins:edgeInsets];
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) [cell setSeparatorInset:edgeInsets];
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) [cell setLayoutMargins:edgeInsets];
}

// 每一行的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self respondsToSelector:@selector(cellheightAtIndexPath:)]) {
        return [self cellheightAtIndexPath:indexPath];
    }
    return tableView.rowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if ([self respondsToSelector:@selector(sectionHeaderHeightAtSection:)]) {
        return [self sectionHeaderHeightAtSection:section];
    }
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if ([self respondsToSelector:@selector(sectionFooterHeightAtSection:)]) {
        return [self sectionFooterHeightAtSection:section];
    }
    return 0.01;
}

- (NSInteger)numberOfSections { return 0; }

- (NSInteger)numberOfRowsInSection:(NSInteger)section { return 0; }

- (UITableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath { return [BaseTableViewCell cellWithTableView:self.tableView]; }

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath { return 0; }

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell { }

- (UIView *)headerAtSection:(NSInteger)section { return [BaseTableViewHeaderFooterView headerFooterViewWithTableView:self.tableView]; }

- (UIView *)footerAtSection:(NSInteger)section { return [BaseTableViewHeaderFooterView headerFooterViewWithTableView:self.tableView]; }

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section { return 0.01; }

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section { return 0.01; }

- (UIEdgeInsets)sepEdgeInsetsAtIndexPath:(NSIndexPath *)indexPath { return UIEdgeInsetsMake(0, 15, 0, 0); }

- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
