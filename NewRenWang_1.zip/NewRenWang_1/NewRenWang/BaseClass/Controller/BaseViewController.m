//
//  BaseViewController.m
//  NewRenWang
//
//  Created by JopYin on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"
#import "LoadAnimationView.h"
@interface BaseViewController ()
@property (nonatomic, weak) LoadAnimationView *animationView;
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)pop
{
    if (self.navigationController == nil) return;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)popToRootVc
{
    if (self.navigationController == nil) return;
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)popToVc:(UIViewController *)vc
{
    if ([vc isKindOfClass:[UIViewController class]] == NO) return;
    if (self.navigationController == nil) return;
    [self.navigationController popToViewController:vc animated:YES];
}

- (void)dismiss
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)dismissWithCompletion:(void(^)())completion
{
    [self dismissViewControllerAnimated:YES completion:completion];
}

- (void)presentVc:(UIViewController *)vc
{
    [self presentVc:vc completion:nil];
}

- (void)presentVc:(UIViewController *)vc completion:(void (^)(void))completion
{
    [self presentViewController:vc animated:YES completion:completion];
}

- (void)pushVc:(UIViewController *)vc
{
    if ([vc isKindOfClass:[UIViewController class]] == NO) return;
    if (self.navigationController == nil) return;
    if (vc.hidesBottomBarWhenPushed == NO) vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (void)removeChildVc:(UIViewController *)childVc
{
    
}

- (void)addChildVc:(UIViewController *)childVc
{
    
}

- (void)showLoadingAnimation {
    LoadAnimationView *animation = [[LoadAnimationView alloc] initWithFrame:CGRectMake(0, 20, ScreenWIDTH, ScreenHEIGHT)];
     _animationView = animation;
    [self.view addSubview:animation];
}

- (void)hideLoadingAnimation {
    [_animationView stopAnimation];
    _animationView = nil;
}

- (void)dealloc {
    NSLog(@"%s",__func__);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
