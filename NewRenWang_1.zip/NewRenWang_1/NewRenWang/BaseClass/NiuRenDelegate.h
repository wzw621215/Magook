//
//  NiuRenDelegate.h
//  NewRenWang
//
//  Created by JopYin on 2017/4/5.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark - push牛人中心
@protocol PushNiuRenDelegate<NSObject>
- (void)pushNiuRenCenter:(NSInteger)nrID;
@end

#pragma mark - 关注老师
@protocol FollowDelegate<NSObject>
- (void)followTeacher;
@end

#pragma mark - 登录
@protocol PresentLoginDelegate <NSObject>
- (void)presentLogin;
@end

#pragma mark - banner  push  wkWebView
@protocol PushWKWebViewDelegate <NSObject>
- (void)pushWKWebView:(NSString*)bannerURL;
@end

#pragma mark - push到直播间
@protocol PushLiveDelegate <NSObject>
- (void)pushLiveWith:(NSInteger)liveID;
@end
