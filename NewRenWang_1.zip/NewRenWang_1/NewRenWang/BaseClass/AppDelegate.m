//
//  AppDelegate.m
//  NewRenWang
//
//  Created by JopYin on 2017/1/6.
//  Copyright © 2017年 . All rights reserved.
//

#import "AppDelegate.h"
#import "SystemSettingManager.h"
#import "MainTabbarViewController.h"
#import "DataProvide.h"
#import <UMSocialCore/UMSocialCore.h>

#define USHARE_APPKEY   @"58d22af8cae7e7545700082e"

@interface AppDelegate ()

@property (nonatomic, strong)NSMutableArray *SHArr;      //上证指数
@property (nonatomic, strong)NSMutableArray *SZArr;      //深证指数
@property (nonatomic, strong)NSMutableArray *HuShenArr;  //沪深A股

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    /** 打开日志*/
    [[UMSocialManager defaultManager] openLog:YES];
    [UMSocialGlobal shareInstance].isClearCacheWhenGetUserInfo = NO;
    /* 设置友盟appkey */
    [[UMSocialManager defaultManager] setUmSocialAppkey:USHARE_APPKEY];
    
    [self configUSharePlatforms];
    
    [self configUShareSettings];
    
    [self updateDataBase];       //每日更新一次数据库
    // 系统设置
    [SystemSettingManager globalSystemSetting];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.rootViewController = [[MainTabbarViewController alloc] init];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}

#pragma mark - 设置第三方平台的信息
- (void)configUSharePlatforms {
    /**设置微信的appkey 和appSecret*/
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wxc48c9a170060dbdd" appSecret:@"b757ddbe865c164b6cdff10a0693ee54" redirectURL:@"http://mobile.umeng.com/social"];
   
    /* 设置分享到QQ互联的appID
     * U-Share SDK为了兼容大部分平台命名，统一用appKey和appSecret进行参数设置，而QQ平台仅需将appID作为U-Share的appKey参数传进即可。
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:@"1105160937" appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
   
    
    /* 设置新浪的appKey和appSecret */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:@"1686014587" appSecret:@"876e0a1926c8fcc7d12098f3c41675f5" redirectURL:@"https://sns.whalecloud.com/sina2/callback"];
}

- (void)configUShareSettings {
    /**打开图片水印*/
   // [UMSocialGlobal shareInstance].isUsingWaterMark = YES;
//    [UMSocialGlobal shareInstance].isUsingHttpsWhenShareContent = NO;
}

#if __IPHONE_OS_VERSION_MAX_ALLOWED > 100000
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
     //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响。
    BOOL result = [[UMSocialManager defaultManager]  handleOpenURL:url options:options];
    if (!result) {
        // 其他如支付等SDK的回调
    }
    return result;
}
#endif

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    //6.3的新的API调用，是为了兼容国外平台(例如:新版facebookSDK,VK等)的调用[如果用6.2的api调用会没有回调],对国内平台没有影响
    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url sourceApplication:sourceApplication annotation:annotation];
    if (!result) {
        // 其他如支付等SDK的回调
    }
    return result;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
    if (!result) {
        // 其他如支付等SDK的回调
    }
    return result;
}


#pragma mark - 更新数据库---每日只更新一次
- (void)updateDataBase {
    NSDate *  date=[NSDate date];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"Asia/beijing"];
    [format setTimeZone:timeZone];
    NSString *stringDate = [format stringFromDate:date];
    NSString *stirng = [YDConfigurationHelper getStringValueForConfigurationKey:@"isToday"];
    if (![stirng isEqualToString:stringDate]){
        [YDConfigurationHelper setStringValueForConfigurationKey:@"isToday" withValue:stringDate];
        [self getStocks];
    }
    
}

#pragma mark - 更新具体的股票数据库
- (void)getStocks {
    //深证指数
    [[DataProvide sharedStore] getShenZhenExpWithBlock:^(id data) {
        if ([data isKindOfClass:[NSArray class]]) {
            [self.SZArr addObjectsFromArray:data];
            NSInteger SZNum = [YDConfigurationHelper getIntergerValueForConfigurationKey:@"SZExp"];
            if (self.SZArr.count != SZNum) {
//                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0); //全局并行队列 可
                dispatch_queue_t queue = dispatch_queue_create("updateStock", DISPATCH_QUEUE_SERIAL);     //串行队列
                dispatch_async(queue, ^{
                    for (int i = 0; i<self.SZArr.count; i++){
                        StockModel *model = [[StockModel alloc] init];
                        model.isFav = 2;
                        [model setValuesForKeysWithDictionary:self.SZArr[i]];
//                        [[SearchStock shareManager] replaceStock:model];  //多线程操作数据库会导致崩溃或丢失数据
                        [[SearchStock shareManager] replaceStockInQueue:model];
                    }
                    [YDConfigurationHelper setIntergerValueForConfigurationKey:@"SZExp" withValue:self.SZArr.count];
                });
            }
        }
    } failure:^(NSString *error) {
    }];
    //上证指数
    [[DataProvide sharedStore] getShangZhenExpWithBlock:^(id data) {
        if ([data isKindOfClass: [NSArray class]])
        {
            [self.SHArr addObjectsFromArray:data];
            NSInteger SHNum = [YDConfigurationHelper getIntergerValueForConfigurationKey:@"SHExp"];
            if (self.SHArr.count != SHNum) {
                dispatch_queue_t queue = dispatch_queue_create("updateStock", DISPATCH_QUEUE_SERIAL);     //串行队列
                dispatch_async(queue, ^{
                    for (int i = 0; i<self.SHArr.count; i++)
                    {
                        StockModel *model = [[StockModel alloc] init];
                        model.isFav = 1;
                        [model setValuesForKeysWithDictionary:self.SHArr[i]];
                        [[SearchStock shareManager] replaceStockInQueue:model];
                    }
                    [YDConfigurationHelper setIntergerValueForConfigurationKey:@"SHExp" withValue:self.SHArr.count];
                });
            }
        }
    } failure:^(NSString *error) {
        
    }];
    //沪深A股
    [[DataProvide sharedStore] getAllStockWithBlock:^(id data) {
        if ([data isKindOfClass: [NSArray class]])
        {
            [self.HuShenArr addObjectsFromArray:data];
            NSInteger stocksNum = [YDConfigurationHelper getIntergerValueForConfigurationKey:@"HuShenA"];
            if (self.HuShenArr.count != stocksNum) {
                dispatch_queue_t queue = dispatch_queue_create("updateStock", DISPATCH_QUEUE_SERIAL);     //串行队列
                dispatch_async(queue, ^{
                    for (int i = 0; i<self.HuShenArr.count; i++)
                    {
                        StockModel *model = [[StockModel alloc] init];
                        model.isFav = 0;
                        [model setValuesForKeysWithDictionary:self.HuShenArr[i]];
                        [[SearchStock shareManager] replaceStockInQueue:model];
                    }
                    [YDConfigurationHelper setIntergerValueForConfigurationKey:@"HuShenA" withValue:self.HuShenArr.count];
                });
            }
        }
    } failure:^(NSString *error) {
        
    }];
}
#pragma mark -懒加载股票和指数数组
-(NSMutableArray *)SZArr {
    if (_SZArr == nil) {
        _SZArr = [NSMutableArray array];
    }
    return _SZArr;
}
-(NSMutableArray *)SHArr {
    if (_SHArr == nil) {
        _SHArr = [NSMutableArray array];
    }
    return _SHArr;
}
-(NSMutableArray *)HuShenArr {
    if (_HuShenArr == nil) {
        _HuShenArr = [NSMutableArray array];
    }
    return _HuShenArr;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
