//
//  NiuRenViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface NiuRenViewController : BaseViewController


/**供其他按钮控制跳转到指定控制器界面*/
- (void) selectVCIndex:(NSInteger)vcIndex;

@end
