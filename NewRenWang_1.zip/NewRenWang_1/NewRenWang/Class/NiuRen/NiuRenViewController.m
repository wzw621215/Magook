//
//  NiuRenViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuRenViewController.h"
#import "SGSegmentedControl.h"
#import "RecommendVC.h"
#import "SolveVC.h"
#import "OpStockViewController.h"
#import "TopicViewController.h"

@interface NiuRenViewController ()<SGSegmentedControlStaticDelegate,UIScrollViewDelegate>
@property (nonatomic, strong) SGSegmentedControlStatic *topSView;
@property (nonatomic, strong) SGSegmentedControlBottomView *bottomSView;

@property (nonatomic,assign)NSInteger vcIndex; //子控制器的索引

@end

@implementation NiuRenViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
}

#pragma  mark - 显示导航栏
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIView *statusBarView=[[UIView alloc] initWithFrame:CGRectMake(0, 0,ScreenWIDTH, 20)];
    statusBarView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:statusBarView];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    RecommendVC *oneVC = [[RecommendVC alloc] init];
    [self addChildViewController:oneVC];
    
    SolveVC *twoVC = [[SolveVC alloc] init];
    [self addChildViewController:twoVC];
    
    TopicViewController *threeVC = [[TopicViewController alloc] init];
    [self addChildViewController:threeVC];
    
    OpStockViewController *fourVC = [[OpStockViewController alloc] init];
    [self addChildViewController:fourVC];
    
    NSArray *childVC = @[oneVC, twoVC, threeVC, fourVC];
    NSArray *title_arr = @[@"推荐", @"解盘", @"话题", @"操盘"];
    
    self.bottomSView = [[SGSegmentedControlBottomView alloc] initWithFrame:CGRectMake(0, 64, ScreenWIDTH,self.view.height-64-49)];
    _bottomSView.childViewController = childVC;
    _bottomSView.backgroundColor = [UIColor clearColor];
    _bottomSView.delegate = self;
    //_bottomView.scrollEnabled = NO;
    [self.view addSubview:_bottomSView];
    
    self.topSView = [SGSegmentedControlStatic segmentedControlWithFrame:CGRectMake(0, 20, ScreenWIDTH, 44) delegate:self childVcTitle:title_arr indicatorIsFull:NO];
    // 必须实现的方法
    [self.topSView SG_setUpSegmentedControlType:^(SGSegmentedControlStaticType *segmentedControlStaticType, NSArray *__autoreleasing *nomalImageArr, NSArray *__autoreleasing *selectedImageArr) {
        *segmentedControlStaticType = SGSegmentedControlStaticTypeDefault;
    }];
    [self.topSView SG_setUpSegmentedControlStyle:^(UIColor *__autoreleasing *segmentedControlColor, UIColor *__autoreleasing *titleColor, UIColor *__autoreleasing *selectedTitleColor, UIColor *__autoreleasing *indicatorColor, BOOL *isShowIndicor) {
        *selectedTitleColor = kRGBColor(200, 0, 0);
        *indicatorColor = kRGBColor(200, 0, 0);
    }];
    self.topSView.selectedIndex = self.vcIndex;
    [self.view addSubview:_topSView];
}

#pragma mark -SGSegmentedControlStaticDelegate
- (void)SGSegmentedControlStatic:(SGSegmentedControlStatic *)segmentedControlStatic didSelectTitleAtIndex:(NSInteger)index {
    CNLog(@"index - - %ld", (long)index);
    // 计算滚动的位置
    CGFloat offsetX = index * self.view.frame.size.width;
    self.bottomSView.contentOffset = CGPointMake(offsetX, 0);
    [self.bottomSView showChildVCViewWithIndex:index outsideVC:self];
}
#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    // 计算滚动到哪一页
    NSInteger index = scrollView.contentOffset.x / scrollView.frame.size.width;
    // 1.添加子控制器view
    [self.bottomSView showChildVCViewWithIndex:index outsideVC:self];
    // 2.把对应的标题选中
    [self.topSView changeThePositionOfTheSelectedBtnWithScrollView:scrollView];
}


#pragma mark -外部按钮跳转到指定子控制器视图
- (void) selectVCIndex:(NSInteger)vcIndex {
    self.vcIndex = vcIndex;
    self.topSView.selectedIndex = vcIndex;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
