//
//  SolveVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "SolveVC.h"
#import "HomeSectionHeadView.h"
#import "NiuStockCell.h"
#import "KLineViewController.h"
#import "MinViewController.h"
#import "DataProvide.h"
#import "GoldProCell.h"
#import "TopicCell.h"
#import "SolveRequest.h"
#import "SolveVideoModel.h"
#import "HomeModel.h"
#import "Solve_TopicCell.h"
#import "SKAES.h"
#import "NiuRenVC.h"
@interface SolveVC ()<NiuStockLineDelegate,FollowDelegate,PresentLoginDelegate,PushNiuRenDelegate>

@property (nonatomic, weak) NiuStockCell *niuStockCell;

@property (nonatomic,strong)KLineViewController *KLineVC;
@property (nonatomic,strong)MinViewController *minTimeVC;
@property (nonatomic,strong)UIViewController *tmpVC;        //临时存储右侧视图正在显示的控制器
@property (nonatomic,copy)NSString *preClose;               //昨收价用于传给分时控制器
@property (nonatomic,strong) NSMutableArray *stockExpArr;  //存放底部的大盘指数 ：上证指数、深证指数、创业板
@property (nonatomic,strong) NSTimer *timer;               //用于刷新右侧视图顶部数据

@property (nonatomic,strong)NSMutableArray *videoArray;

/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;

@end

@implementation SolveVC

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self startTimer];
    [self refresh];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self stopTimer];
}

#pragma mark - 开启定时器 -- 右侧顶部行情定时刷新
- (void)startTimer{
    if ([_timer isValid]){
        [_timer invalidate];
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(getStockData) userInfo:nil repeats:YES];
}
#pragma mark - 关闭定时器 -- 右侧顶部行情定时刷新
- (void)stopTimer {
    if ([_timer isValid]){
        [_timer setFireDate:[NSDate distantFuture]]; //关闭定时器
        _timer = nil;
    }
}

#pragma mark - 请求下面
- (void)getStockData {
    NSString *Url = @"sh1A0001,sz399001,sz399006";
    [[DataProvide sharedStore] getShiShiDataWithURL:Url success:^(NSArray *data) {
        if (data.count > 0) {
            [self.stockExpArr removeAllObjects];
            [self.stockExpArr addObjectsFromArray:data];
            QuoteModel *model = data[0];
            self.preClose = model.closePrice;
            [self.niuStockCell updateUIWith:self.stockExpArr];
        }
    } failure:^(NSString *error) {
        [CNNavigationBarHUD showError:@"行情服务器异常"];
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.pageIndex = 1;
    self.needCellSepLine = NO;
    [self requestVideoData];
//    [self requestSolveData];
    
    self.refreshType = BaseTableVcRefreshTypeRefreshAndLoadMore;
}

#pragma mark - 请求金牌栏目数据
- (void)requestVideoData {
    BaseRequest *request = [BaseRequest requestWithUrl:kSolveVideoAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            NSArray *videoArr = [NSArray arrayWithArray:response[@"video"]];
            for (NSDictionary *dic in videoArr) {
                SolveVideoModel *model = [[SolveVideoModel alloc] mj_setKeyValues:dic];
                [self.videoArray addObject:model];
            }
            [self reloadData];
            [self endLoadMore];
        }
    }];
}

#pragma mark - 请求深度解盘数据
- (void)requestSolveData{
    SolveRequest *reequest = [[SolveRequest alloc] initWithPageIndex:self.pageIndex];
    [reequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            NSArray *array = [NSArray arrayWithArray:response[@"shendujp"]];
            for (NSDictionary *dic in array) {
                HTopicModel *model = [[HTopicModel alloc] mj_setKeyValues:dic];
                [self.dataArray addObject:model];
            }
            [self reloadData];
            [self endLoadMore];
        }
    }];
}

- (void)refresh {
    [super refresh];
    [self.dataArray removeAllObjects];
    self.pageIndex = 1;
    [self requestSolveData];
}

- (void)loadMore {
    [super loadMore];
    self.pageIndex++;
    [self requestSolveData];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 380;
    }else if (indexPath.section == 1){
        return 240;
    }else{
        return 150;
    }
}

- (NSInteger)numberOfSections{
    return 3;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }else if (section == 1){
        return 2;
    }else{
        return self.dataArray.count;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section{
    if (section == 0) {
        return 10;
    }
    return 0;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    }
    return 40;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        NiuStockCell *cell = [NiuStockCell nibCellWithTableView:self.tableView];
        cell.delegate = self;
        self.niuStockCell = cell;
        
        self.KLineVC.view.frame = cell.kLineView.bounds;
        [self addChildViewController:self.KLineVC];
        [cell.kLineView addSubview:self.KLineVC.view];
        self.tmpVC = self.KLineVC;
        [self showKLine];
        return cell;
    }else if (indexPath.section == 1){
        GoldProCell *cell = [GoldProCell nibCellWithTableView:self.tableView];
        cell.model = [self.videoArray objectAtIndexCheck:indexPath.row];
        return cell;
    }else{
        Solve_TopicCell *cell = [Solve_TopicCell nibCellWithTableView:self.tableView];
        cell.followDelegate = self;
        cell.loginDelegate = self;
        cell.NRDelegate = self;
        cell.model = [self.dataArray objectAtIndexCheck:indexPath.row];
        return cell;
    }
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    if (indexPath.section == 1) {
        SolveVideoModel *model = [self.videoArray objectAtIndexCheck:indexPath.row];
        NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)model.ID,[UserInfoManage sharedManager].token];
        NSString *desSn = [SKAES  encryt:sn];
        NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)model.ID,desSn];
        // NSString *HurlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]; //设置字符编码
        WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
        [self.navigationController pushViewController:webViewController animated:YES];
    }
}

#pragma mark - FollowDelegate
- (void)followTeacher {
    [self refresh];
}

#pragma mark - PresentLoginDelegate
- (void)presentLogin {
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}

#pragma mark - PushNiuRenDelegate  
- (void)pushNiuRenCenter:(NSInteger)nrID {
    
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)nrID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/%ld.html?sn=%@",(long)nrID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
    
    /*
    NiuRenVC *niurenCenterVC = [[NiuRenVC alloc] init];
    niurenCenterVC.nrID = nrID;
    [self.navigationController pushViewController:niurenCenterVC animated:YES];
     */
}

#pragma mark - 加载section的头部视图
- (UIView *)headerAtSection:(NSInteger)section{
    if (section == 1) {
        HomeSectionHeadView *sectionHeadView = [HomeSectionHeadView headerFooterViewWithTableView:self.tableView];
        sectionHeadView.title.text = @"金牌栏目";
        sectionHeadView.rightBtn.hidden = YES;
        return sectionHeadView;
    }else{
        HomeSectionHeadView *sectionHeadView = [HomeSectionHeadView headerFooterViewWithTableView:self.tableView];
        sectionHeadView.title.text = @"深度解盘";
        sectionHeadView.rightBtn.hidden = YES;
        return sectionHeadView;
    }
}

#pragma mark - 懒加载视频的数组
- (NSMutableArray *)videoArray {
    if (!_videoArray) {
        _videoArray = [NSMutableArray array];
    }
    return _videoArray;
}

#pragma mark *******************************-股票相关的****************
#pragma mark -- 代理方法 加载K线和分时  NiuStockLineDelegate
- (void)fenShiLine{
    self.minTimeVC.preClose = self.preClose;
    
    [self replaceRightController:self.KLineVC newController:self.minTimeVC];
}
- (void)dayKLine{
    self.KLineVC.klineType = @"4";
    [self showKLine];
}
- (void)weekLine{
    self.KLineVC.klineType = @"5";
    [self showKLine];
}
- (void)monthKLine{
    self.KLineVC.klineType = @"6";
    [self showKLine];
}
- (void)hourKLine{
    self.KLineVC.klineType = @"3";
    [self showKLine];
}
- (void)showKLine {
    if (self.tmpVC != self.KLineVC) {
        //当从分时切换到K线
        [self replaceRightController:self.tmpVC newController:self.KLineVC];
    }else{
        //当日K、周K、月K、60分钟相互切换时候 或者点击左侧视图切换过来
        [self.KLineVC updateKLine];
    }
}
- (void)replaceRightController:(UIViewController *)oldController newController:(UIViewController *)newController{
    newController.view.frame = self.niuStockCell.kLineView.bounds;
    [self addChildViewController:newController];
    [oldController willMoveToParentViewController:nil];
    [self.niuStockCell.kLineView addSubview:newController.view];
    __weak id weakSelf = self;
    [self transitionFromViewController:oldController toViewController:newController duration:0.3 options:UIViewAnimationOptionTransitionNone animations:^{
    } completion:^(BOOL finished) {
        [oldController.view removeFromSuperview];
        [oldController removeFromParentViewController];
        [newController didMoveToParentViewController:weakSelf];
        _tmpVC = newController;
    }];
}

- (KLineViewController *)KLineVC {
    if (_KLineVC == nil) {
        _KLineVC = [[KLineViewController alloc] init];
        _KLineVC.stockCode = @"sh1A0001";
        _KLineVC.klineType = @"4";
    }
    return _KLineVC;
}

- (MinViewController *)minTimeVC {
    if (_minTimeVC == nil) {
        _minTimeVC = [[MinViewController alloc] init];
        _minTimeVC.isExp = YES;
        _minTimeVC.stockCode = @"sh1A0001";
    }
    return _minTimeVC;
}

#pragma mark - 懒加载
- (NSMutableArray *)stockExpArr {
    if (!_stockExpArr) {
        _stockExpArr = [NSMutableArray array];
    }
    return _stockExpArr;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
