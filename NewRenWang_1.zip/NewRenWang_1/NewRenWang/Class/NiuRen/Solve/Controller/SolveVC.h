//
//  SolveVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface SolveVC : BaseTableViewController

@end
