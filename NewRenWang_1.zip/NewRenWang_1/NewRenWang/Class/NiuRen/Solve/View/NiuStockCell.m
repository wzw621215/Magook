//
//  NiuStockCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuStockCell.h"

@interface NiuStockCell ()

@property (weak, nonatomic) IBOutlet UIView *btnView;
@property (weak, nonatomic) IBOutlet UIButton *fenShiBtn;
@property (weak, nonatomic) IBOutlet UIButton *dayBtn;
@property (weak, nonatomic) IBOutlet UIButton *weekBtn;
@property (weak, nonatomic) IBOutlet UIButton *monthBtn;
@property (weak, nonatomic) IBOutlet UIButton *hourBtn;
@property (weak,nonatomic) UIButton *tmpBtn;


@property (weak, nonatomic) IBOutlet UILabel *SHPrice;
@property (weak, nonatomic) IBOutlet UILabel *SHRate;
@property (weak, nonatomic) IBOutlet UILabel *SHChange;

@property (weak, nonatomic) IBOutlet UILabel *SZPrice;
@property (weak, nonatomic) IBOutlet UILabel *SZRate;
@property (weak, nonatomic) IBOutlet UILabel *SZChange;

@property (weak, nonatomic) IBOutlet UILabel *CYPrice;
@property (weak, nonatomic) IBOutlet UILabel *CYRate;
@property (weak, nonatomic) IBOutlet UILabel *CYChange;

@end

@implementation NiuStockCell

- (void)awakeFromNib{
    [super awakeFromNib];
    self.dayBtn.enabled = NO;
    self.dayBtn.backgroundColor = [UIColor colorWithHexString:@"114068"];
    self.tmpBtn = self.dayBtn;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)updateUIWith:(NSMutableArray *)stockExpArr{
    [stockExpArr enumerateObjectsUsingBlock:^(QuoteModel * obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx == 0) {
            self.SHPrice.text = obj.price;
            self.SHRate.text = obj.changeRate;
            self.SHChange.text = obj.change;
            if ([obj.changeRate floatValue] >= 0) {
                self.SHPrice.textColor  = kRGBColor(227, 0, 27);
                self.SHRate.textColor   = kRGBColor(227, 0, 27);
                self.SHChange.textColor = kRGBColor(227, 0, 27);
            }else{
                self.SHPrice.textColor  = kRGBColor(60, 178, 17);
                self.SHRate.textColor   = kRGBColor(60, 178, 17);
                self.SHChange.textColor = kRGBColor(60, 178, 17);
            }
        }else if (idx == 1){
            self.SZPrice.text = obj.price;
            self.SZRate.text = obj.changeRate;
            self.SZChange.text = obj.change;
            if ([obj.changeRate floatValue] >= 0) {
                self.SZPrice.textColor  = kRGBColor(227, 0, 27);
                self.SZRate.textColor   = kRGBColor(227, 0, 27);
                self.SZChange.textColor  = kRGBColor(227, 0, 27);
            }else{
                self.SZPrice.textColor  = kRGBColor(227, 0, 27);
                self.SZRate.textColor   = kRGBColor(227, 0, 27);
                self.SZChange.textColor = kRGBColor(227, 0, 27);
            }
        }else if (idx == 2){
            self.CYPrice.text = obj.price;
            self.CYRate.text = obj.changeRate;
            self.CYChange.text = obj.change;
            if ([obj.changeRate floatValue] >= 0) {
                self.CYPrice.textColor  = kRGBColor(227, 0, 27);
                self.CYRate.textColor   = kRGBColor(227, 0, 27);
                self.CYChange.textColor = kRGBColor(227, 0, 27);
            }else{
                self.CYPrice.textColor  = kRGBColor(227, 0, 27);
                self.CYRate.textColor   = kRGBColor(227, 0, 27);
                self.CYChange.textColor = kRGBColor(227, 0, 27);
            }
        }
    }];

}


- (IBAction)fenShi:(id)sender {
    [self setSelectButton:sender];
    if ([self.delegate respondsToSelector:@selector(fenShiLine)]) {
        [self.delegate fenShiLine];
    }
}

- (IBAction)day:(id)sender {
    [self setSelectButton:sender];
    if ([self.delegate respondsToSelector:@selector(dayKLine)]) {
        [self.delegate dayKLine];
    }
}

- (IBAction)week:(id)sender {
    [self setSelectButton:sender];
    if ([self.delegate respondsToSelector:@selector(weekLine)]) {
        [self.delegate weekLine];
    }
}

- (IBAction)month:(id)sender {
    [self setSelectButton:sender];
    if ([self.delegate respondsToSelector:@selector(monthKLine)]) {
        [self.delegate monthKLine];
    }
}

- (IBAction)hour:(id)sender {
    [self setSelectButton:sender];
    if ([self.delegate respondsToSelector:@selector(hourKLine)]) {
        [self.delegate hourKLine];
    }
}
#pragma mark - 还原未点击的按钮状态 设置被点击按钮状态
- (void)setSelectButton:(UIButton *)selBtn{
    self.tmpBtn.enabled = YES;
    selBtn.enabled = NO;
    selBtn.backgroundColor = [UIColor colorWithHexString:@"114068"];
    self.tmpBtn.backgroundColor = [UIColor clearColor];
    self.tmpBtn = selBtn;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.btnView.layer.borderWidth = 0.5;
    self.btnView.layer.borderColor = [[UIColor colorWithHexString:@"7D7D7D"] CGColor];
}

@end
