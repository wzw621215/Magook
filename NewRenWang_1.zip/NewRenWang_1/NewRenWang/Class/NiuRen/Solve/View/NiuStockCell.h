//
//  NiuStockCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "QuoteModel.h"

@protocol NiuStockLineDelegate <NSObject>

- (void)fenShiLine;
- (void)dayKLine;
- (void)weekLine;
- (void)monthKLine;
- (void)hourKLine;

@end


@interface NiuStockCell : BaseTableViewCell

@property (nonatomic,weak)id<NiuStockLineDelegate>delegate;

@property (weak, nonatomic) IBOutlet UIView *kLineView;

@property (nonatomic,strong)QuoteModel *model;

- (void)updateUIWith:(NSMutableArray *)stockExpArr;


@end
