//
//  Solve_TopicCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "HomeModel.h"

@interface Solve_TopicCell : BaseTableViewCell

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

@property (nonatomic,weak)id<FollowDelegate>followDelegate;

@property(nonatomic,weak)id<PushNiuRenDelegate>NRDelegate;

@property (nonatomic, strong)HTopicModel *model;

@end
