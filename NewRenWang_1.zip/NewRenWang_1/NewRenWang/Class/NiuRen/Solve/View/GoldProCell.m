//
//  GoldProCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "GoldProCell.h"

@interface GoldProCell()

@property (weak, nonatomic) IBOutlet UIImageView *videoImg;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *num;
@property (weak, nonatomic) IBOutlet UILabel *summary;

@end

@implementation GoldProCell

- (void)setModel:(SolveVideoModel *)model {
    _model = model;
    [self.videoImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"replace"]];
    self.title.text = model.title;
    self.num.text = [NSString stringWithFormat:@"%ld",(long)model.online_num];
    self.summary.text = model.summary;
}


@end
