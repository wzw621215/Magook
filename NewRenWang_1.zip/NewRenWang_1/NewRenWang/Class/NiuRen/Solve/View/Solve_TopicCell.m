//
//  Solve_TopicCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "Solve_TopicCell.h"
#import "UpRequest.h"
#import "DownRequest.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"
@interface Solve_TopicCell()
@property (weak, nonatomic) IBOutlet UIImageView *teacherImg;

@property (weak, nonatomic) IBOutlet YYLabel *content;
@property (weak, nonatomic) IBOutlet UILabel *teacherName;
@property (weak, nonatomic) IBOutlet UILabel *teacherFans;
@property (weak, nonatomic) IBOutlet UIButton *followBtn;
@property (weak, nonatomic) IBOutlet UILabel *weak;
@property (weak, nonatomic) IBOutlet UIButton *weakBtn;
@property (weak, nonatomic) IBOutlet UILabel *strong;
@property (weak, nonatomic) IBOutlet UIButton *strongBtn;

@property (nonatomic, strong)UILabel *time;
@property (nonatomic, strong)NSMutableAttributedString *textAtt;
@property (nonatomic, strong)UIImageView *stateImage;

@end


@implementation Solve_TopicCell
- (void)setModel:(HTopicModel *)model {
    if (model == nil) {
        return ;
    }
    _model = model;
    [self.teacherImg sd_setImageWithURL:[NSURL URLWithString:model.user.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    {
        self.textAtt = [NSMutableAttributedString new];
        self.stateImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"time"]];
        self.time = [[UILabel alloc] initWithFrame:_stateImage.frame];
        _time.text = model.time;
        _time.textColor = kRGBColor(125, 125, 125);;
        _time.font = kFont(11);
        _time.textAlignment = NSTextAlignmentCenter;
        [_stateImage addSubview:_time];
        [_textAtt appendAttributedString:[NSMutableAttributedString yy_attachmentStringWithContent:_stateImage contentMode:UIViewContentModeCenter attachmentSize:CGSizeMake(39, 15) alignToFont:[UIFont systemFontOfSize:12.0f] alignment:YYTextVerticalAlignmentCenter]];
        [_textAtt yy_appendString:model.content];
        _textAtt.yy_lineSpacing = 5;
        self.content.attributedText = _textAtt;
        self.content.numberOfLines = 0;
        self.content.font = kFont(12);
        self.content.textColor = kRGBColor(0, 0, 0);
    }
    self.teacherName.text = model.user.name;
    self.teacherFans.text = [NSString stringWithFormat:@"%ld",(long)model.user.fans];
    
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        self.strong.text = [NSString stringWithFormat:@"%ld",(long)model.up];
        self.weak.text = [NSString stringWithFormat:@"%ld",(long)model.down];
        self.strongBtn.selected = model.isup;
        self.weakBtn.selected = model.isdown;
        self.followBtn.selected = model.user.isfollw;
    }else{
        //未登录
        self.strong.text = [NSString stringWithFormat:@"%ld",(long)model.up];
        self.weak.text = [NSString stringWithFormat:@"%ld",(long)model.down];
        self.strongBtn.selected = NO;
        self.weakBtn.selected = NO;
        self.followBtn.selected = NO;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self.teacherImg addActionWithTarget:self action:@selector(pushNiuRen)];
}

#pragma mark - push到牛人中心
- (void)pushNiuRen{
    if ([self.NRDelegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        [self.NRDelegate pushNiuRenCenter:self.model.user.ID];
    }
}


#pragma mark - 关注老师
- (IBAction)followTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        
        if (self.followBtn.selected) {
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = NO;
                    self.model.user.isfollw = NO;
                    if ([self.followDelegate respondsToSelector:@selector(followTeacher)]) {
                        [self.followDelegate followTeacher];
                    }
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    
                    self.followBtn.selected = YES;
                    self.model.user.isfollw = YES;
                    if ([self.followDelegate respondsToSelector:@selector(followTeacher)]) {
                        [self.followDelegate followTeacher];
                    }
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

#pragma mark- 点踩
- (IBAction)down:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        
        DownRequest *request = [[DownRequest alloc] initWithType:self.model.type targetid:self.model.ID];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                self.weakBtn.selected = !self.weakBtn.selected;
                self.model.isdown = self.weakBtn.selected;
                self.model.down = [response[@"down"] integerValue];
                self.weak.text = [NSString stringWithFormat:@"%@",response[@"down"]];
                self.strong.text = [NSString stringWithFormat:@"%@",response[@"up"]];
            }else{
                [CNNavigationBarHUD showError:message];
            }
        }];
    }else{
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

#pragma mark - 点赞
- (IBAction)up:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        UpRequest *request = [[UpRequest alloc] initWithType:self.model.type targetid:self.model.ID];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                self.strongBtn.selected = !self.strongBtn.selected;
                self.model.isup = self.strongBtn.selected;
        
                self.model.up = [response[@"up"] integerValue];
                self.strong.text = [NSString stringWithFormat:@"%@",response[@"up"]];
                self.weak.text = [NSString stringWithFormat:@"%@",response[@"down"]];
            }else{
                [CNNavigationBarHUD showError:message];
            }
        }];
    }else{
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }

}

@end
