//
//  SolveVideoModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/1.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface SolveVideoModel : BaseModel

@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger online_num;
@property (nonatomic,copy)NSString *redirectUrl;
@property (nonatomic,copy)NSString *summary;
@property (nonatomic,copy)NSString *thumb_href;
@property (nonatomic,copy)NSString *title;

@end
