//
//  SolveVideoModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/1.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "SolveVideoModel.h"

@implementation SolveVideoModel

@end
