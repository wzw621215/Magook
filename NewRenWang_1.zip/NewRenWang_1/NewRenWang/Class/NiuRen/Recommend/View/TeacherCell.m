//
//  TeacherCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TeacherCell.h"
#import "TeaView.h"

@interface TeacherCell ()<PresentLoginDelegate>

@property (nonatomic,weak) UIView *horLine;

@property (nonatomic,weak) UIView *verLine1;

@property (nonatomic,weak) UIView *verLine2;

@property (nonatomic,weak) TeaView *view1;

@property (nonatomic,weak) TeaView *view2;

@property (nonatomic,weak) TeaView *view3;

@property (nonatomic,weak) TeaView *view4;

@end

@implementation TeacherCell

- (void)setNrRecommend:(NSArray<NrRecModel *> *)nrRecommend {
    _nrRecommend = nrRecommend;
    [nrRecommend enumerateObjectsUsingBlock:^(NrRecModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx == 0) {
            self.view1.model = obj;
        }else if (idx == 1){
            self.view2.model = obj;
        }else if (idx == 2){
            self.view3.model = obj;
        }else if (idx == 3){
            self.view4.model = obj;
        }
    }];
}

- (UIView *)horLine {
    if (!_horLine) {
        UIView *horLine = [[UIView alloc] init];
        horLine.backgroundColor = kRGBColor(220,220,220);
        [self.contentView addSubview:horLine];
        _horLine = horLine;
    }
    return _horLine;
}

- (UIView *)verLine1 {
    if (!_verLine1) {
        UIView *verLine1 = [[UIView alloc] init];
        verLine1.backgroundColor = kRGBColor(220,220,220);
        [self.contentView addSubview:verLine1];
        _verLine1 = verLine1;
    }
    return _verLine1;
}

- (UIView *)verLine2 {
    if (!_verLine2) {
        UIView *verLine2 = [[UIView alloc] init];
        verLine2.backgroundColor = kRGBColor(220,220,220);
        [self.contentView addSubview:verLine2];
        _verLine2 = verLine2;
    }
    return _verLine2;
}

- (TeaView *)view1 {
    if (!_view1) {
        TeaView *view1 = [TeaView teaView];
        view1.loginDelegate = self;
        [view1 addActionWithTarget:self action:@selector(pushTeacher1)];
        [self.contentView addSubview:view1];
        _view1 = view1;
    }
    return _view1;
}

- (TeaView *)view2 {
    if (!_view2) {
        TeaView *view2 = [TeaView teaView];
        view2.loginDelegate = self;
        [view2 addActionWithTarget:self action:@selector(pushTeacher2)];
        [self.contentView addSubview:view2];
        _view2 = view2;
    }
    return _view2;
}

- (TeaView *)view3 {
    if (!_view3) {
        TeaView *view3 = [TeaView teaView];
        view3.loginDelegate = self;
        [view3 addActionWithTarget:self action:@selector(pushTeacher3)];
        [self.contentView addSubview:view3];
        _view3 = view3;
    }
    return _view3;
}

- (TeaView *)view4 {
    if (!_view4) {
        TeaView *view4 = [TeaView teaView];
        view4.loginDelegate = self;
        [view4 addActionWithTarget:self action:@selector(pushTeacher4)];
        [self.contentView addSubview:view4];
        _view4 = view4;
    }
    return _view4;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.horLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.contentView.mas_width);
        make.height.equalTo(@0.5);
        make.center.equalTo(self.contentView);
    }];
    
    [self.verLine1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@0.5);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.top.equalTo(self.contentView.mas_top).offset(10);
        make.bottom.equalTo(self.horLine.mas_top).offset(-10);
    }];
    
    [self.verLine2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.equalTo(self.verLine1);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.top.equalTo(self.horLine.mas_bottom).offset(10);
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-10);
    }];
    
    [self.view1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(5);
        make.right.equalTo(self.verLine1.mas_left);
        make.top.equalTo(self.contentView.mas_top);
        make.bottom.equalTo(self.horLine.mas_top);
    }];
    
    [self.view2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.verLine1.mas_right);
        make.right.equalTo(self.contentView.mas_right);
        make.top.equalTo(self.contentView.mas_top);
        make.bottom.equalTo(self.horLine.mas_top);
    }];
    
    [self.view3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(5);
        make.right.equalTo(self.verLine2.mas_left);
        make.top.equalTo(self.horLine.mas_bottom);
        make.bottom.equalTo(self.contentView.mas_bottom);
    }];
    
    [self.view4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.verLine2.mas_right);
        make.right.equalTo(self.contentView.mas_right);
        make.top.equalTo(self.horLine.mas_bottom);
        make.bottom.equalTo(self.contentView.mas_bottom);
    }];
    
}

- (void)pushTeacher1{
    if (self.nrRecommend.count>0 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecModel *model = self.nrRecommend[0];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher2{
    if (self.nrRecommend.count>1 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecModel *model = self.nrRecommend[1];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher3{
    if (self.nrRecommend.count>2 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecModel *model = self.nrRecommend[2];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher4{
    if (self.nrRecommend.count>3 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecModel *model = self.nrRecommend[3];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}

#pragma mark -PresentLoginDelegate
//未登录去登录页
- (void)presentLogin{
    if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
        [self.loginDelegate presentLogin];
    }
}


@end
