//
//  NiuLiveCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuLiveCell.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

@interface NiuLiveCell()

@property (weak, nonatomic) IBOutlet UIImageView *liveImg;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *summary;
@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UIButton *followBtn;

@property (weak, nonatomic) IBOutlet UILabel *online;

@end

@implementation NiuLiveCell

- (void)setModel:(LiveModel *)model {
    _model = model;
    [self.liveImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href]];
    self.title.text = model.title;
    self.summary.text = model.summary;
    self.userName.text = model.user.name;
    self.online.text = [NSString stringWithFormat:@"%ld",(long)model.online_num];
    
    if ([UserInfoManage sharedManager].isLogin) {
        self.followBtn.selected = model.user.isfollw;
    }else{
        self.followBtn.selected = NO;
    }
}
- (IBAction)followTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if (self.followBtn.selected) {
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
                
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

@end
