//
//  RankCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RankCell.h"
#import "JXButton.h"

@interface RankCell ()

@property (nonatomic, weak) JXButton *firstBtn;

@property (nonatomic, weak) JXButton *secondBtn;

@property (nonatomic, weak) JXButton *threeBtn;

@end

@implementation RankCell

- (JXButton *)firstBtn{
    if (!_firstBtn) {
        JXButton *firstBtn = [[JXButton alloc] init];
        [firstBtn setTitle:@"人气榜" forState:0];
        [firstBtn setTitleColor:[UIColor blackColor] forState:0];
        [firstBtn setImage:[UIImage imageNamed:@"rqb"] forState:0];
        [firstBtn addTarget:self action:@selector(firstAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:firstBtn];
        _firstBtn = firstBtn;
    }
    return _firstBtn;
}

- (JXButton *)secondBtn{
    if (!_secondBtn) {
        JXButton *secondBtn = [[JXButton alloc] init];
        [secondBtn setTitle:@"点赞榜" forState:0];
        [secondBtn setTitleColor:[UIColor blackColor] forState:0];
        [secondBtn setImage:[UIImage imageNamed:@"syb"] forState:0];
        [secondBtn addTarget:self action:@selector(secondAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:secondBtn];
        _secondBtn = secondBtn;
    }
    return _secondBtn;
}

- (JXButton *)threeBtn{
    if (!_threeBtn) {
        JXButton *threeBtn = [[JXButton alloc] init];
        [threeBtn setTitle:@"话题榜" forState:0];
        [threeBtn setTitleColor:[UIColor blackColor] forState:0];
        [threeBtn setImage:[UIImage imageNamed:@"hdb"] forState:0];
        [threeBtn addTarget:self action:@selector(threeAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:threeBtn];
        _threeBtn = threeBtn;
    }
    return _threeBtn;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.firstBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(35);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(self.secondBtn.mas_left).offset(-60);
        make.height.equalTo(@100);
        make.width.equalTo(@((self.contentView.width-190)/3));
    }];
    [self.secondBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.right.equalTo(self.threeBtn.mas_left).offset(-60);
        make.width.height.equalTo(self.firstBtn);
    }];
    [self.threeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-35);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.width.height.equalTo(self.firstBtn);
    }];
}

- (void)firstAction:(UIButton *)sender{
    if ([self.delegate respondsToSelector:@selector(pushDetailVC:)]) {
        [self.delegate pushDetailVC:Fans];
    }
}

- (void)secondAction:(UIButton *)sender{
    if ([self.delegate respondsToSelector:@selector(pushDetailVC:)]) {
        [self.delegate pushDetailVC:Strong];
    }
}

- (void)threeAction:(UIButton *)sender{
    if ([self.delegate respondsToSelector:@selector(pushDetailVC:)]) {
        [self.delegate pushDetailVC:Topic];
    }
}

@end
