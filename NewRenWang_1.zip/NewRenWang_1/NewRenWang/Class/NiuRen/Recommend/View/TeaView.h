//
//  TeaView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecModel.h"

@interface TeaView : UIView

@property (nonatomic,strong)NrRecModel *model;

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

@property (weak, nonatomic) IBOutlet UIImageView *teacherIcon;

+(instancetype)teaView;

@end
