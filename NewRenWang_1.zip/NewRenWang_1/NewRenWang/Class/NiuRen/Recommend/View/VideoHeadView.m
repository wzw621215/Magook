//
//  VideoHeadView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "VideoHeadView.h"
#import "SGSegmentedControl.h"

@interface VideoHeadView ()<SGSegmentedControlDefaultDelegate>

@property (nonatomic, strong) SGSegmentedControlDefault *topSView;

@property (nonatomic, strong)NSMutableArray *titleArr;

@property (nonatomic, strong)NSMutableArray *categoryIdArr;

@end

@implementation VideoHeadView

- (NSMutableArray *)titleArr {
    if (!_titleArr) {
        _titleArr  = [NSMutableArray array];
    }
    return _titleArr;
}

- (NSMutableArray *)categoryIdArr {
    if (!_categoryIdArr) {
        _categoryIdArr  = [NSMutableArray array];
    }
    return _categoryIdArr;
}

- (instancetype)initWithNSArray:(NSArray <VideoCategoryModel *>*)video{
    self = [super init];
    if (self) {
        for (VideoCategoryModel *model in video) {
            [self.titleArr addObject:model.category];
            [self.categoryIdArr addObject:model.categoryid];
        }
        [self createUI];
    }
    return self;
}

- (void)createUI{
    self.backgroundColor = [UIColor whiteColor];
    UIView *line = [[UIView alloc] init];
    line.backgroundColor = [UIColor colorWithHexString:@"7D7D7D"];
    [self addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom).offset(0);
        make.height.equalTo(@0.5);
        make.left.equalTo(self.mas_left).offset(0);
        make.right.equalTo(self.mas_right).offset(0);
    }];
    
    self.topSView = [SGSegmentedControlDefault segmentedControlWithFrame:CGRectMake(0, 0, ScreenWIDTH, 40) delegate:self childVcTitle:self.titleArr isScaleText:NO];
    self.topSView.indicatorColor = kRGBColor(200, 0, 0);
    self.topSView.titleColorStateSelected = kRGBColor(200, 0, 0);
    [self addSubview:_topSView];
}

- (void)SGSegmentedControlDefault:(SGSegmentedControlDefault *)segmentedControlDefault didSelectTitleAtIndex:(NSInteger)index {
    CNLog(@"index - - %ld", (long)index);
    if ([self.delegate respondsToSelector:@selector(postCategoryId:)]) {
        [self.delegate postCategoryId:self.categoryIdArr[index]];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
}

@end
