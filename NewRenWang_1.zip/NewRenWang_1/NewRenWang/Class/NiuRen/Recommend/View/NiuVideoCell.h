//
//  NiuVideoCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "VideoHeadView.h"

@interface NiuVideoCell : BaseTableViewCell<VideoCategoryDelegate>

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;

/** offset */
@property (nonatomic, assign) CGFloat offset;

@property (nonatomic,weak)id <PushLiveDelegate> liveDelegate;

@end
