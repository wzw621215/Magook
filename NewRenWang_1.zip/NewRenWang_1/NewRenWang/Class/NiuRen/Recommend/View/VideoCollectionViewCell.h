//
//  VideoCollectionViewCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecVideoModel.h"

@interface VideoCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong)RecVideoModel *model;

@end
