//
//  NiuVideoCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuVideoCell.h"
#import "VideoCollectionViewCell.h"
#import "RecVideoRequest.h"
#import "VideoHeadView.h"
#import "RecVideoModel.h"
#import "YZBackFooter.h"
#import "YZHeader.h"

@interface NiuVideoCell ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,weak)UICollectionView *videoCollectionView;

@property (nonatomic,assign)NSInteger count;

@property (nonatomic, weak) UITableView *niuTableView;

/**  视频栏目 */
@property (nonatomic, copy) NSString *categoryId;
/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;

@property (nonatomic, strong)NSMutableArray *dataArray;

@end

static NSString * const CellID = @"VideoCollectionViewCell";

@implementation NiuVideoCell

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath {
    NiuVideoCell *cell = [NiuVideoCell cellWithTableView:tableView];
    cell.videoCollectionView.backgroundColor = [UIColor whiteColor];
    cell.niuTableView = tableView;
    [cell setupRefresh];
    [cell.videoCollectionView.mj_header beginRefreshing];
    [cell.videoCollectionView registerNib:[UINib nibWithNibName:CellID bundle:nil] forCellWithReuseIdentifier:CellID];
    return cell;
}

- (UICollectionView *)videoCollectionView {
    if (!_videoCollectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        flowLayout.itemSize = CGSizeMake((ScreenWIDTH - 35)/2, 145);
        flowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 0, 10);
        flowLayout.minimumLineSpacing = 15;
        flowLayout.minimumInteritemSpacing = 15;
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
        
    
        UICollectionView *videoCollectionView = [[UICollectionView alloc] initWithFrame:self.contentView.bounds collectionViewLayout:flowLayout];
        [self.contentView addSubview:videoCollectionView];
        videoCollectionView.delegate = self;
        videoCollectionView.dataSource = self;
        _videoCollectionView = videoCollectionView;
    }
    return _videoCollectionView;
}

- (void)setupRefresh{
    
    self.videoCollectionView.mj_header  = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNew)];
    self.videoCollectionView.mj_header.automaticallyChangeAlpha = YES;
    self.videoCollectionView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
    
    
//    self.videoCollectionView.mj_header  = [YZHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNew)];
//    self.videoCollectionView.mj_header.automaticallyChangeAlpha = YES;
//    self.videoCollectionView.mj_footer = [YZBackFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMore)];
}

- (void)loadNew{
    [self.videoCollectionView.mj_footer endRefreshing];
    self.pageIndex = 1;
    [self.dataArray removeAllObjects];
    if (self.categoryId) {
        [self requestVideoData:self.categoryId];
    }else{
        //当第一次时默认请求第一个视频
        [self requestVideoData:@"b"];
    }
    [self.videoCollectionView.mj_header endRefreshing];
}

- (void)loadMore{
    [self.videoCollectionView.mj_header endRefreshing];
    if (self.dataArray.count == self.count){
        [CNNavigationBarHUD showSuccess:@"数据全部加载完"];
    }else {
        self.pageIndex ++;
        if (self.categoryId) {
            [self requestVideoData:self.categoryId];
        }else{
            //当第一次时默认请求第一个视频
            [self requestVideoData:@"b"];
        }
    }
    [self.videoCollectionView.mj_footer endRefreshing];
}

#pragma mark - VideoCategoryDelegate
- (void)postCategoryId:(NSString *)categoryId {
    [self.dataArray removeAllObjects];
    self.categoryId = categoryId;
    [self requestVideoData:categoryId];
}
#pragma mark - 根据categoryId 请求最下面视频数据
- (void)requestVideoData:(NSString *)categoryId {
    RecVideoRequest *request = [[RecVideoRequest alloc] initWithVideoCategoryId:categoryId pageIndex:self.pageIndex];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            self.count = [response[@"count"] integerValue];
            NSArray *rows = [NSArray arrayWithArray:response[@"rows"]];
            if (rows.count > 0) {
                for (int i = 0; i < rows.count; i++) {
                    RecVideoModel *model = [[RecVideoModel alloc] mj_setKeyValues:rows[i]];
                    [self.dataArray addObject:model];
                }
            }
        }
        [self.videoCollectionView reloadData];
    }];
}
#pragma mark -
- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    VideoCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellID forIndexPath:indexPath];
    cell.model = [self.dataArray objectAtIndexCheck:indexPath.item];
    return cell;
}
#pragma mark - UICollectionViewDelegate 
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {  // 处理cell的点击事件
    if ([self.liveDelegate respondsToSelector:@selector(pushLiveWith:)]) {
        RecVideoModel *model = [self.dataArray objectAtIndexCheck:indexPath.item];
        [self.liveDelegate pushLiveWith:model.ID];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.niuTableView) {
        self.height = scrollView.contentOffset.y;
        CNLog(@"=====%f",scrollView.contentOffset.y);
    }
}
#pragma mark -属性offset的set方法
- (void)setOffset:(CGFloat)offset {
    if (offset >= 1030) {
        //最下面的一组 已经到顶了
        self.videoCollectionView.frame = CGRectMake(0, 0, ScreenWIDTH,  ScreenHEIGHT - 153);
    } else {
        self.videoCollectionView.frame = CGRectMake(0, 0, ScreenWIDTH,  ScreenHEIGHT-(1030-offset+153));
    }
}


@end
