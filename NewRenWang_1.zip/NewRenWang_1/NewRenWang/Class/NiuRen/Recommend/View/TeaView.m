//
//  TeaView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TeaView.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

@interface TeaView ()

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *nameWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *followBtnWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *followH;

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *title;

@property (weak, nonatomic) IBOutlet UIButton *followBtn;
@end

@implementation TeaView

- (void)setModel:(NrRecModel *)model {
    _model = model;
    self.name.text = model.name;
    [self.teacherIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    self.title.text = model.title;
    if ([UserInfoManage sharedManager].isLogin) {
        self.followBtn.selected = model.isfollw;
    }else{
        self.followBtn.selected = NO;
    }
}


+(instancetype)teaView {
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil].lastObject;
}


- (IBAction)followTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if (self.followBtn.selected) {
            
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = NO;
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = YES;
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.nameWidth.constant = W(60, 375);
    self.followBtnWidth.constant = W(43, 375);
    self.followH.constant = H(17, 667);
    self.teacherIcon.layer.masksToBounds = YES;
    self.teacherIcon.layer.cornerRadius = self.teacherIcon.width/2;
    
}

@end
