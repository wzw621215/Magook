//
//  AdCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年  All rights reserved.
//

#import "AdCell.h"

@interface AdCell ()

@property (nonatomic,weak)UIImageView *bannerImg;

@end

@implementation AdCell

- (void)setModel:(RecommendAdModel *)model {
    _model = model;
    [self.bannerImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"DefaultImage_banner"]];
}

- (UIImageView *)bannerImg {
    if (!_bannerImg) {
        UIImageView *bannerImg = [[UIImageView alloc] init];
        [self.contentView addSubview:bannerImg];
        bannerImg.userInteractionEnabled = YES;
        [bannerImg addActionWithTarget:self action:@selector(pushVC)];
        _bannerImg = bannerImg;
    }
    return _bannerImg;
}

- (void)pushVC{
    if ([self.delegate respondsToSelector:@selector(pushWKWebView:)]) {
        [self.delegate pushWKWebView:self.model.redirectUrl];
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.bannerImg.userInteractionEnabled = YES;
    [self.bannerImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.equalTo(self.contentView);
        make.center.equalTo(self.contentView);
    }];
}

@end
