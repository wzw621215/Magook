//
//  RankCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "NRRankDetailVC.h"

@protocol RankDetailVCDelegate <NSObject>

- (void)pushDetailVC:(RankType ) rankType;

@end

@interface RankCell : BaseTableViewCell

@property (nonatomic, weak) id<RankDetailVCDelegate>delegate;

@end
