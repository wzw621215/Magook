//
//  TeacherCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@class NrRecModel;

@interface TeacherCell : BaseTableViewCell

//跳转到登录界面
@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

//push到牛人中心
@property (nonatomic,weak)id <PushNiuRenDelegate> delegate;

@property (nonatomic,strong)NSArray<NrRecModel *> *nrRecommend;

@end
