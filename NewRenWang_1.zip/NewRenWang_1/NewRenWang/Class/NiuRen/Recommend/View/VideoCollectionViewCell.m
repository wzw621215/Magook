//
//  VideoCollectionViewCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "VideoCollectionViewCell.h"

@interface VideoCollectionViewCell()

@property (weak, nonatomic) IBOutlet UIImageView *videoImg;

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *summary;
@property (weak, nonatomic) IBOutlet UILabel *num;

@end

@implementation VideoCollectionViewCell

- (void)setModel:(RecVideoModel *)model {
    _model = model;
    [self.videoImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"nr_live"]];
    self.title.text = model.title;
    self.summary.text =  model.summary;
    self.num.text = [NSString stringWithFormat:@"%ld",model.online_num];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
