//
//  VideoHeadView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryModel.h"

@protocol VideoCategoryDelegate <NSObject>

- (void)postCategoryId:(NSString *)categoryId;

@end

@interface VideoHeadView : UIView

@property (nonatomic, weak)id <VideoCategoryDelegate>delegate;

- (instancetype)initWithNSArray:(NSArray <VideoCategoryModel *>*)video;

@end
