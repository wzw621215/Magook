//
//  AdCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 . All rights reserved.
//

#import "BaseTableViewCell.h"
#import "RecModel.h"

@interface AdCell : BaseTableViewCell

@property (nonatomic, weak)id <PushWKWebViewDelegate> delegate;

@property (nonatomic, strong)RecommendAdModel *model;

@end
