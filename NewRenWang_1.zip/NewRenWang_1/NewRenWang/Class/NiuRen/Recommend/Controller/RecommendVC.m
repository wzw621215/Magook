//
//  RecommendVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RecommendVC.h"
#import "HomeSectionHeadView.h"
#import "VideoHeadView.h"
#import "AdCell.h"
#import "TeacherCell.h"
#import "RankCell.h"
#import "NiuLiveCell.h"
#import "NiuVideoCell.h"
#import "NRRankDetailVC.h"
#import "WebServesViewController.h"
#import "RecModel.h"
#import "CategoryModel.h"
#import "RecVideoRequest.h"
#import "NiuRenVC.h"
#import "SKAES.h"

@interface RecommendVC ()<RankDetailVCDelegate,PushNiuRenDelegate,PresentLoginDelegate,PushLiveDelegate,PushWKWebViewDelegate>

@property (nonatomic, weak) NiuVideoCell *niuVideoCell;

@property (nonatomic, strong)RecModel *recModel;

@property (nonatomic, strong)CategoryModel *categoryModel;

@end

@implementation RecommendVC

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self requestData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.needCellSepLine = NO;
    [self requestData];
    [self requestHeadData];
    
}

#pragma mark - 请求栏目
- (void)requestHeadData {
    BaseRequest *request = [BaseRequest requestWithUrl:kRecomCategoryAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            CategoryModel *model = [[CategoryModel alloc] mj_setKeyValues:response];
            _categoryModel = model;
        }
    }];
}

#pragma mark - 请求推荐广告和直播以及老师数据
- (void)requestData {
    BaseRequest *request = [BaseRequest requestWithUrl:kRecomAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            RecModel *model = [[RecModel alloc] mj_setKeyValues:response];
            _recModel = model;
            [self reloadData];
        }
    }];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 130;
    }else if (indexPath.section == 1){
        return 160;
    }else if (indexPath.section == 2){
        return 120;
    }else if (indexPath.section == 3){
        return  100;
    }else if (indexPath.section == 4){
        return  130;
    }else{
        return ScreenHEIGHT-153;    //153 = 导航栏：64 + tabBar：49 + 这组的组头
    }
}

- (NSInteger)numberOfSections{
    return 6;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 3) {
        return 4;
    }else{
        return 1;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section{
    if (section == 5) {
        return 0;
    }
    return 10;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 3 || section == 5) {
        return 40;
    }
    return 0;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        AdCell *cell = [AdCell cellWithTableView:self.tableView];
        cell.delegate = self;
        cell.model = self.recModel.ad.top;
        return cell;
    }else if (indexPath.section == 1){
        TeacherCell *cell = [TeacherCell cellWithTableView:self.tableView];
        cell.delegate = self;
        cell.loginDelegate = self;
        cell.nrRecommend = self.recModel.nrRecommend;
        return cell;
    }else if (indexPath.section == 2){
        RankCell *cell = [RankCell cellWithTableView:self.tableView];
        cell.delegate = self;
        return cell;
    }else if (indexPath.section == 3){
        NiuLiveCell *cell = [NiuLiveCell nibCellWithTableView:self.tableView];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.loginDelegate = self;
        cell.model = [self.recModel.live objectAtIndexCheck:indexPath.row];
        return cell;
    }else if (indexPath.section == 4){
        AdCell *cell = [AdCell cellWithTableView:self.tableView];
        cell.delegate = self;
        cell.model = self.recModel.ad.bottom;
        return cell;
    }else{
        NiuVideoCell *cell = [NiuVideoCell cellOfTableView:self.tableView indexPath:indexPath];
        self.niuVideoCell = cell;
        cell.liveDelegate = self;
        return cell;
    }
}

#pragma mark - 加载section的头部视图
- (UIView *)headerAtSection:(NSInteger)section{
    if (section == 3) {
        HomeSectionHeadView *sectionHeadView = [HomeSectionHeadView headerFooterViewWithTableView:self.tableView];
        sectionHeadView.title.text = @"正在直播";
        sectionHeadView.rightBtn.hidden = YES;
        return sectionHeadView;
    }else{
        VideoHeadView *videoHeadView = [[VideoHeadView alloc] initWithNSArray:self.categoryModel.video];
        videoHeadView.delegate = self.niuVideoCell;
        return videoHeadView;
    }
}

- (UIView *)footerAtSection:(NSInteger)section{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = kRGBColor(244,244,244);
    return view;
}



- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.tableView) {
        CGFloat offset = scrollView.contentOffset.y;
        CNLog(@"**************%lf",offset);
        [self.niuVideoCell setOffset:offset];
    }
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    if (indexPath.section == 3) {
        LiveModel *model = [self.recModel.live objectAtIndexCheck:indexPath.row];
        NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)model.ID,[UserInfoManage sharedManager].token];
        NSString *desSn = [SKAES  encryt:sn];
        NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)model.ID,desSn];
        WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
        [self.navigationController pushViewController:webViewController animated:YES];
    }
}

#pragma mark - PresentLoginDelegate
- (void)presentLogin{
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}
#pragma mark - PushNiuRenDelegate  --点击第二组老师
- (void)pushNiuRenCenter:(NSInteger)nrID {
    /*
    NiuRenVC *niurenCenterVC = [[NiuRenVC alloc] init];
    niurenCenterVC.nrID = nrID;
    [self.navigationController pushViewController:niurenCenterVC animated:YES];
     */
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)nrID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/%ld.html?sn=%@",(long)nrID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
}
#pragma mark - RankDetailVCDelegate
- (void)pushDetailVC:(RankType )rankType{
    NRRankDetailVC *rankDetailVC = [[NRRankDetailVC alloc] init];
    rankDetailVC.rankType = rankType;
    [self.navigationController pushViewController:rankDetailVC animated:YES];
}

#pragma mark - PushWKWebViewDelegate
- (void)pushWKWebView:(NSString *)bannerURL {
    WKWebViewController *web = [[WKWebViewController alloc] init];
    [web loadWebURLSring:bannerURL];
    [self.navigationController pushViewController:web animated:YES];
}

#pragma mark - PushLiveDelegate 进入直播间
- (void)pushLiveWith:(NSInteger)liveID {
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)liveID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)liveID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
