//
//  NRRankCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NRRankCell.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

@interface NRRankCell ()

@property (weak, nonatomic) IBOutlet UILabel *rank;
@property (weak, nonatomic) IBOutlet UIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *value;
@property (weak, nonatomic) IBOutlet UILabel *ability;
@property (weak, nonatomic) IBOutlet UIButton *followBtn;

@end

@implementation NRRankCell

- (void)setModel:(RecRankModel *)model {
    _model = model;
    self.rank.text = [NSString stringWithFormat:@"%ld",model.rank];
    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    self.name.text = model.name;
    self.value.text = [NSString stringWithFormat:@"%@:%ld",model.type,model.value];
    self.ability.text = [NSString stringWithFormat:@"能力圈:%@",model.ability];
    if ([UserInfoManage sharedManager].isLogin) {
        self.followBtn.selected = model.isfollw;
    }else{
        self.followBtn.selected = NO;
    }
}

- (IBAction)followTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if ([self.delegate respondsToSelector:@selector(followTeacher)]) {
            [self.delegate followTeacher];
        }
        if (self.followBtn.selected) {
            
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
                
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }

    
}

@end
