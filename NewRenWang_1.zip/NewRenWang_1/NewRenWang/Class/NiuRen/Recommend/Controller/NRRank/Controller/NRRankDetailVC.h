//
//  NRRankDetailVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//



#import "BaseTableViewController.h"

typedef NS_ENUM(NSInteger, RankType) {
    Fans,
    Strong,
    Topic
};

@interface NRRankDetailVC : BaseTableViewController

@property (nonatomic, assign)RankType rankType;

@end
