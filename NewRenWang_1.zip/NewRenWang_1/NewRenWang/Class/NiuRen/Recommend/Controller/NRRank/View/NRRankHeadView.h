//
//  NRRankHeadView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NRRankHeadView : UIView

@property (nonatomic, copy)NSString *title;

@end
