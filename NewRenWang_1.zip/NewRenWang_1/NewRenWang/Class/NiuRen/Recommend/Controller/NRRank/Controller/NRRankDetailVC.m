//
//  NRRankDetailVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NRRankDetailVC.h"
#import "NRRankHeadView.h"
#import "NRRankCell.h"
#import "RankRequest.h"
#import "RecRankModel.h"

@interface NRRankDetailVC ()<FollowDelegate,PresentLoginDelegate>

/** 接口请求参数*/
@property (nonatomic,assign)NSInteger type;
/** model属性*/
@property (nonatomic,copy)NSString *typeString;
/** 头部标题*/
@property (nonatomic,copy)NSString *headTitle;

@end

@implementation NRRankDetailVC

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self requestData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (self.rankType == Fans) {
        self.title = @"人气榜";
        self.type = 1;
        self.typeString = @"粉丝数";
        self.headTitle = @"按照牛人粉丝数排名";
        
    }else if (self.rankType == Strong){
        self.title = @"点赞榜";
        self.type = 2;
        self.typeString = @"点赞数";
        self.headTitle = @"按照牛人近一个月收获最多赞排名";
    }else{
        self.title = @"话题榜";
        self.type = 3;
        self.typeString = @"话题量";
        self.headTitle = @"按照牛人近一个月话题量排名";
    }
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.needCellSepLine = NO;
    [self requestData];
    self.refreshType = BaseTableVcRefreshTypeOnlyCanRefresh;
    [LoadingHUD show];
}

- (void)requestData {
    RankRequest *request = [[RankRequest alloc] initWithType:self.type];
    [request sendRequestWithCompletion:^(NSArray * response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            [self.dataArray removeAllObjects];
            if ([response isKindOfClass:[NSArray class]]) {
                for (int i = 0; i < response.count; i++) {
                    RecRankModel * model = [[RecRankModel alloc] mj_setKeyValues:response[i]];
                    model.rank = i+1;
                    model.type = self.typeString;
                    [self.dataArray addObject:model];
                }
            }
        }
        [self reloadData];
        [LoadingHUD dismiss];
    }];
}

- (void)refresh {
    [super refresh];
    
    [self requestData];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    return 75;
}

- (NSInteger)numberOfSections {
    return 1;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    return 50;
}

- (UIView *)headerAtSection:(NSInteger)section{
    NRRankHeadView *headView = [[NRRankHeadView alloc] init];
    headView.title = self.headTitle;
    return headView;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    NRRankCell *cell = [NRRankCell nibCellWithTableView:self.tableView];
    cell.delegate = self;
    cell.loginDelegate = self;
    cell.model = [self.dataArray objectAtIndexCheck:indexPath.row];
    return cell;
}

#pragma mark - FollowDelegate
- (void)followTeacher{
    [self requestData];
}

#pragma mark -PresentLoginDelegate
- (void)presentLogin{
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
