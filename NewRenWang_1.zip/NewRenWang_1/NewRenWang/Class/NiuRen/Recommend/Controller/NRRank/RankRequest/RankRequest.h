//
//  RankRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface RankRequest : BaseRequest

- (instancetype)initWithType:(NSInteger)type ;

@end
