//
//  NRRankCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "RecRankModel.h"
#import "TopicCell.h"

@interface NRRankCell : BaseTableViewCell

@property (nonatomic,weak)id<FollowDelegate>delegate;

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

@property (nonatomic, strong)RecRankModel *model;

@end
