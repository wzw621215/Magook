//
//  RankRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RankRequest.h"

@interface RankRequest()

/** 排行榜类型*/
@property (nonatomic, assign) NSInteger type;

@end

@implementation RankRequest

- (instancetype)initWithType:(NSInteger)type {
    if (self == [super init]) {
        _type = type;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"type":@(_type)
             };
}

- (NSString *)url {
    return kRecomRankAPI;
}
@end
