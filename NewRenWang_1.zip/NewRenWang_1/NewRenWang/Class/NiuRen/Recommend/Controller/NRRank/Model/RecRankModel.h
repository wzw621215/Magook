//
//  RecRankModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface RecRankModel : BaseModel
/** 能力圈*/
@property (nonatomic, copy)NSString *ability;
/** 图像*/
@property (nonatomic, copy)NSString *avatar;
/** 老师名字*/
@property (nonatomic, copy)NSString *name;
/** ID*/
@property (nonatomic, assign)NSInteger ID;
/** 点赞数*/
@property (nonatomic, assign)NSInteger value;
/**是否关注*/
@property (nonatomic,assign)BOOL isfollw;
/** rank*/
@property (nonatomic, assign)NSInteger rank;
/** 排行类型*/
@property (nonatomic, copy)NSString *type;

@end
