//
//  NRRankHeadView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NRRankHeadView.h"

@interface NRRankHeadView ()

@property (nonatomic, weak)UILabel *labelTitle;

@end

@implementation NRRankHeadView

- (instancetype)init{
    self = [super init];
    if (self) {
        [self createUI];
    }
    return self;
}

- (void)createUI {
    self.frame = CGRectMake(0, 0, ScreenWIDTH, 50);
    self.backgroundColor = kRGBColor(244, 244, 244);
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height-10)];
    view.backgroundColor = kWhiteColor;
    [self addSubview:view];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, (view.height-20)/2, 15, 20)];
    imageView.image = [UIImage imageNamed:@"cup"];
    [view addSubview:imageView];
    
    UILabel *title = [[UILabel alloc] init];
    title.text = @"按照牛人近一个月收获最多赞排名";
    title.font = kFont(13.0);
    title.textColor = kRGBColor(125, 125, 125);
    self.labelTitle = title;
    [view addSubview:title];
    [title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(view.mas_centerY);
        make.height.equalTo(@25);
        make.left.equalTo(imageView.mas_right).offset(10);
        make.right.equalTo(view.mas_right);
    }];
    
    UIView *line = [[UIView alloc] init];
    line.backgroundColor = kRGBColor(220, 220, 220);
    [view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@0.5);
        make.left.right.equalTo(view);
        make.bottom.equalTo(view.mas_bottom);
        
    }];
}

- (void)layoutSubviews {
    self.labelTitle.text = self.title;
}

@end
