//
//  RecVideoRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RecVideoRequest.h"
@interface RecVideoRequest()
/**第几页 默认从1开始*/
@property(nonatomic, assign)NSInteger pageIndex;
/** 视频栏目ID*/
@property (nonatomic,copy)NSString *categoryId;

@end

@implementation RecVideoRequest

- (instancetype)initWithVideoCategoryId:(NSString *)categoryId
                              pageIndex:(NSInteger)index{
    if (self == [super init]) {
        _categoryId = categoryId;
        _pageIndex = index;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"categoryId":_categoryId,
             @"pageSize":@"4",
             @"pageIndex":@(_pageIndex)
             };
}

- (NSString *)url{
    return kRecomVideoAPI;
}
@end
