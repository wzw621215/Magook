//
//  CategoryModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface CategoryModel : BaseModel

@property (nonatomic, strong)NSArray *top;

@property (nonatomic, strong)NSArray *video;

@end


@interface TopModel : BaseModel
/** 头部的顺序*/
@property (nonatomic, assign)NSInteger order;
/** 头部的categoryId*/
@property (nonatomic, assign)NSInteger categoryid;
/** 头部的category*/
@property (nonatomic, copy)NSString *category;

@end

@interface VideoCategoryModel : BaseModel
/** 头部的顺序*/
@property (nonatomic, assign)NSInteger order;
/** 头部的categoryId*/
@property (nonatomic, copy)NSString * categoryid;
/** 头部的category*/
@property (nonatomic, copy)NSString *category;

@end
