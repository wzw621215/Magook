//
//  RecoModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"
@class RecADModel,RecommendAdModel,RecUserModel;


@interface RecModel : BaseModel
/** 广告 */
@property (nonatomic, strong)RecADModel *ad;
/** 直播 */
@property (nonatomic, strong)NSArray *live;
/** 牛人推荐 */
@property (nonatomic, strong)NSArray *nrRecommend;

@end

/********************************************广告****************************/
@interface RecADModel : BaseModel

@property (nonatomic,strong)RecommendAdModel *bottom;

@property (nonatomic,strong)RecommendAdModel *top;

@end

@interface RecommendAdModel : BaseModel
/** 图片地址 */
@property (nonatomic, copy) NSString *thumb_href;
/** 标题 */
@property (nonatomic, copy) NSString *title;
/** 跳转地址 */
@property (nonatomic, copy) NSString *redirectUrl;

@end

/*********************************************直播****************************/
@interface LiveModel : BaseModel
/** ID*/
@property (nonatomic,assign)NSInteger ID;
/** nid*/
@property (nonatomic,assign)NSInteger nid;
/** 在线人数*/
@property (nonatomic,assign)NSInteger online_num;
/** 跳转地址*/
@property (nonatomic,copy)NSString *redirectUrl;
/** 正文*/
@property (nonatomic,copy)NSString *summary;
/** 图片地址*/
@property (nonatomic,copy)NSString *thumb_href;
/** 标题*/
@property (nonatomic,copy)NSString *title;
/** 用户*/
@property (nonatomic,strong)RecUserModel *user;

@end

@interface RecUserModel : NSObject

@property (nonatomic,assign)NSInteger ID;

@property (nonatomic,assign)NSInteger fans;

@property (nonatomic,copy)NSString *name;

@property (nonatomic,assign)BOOL isfollw;

@end

/*********************************************牛人推荐************************/
@interface NrRecModel : BaseModel
/** 牛人图像*/
@property (nonatomic,copy)NSString *avatar;
/** 牛人ID*/
@property (nonatomic,assign)NSInteger ID;
/** 牛人名称*/
@property (nonatomic,copy)NSString *name;
/** 牛人标题*/
@property (nonatomic,copy)NSString *title;
/**是否关注*/
@property (nonatomic,assign)BOOL isfollw;

@end














