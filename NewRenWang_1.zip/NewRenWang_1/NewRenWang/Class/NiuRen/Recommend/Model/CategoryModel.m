//
//  CategoryModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "CategoryModel.h"

@implementation CategoryModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"top":@"TopModel",
             @"video":@"VideoCategoryModel"
             };
}

@end

@implementation TopModel

@end

@implementation VideoCategoryModel

@end
