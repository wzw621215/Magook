//
//  RecVideoModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/1.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface RecVideoModel : BaseModel
/** ID*/
@property (nonatomic,assign)NSInteger ID;
/** nid*/
@property (nonatomic,assign)NSInteger nid;
/** 标题*/
@property (nonatomic,copy)NSString *title;
/** 图片地址*/
@property (nonatomic, copy) NSString *thumb_href;
/** 在线人数*/
@property (nonatomic,assign)NSInteger online_num;
/** 正文*/
@property (nonatomic,copy)NSString *summary;

@end
