//
//  RecoModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/28.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RecModel.h"

@implementation RecModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"live":@"LiveModel",
             @"nrRecommend":@"NrRecModel"
             };
}

@end

@implementation RecADModel

@end

@implementation RecommendAdModel

@end

@implementation LiveModel

@end

@implementation RecUserModel
@end

@implementation NrRecModel

@end
