//
//  OpRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/2.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpRequest.h"
@interface OpRequest()
/**第几页 默认从1开始*/
@property(nonatomic, assign)NSInteger pageIndex;
@end

@implementation OpRequest

- (instancetype)initWithpageIndex:(NSInteger)index {
    if (self == [super init]) {
        _pageIndex = index;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"pageSize":@"5",
             @"pageIndex":@(_pageIndex)
             };
}

- (NSString *)url{
    return kOpListAPI;
}

@end
