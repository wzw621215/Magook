//
//  OpStockModel.m
//  NewRenWang
//
//  Created by YJ on 17/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpStockModel.h"

@implementation OpStockModel

@end
