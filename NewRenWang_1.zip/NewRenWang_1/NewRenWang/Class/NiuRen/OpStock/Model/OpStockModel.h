//
//  OpStockModel.h
//  NewRenWang
//
//  Created by YJ on 17/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface OpStockModel : BaseModel
/** 标题 */
@property (nonatomic, copy) NSString *title;
/** 内容 */
@property (nonatomic, copy) NSString *content;
/** hit  点击 */
@property (nonatomic, copy) NSString *hit;
/** ID */
@property (nonatomic, assign)NSInteger ID;
/** 时间 */
@property (nonatomic, copy) NSString *time;
/** 高度 */
@property (nonatomic, assign) CGFloat cellHeight;

@end
