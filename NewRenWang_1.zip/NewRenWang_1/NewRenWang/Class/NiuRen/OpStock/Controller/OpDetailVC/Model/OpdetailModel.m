//
//  OpdetailModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpdetailModel.h"

@implementation OpdetailModel

@end
