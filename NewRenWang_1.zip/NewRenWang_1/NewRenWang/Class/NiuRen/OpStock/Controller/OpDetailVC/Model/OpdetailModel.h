//
//  OpdetailModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface OpdetailModel : BaseModel
/** 内容 */
@property (nonatomic, copy) NSString *content;
/** 踩 */
@property (nonatomic, assign) NSInteger down;
/** 作者*/
@property (nonatomic, copy) NSString *editor;
/** hit  点击 */
@property (nonatomic, copy) NSString *hit;
/** ID */
@property (nonatomic, assign) NSInteger ID;
/** 时间 */
@property (nonatomic, copy) NSString *time;
/** 顶 */
@property (nonatomic, assign) NSInteger up;
/** 高度 */
@property (nonatomic, assign) CGFloat cellHeight;
/** 标题 */
@property (nonatomic, copy) NSString *title;

@end
