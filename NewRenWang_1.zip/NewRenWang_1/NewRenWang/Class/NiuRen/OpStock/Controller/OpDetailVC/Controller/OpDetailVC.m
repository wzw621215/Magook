//
//  OpDetailVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpDetailVC.h"
#import "OpDetailRequest.h"
#import "OpdetailModel.h"
@interface OpDetailVC ()
@property (nonatomic, assign) NSInteger textID;
@property (nonatomic, strong)OpdetailModel *model;

/**标题*/
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
/**编辑*/
@property (weak, nonatomic) IBOutlet UILabel *editor;
/**时间*/
@property (weak, nonatomic) IBOutlet UILabel *time;
/**点击量*/
@property (weak, nonatomic) IBOutlet UILabel *hit;
/**点赞数量*/
@property (weak, nonatomic) IBOutlet UILabel *upNum;
/**点踩量*/
@property (weak, nonatomic) IBOutlet UILabel *downNum;
/**正文*/
@property (weak, nonatomic) IBOutlet UITextView *content;

@end

@implementation OpDetailVC

- (instancetype)initWithId:(NSInteger)Id{
    self = [super init];
    if (self) {
        self.textID = Id;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"操盘详情";
    [self requestData];
    [self showLoadingAnimation];
}

- (void)requestData {
    OpDetailRequest *request = [[OpDetailRequest alloc] initWithTextID:self.textID];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            OpdetailModel *model = [[OpdetailModel alloc] mj_setKeyValues:response];
            _model = model;
            [self setupUI];
        }
        [self hideLoadingAnimation];
    }];
}
- (void)setupUI {
    self.titleLabel.text = self.model.title;
    self.editor.text = [NSString stringWithFormat:@"编辑:%@",self.model.editor];
    self.time.text = self.model.time;
    self.hit.text = self.model.hit;
    self.upNum.text = [NSString stringWithFormat:@"%ld",(long)self.model.up];
    self.downNum.text = [NSString stringWithFormat:@"%ld",(long)self.model.down];
    
    NSMutableString *temp1 = [self webImageFitToDeviceSize:[self.model.content mutableCopy]];
    self.content.attributedText = [self getStringFromHTML5String:temp1];
    //   self.content.attributedText = [self getStringFromHTML5String:self.model.content];
}

- (NSAttributedString *)getStringFromHTML5String:(NSString *)htmlString {
    NSMutableAttributedString *htmlStr = [[NSMutableAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding]
                                                                                 options:@{
                                                                                           NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                      NSCharacterEncodingDocumentAttribute:
                                                                                               [NSNumber numberWithInt:NSUTF8StringEncoding],
                                                                                           }
                                                                      documentAttributes:nil error:nil];
    
    [htmlStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Arial" size:13.0] range:NSMakeRange(0, htmlStr.length)];
    [htmlStr addAttribute:NSForegroundColorAttributeName value:kRGBColor(125, 125, 125) range:NSMakeRange(0, htmlStr.length)];
    
    return htmlStr;
}
#pragma mark - 调节html中的图片大小
- (NSMutableString *)webImageFitToDeviceSize:(NSMutableString *)strContent {
    [strContent appendString:@"<html>"];
    [strContent appendString:@"<head>"];
    [strContent appendString:@"<meta charset=\"utf-8\">"];
    [strContent appendString:@"<meta id=\"viewport\" name=\"viewport\" content=\"width=device-width*0.9,initial-scale=1.0,maximum-scale=1.0,user-scalable=false\" />"];
    [strContent appendString:@"<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />"];
    [strContent appendString:@"<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\" />"];
    [strContent appendString:@"<meta name=\"black\" name=\"apple-mobile-web-app-status-bar-style\" />"];
    [strContent appendString:@"<style>img{width:35%;height:50%}</style>"];
    [strContent appendString:@"<style>table{width:100%;}</style>"];
    [strContent appendString:@"<title>webview</title>"];
    
    return strContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
