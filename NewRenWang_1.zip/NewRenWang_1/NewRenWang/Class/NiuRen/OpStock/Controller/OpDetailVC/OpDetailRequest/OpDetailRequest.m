//
//  OpDetailRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpDetailRequest.h"
@interface OpDetailRequest()

@property(nonatomic, assign)NSInteger textID;

@end

@implementation OpDetailRequest

- (instancetype)initWithTextID:(NSInteger)textID {
    if (self == [super init]) {
        _textID = textID;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"id":@(_textID)
             };
}

- (NSString *)url{
    return kOpDetailAPI;
}

@end
