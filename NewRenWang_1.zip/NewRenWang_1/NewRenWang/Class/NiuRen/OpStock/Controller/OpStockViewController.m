//
//  OpStockViewController.m
//  NewRenWang
//
//  Created by YJ on 17/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpStockViewController.h"
#import "OpStockViewCell.h"
#import "OpStockModel.h"
#import "WebServesViewController.h"
#import "OpRequest.h"
#import "OpDetailVC.h"

@interface OpStockViewController ()
/** 顶部图片 */
@property (nonatomic, weak) UIImageView *opStockHead;
/** 跳转地址*/
@property (nonatomic , copy)NSString *ad_redirectUrl;
/**第几页 默认从1开始*/
@property(nonatomic, assign)NSInteger pageIndex;

@property(nonatomic, assign)NSInteger count;

@end

@implementation OpStockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.needCellSepLine = NO;
    self.pageIndex = 1;
    
//    [self requestAdData];
    self.opStockHead.image = [UIImage imageNamed:@"opStockBanner"];
    
    
    [self requestListData];
    self.refreshType = BaseTableVcRefreshTypeRefreshAndLoadMore;
}

#pragma mark - 请求banner数据
- (void)requestAdData {
    BaseRequest *request = [BaseRequest requestWithUrl:kOpAdAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            self.ad_redirectUrl = response[@"redirectUrl"];
            [self.opStockHead sd_setImageWithURL:[NSURL URLWithString:response[@"url"]] placeholderImage:[UIImage imageNamed:@"opStockBanner"]];
        }
    }];
}

#pragma mark - 请求操盘列表数据
- (void)requestListData {
    OpRequest *reques = [[OpRequest alloc] initWithpageIndex:self.pageIndex];
    [reques sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            self.count = [response[@"count"] integerValue];
            NSArray *rows = [NSArray arrayWithArray:response[@"rows"]];
            for (NSDictionary *dic in rows) {
                OpStockModel *model = [[OpStockModel alloc] mj_setKeyValues:dic];
                if (!model.content) {
                    model.content = @"让我掉下眼泪的不止作业的酒让我依依不舍的不止你的温柔，语录还要走多久你转折欧文多饿瘦，让我感到温暖的是文旦的手，会议室深秋的修走到榆林路的尽头和我在成都的接头走一走哦哦，直到所有的灯都熄灭了都不停留弄看我的，每当我走到了公司的最后哈哈哈。丑八怪请别把灯。如果世界漆黑，其实我很美，无关痛痒的是非有什么不对";
                }
                [self.dataArray addObject:model];
            }
        }
        [self reloadData];
        [self endLoadMore];
    }];
}

- (void)refresh {
    [super refresh];
    [self.dataArray removeAllObjects];
    self.pageIndex = 1;
    [self requestListData];
}

- (void)loadMore {
    [super loadMore];
    if (self.dataArray.count >= self.count){
        [CNNavigationBarHUD showSuccess:@"数据全部加载完"];
    }else {
        self.pageIndex++;
        [self requestListData];
    }
}

- (UIImageView *)opStockHead {
    if (!_opStockHead) {
        UIImageView *header = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWIDTH, 100)];
        _opStockHead = header;
        header.userInteractionEnabled = YES;
        
        [header addActionWithTarget:self action:@selector(pushAdWebView)];
        self.tableView.tableHeaderView = self.opStockHead;
    }
    return _opStockHead;
}


- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    CNLog(@"%f",[self.dataArray[indexPath.row] cellHeight]);
    return  [self.dataArray[indexPath.row] cellHeight];
}

- (NSInteger)numberOfSections{
    return 1;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    OpStockViewCell *cell = [OpStockViewCell cellWithTableView:self.tableView];
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    OpStockModel *model = [self.dataArray objectAtIndexCheck:indexPath.row];
    OpDetailVC *optionVC = [[OpDetailVC alloc] initWithId:model.ID ];
    [self.navigationController pushViewController:optionVC animated:YES];
}


- (void)pushAdWebView {
  //  WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:self.ad_redirectUrl]];
  //  [self.navigationController pushViewController:webViewController animated:YES];
    
    WKWebViewController *web = [[WKWebViewController alloc] init];
    [web loadWebURLSring:self.ad_redirectUrl];
    [self.navigationController pushViewController:web animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
