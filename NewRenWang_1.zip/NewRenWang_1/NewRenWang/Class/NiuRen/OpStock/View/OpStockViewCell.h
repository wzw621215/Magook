//
//  OpStockViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@class OpStockModel;
@interface OpStockViewCell : BaseTableViewCell
/** model */
@property (nonatomic, strong) OpStockModel *model;

@end
