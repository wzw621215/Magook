//
//  OpStockViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/2/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "OpStockViewCell.h"
#import "OpStockModel.h"
@interface OpStockViewCell ()
/** 标题 */
@property (nonatomic, weak) UILabel *title;
/** 内容 */
@property (nonatomic, weak) UILabel *content;
/** 线 */
@property (nonatomic, weak) UILabel *line;
/** 浏览量 */
@property (nonatomic, weak) UILabel *allPageView;
/** 浏览图片 */
@property (nonatomic, weak) UIImageView *pageViewImage;
/** 时间 */
@property (nonatomic, weak) UILabel *time;
/** 时间图片 */
@property (nonatomic, weak) UIImageView *timeImage;

@end

@implementation OpStockViewCell


- (UILabel *)title {
    if (!_title) {
        UILabel *title = [[UILabel alloc] init];
        [self.contentView addSubview:title];
        _title = title;
        title.numberOfLines = 0;
        title.textColor = kBlackColor;
        title.font = kFont(14);
        title.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _title;
}

- (UILabel *)content {
    if (!_content) {
        UILabel *content = [[UILabel alloc] init];
        [self.contentView addSubview:content];
        _content = content;
        content.numberOfLines = 0;
        content.textColor = [UIColor colorWithHexString:@"#999999"];;
        content.font = kFont(12);
    }
    return _content;
}

- (UILabel *)line {
    if (!_line) {
        UILabel *line = [[UILabel alloc] init];
        [self.contentView addSubview:line];
        _line = line;
        line.backgroundColor = kRGBColor(225, 225, 225);
    }
    return _line;
}

- (UILabel *)allPageView {
    if (!_allPageView) {
        UILabel *allPageView = [[UILabel alloc] init];
        [self.contentView addSubview:allPageView];
        _allPageView = allPageView;
        allPageView.textColor = [UIColor colorWithHexString:@"#999999"];
        allPageView.font = kFont(12);
        allPageView.text = @"27421";
    }
    return _allPageView;
}

- (UIImageView *)pageViewImage {
    if (!_pageViewImage) {
        UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pageView"]];
        [self.contentView addSubview:image];
        _pageViewImage = image;
        image.contentMode = UIViewContentModeScaleAspectFit;
                              
    }
    return _pageViewImage;
}

- (UIImageView *)timeImage {
    if (!_timeImage) {
        UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"OpSotcktime"]];
        [self.contentView addSubview:image];
        _timeImage = image;
        image.contentMode = UIViewContentModeScaleAspectFit;
        
    }
    return _timeImage;
}

- (UILabel *)time {
    if (!_time) {
        UILabel *time = [[UILabel alloc] init];
        [self.contentView addSubview:time];
        _time = time;
        time.textColor = [UIColor colorWithHexString:@"#999999"];
        time.font = kFont(12);
    }
    return _time;
}

- (void)setModel:(OpStockModel *)model {
    _model = model;
    self.title.text = model.title;
//    self.content.text =  model.content;
    self.time.text = model.time;//[Utils updateTimeForTimeInterval:1487396358];
    self.allPageView.text = model.hit;
    //计算高度
    CGFloat titleHeigth = [model.title boundingRectWithSize:CGSizeMake(ScreenWIDTH - 20, CGFLOAT_MAX) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil].size.height;
    
    NSArray *array = [model.content componentsSeparatedByString:@"</p>"];
    NSString *contentStr = [array[1] stringByAppendingString:@"</p>"];
    
    NSMutableString *temp1 = [self webImageFitToDeviceSize:[contentStr mutableCopy]];
    
    NSMutableAttributedString *contentAtt = [self getStringFromHTML5String:temp1];
    self.content.attributedText = contentAtt;
    
    /*计算高度*/
    YYTextLayout *contentLayout = [YYTextLayout layoutWithContainerSize:CGSizeMake(ScreenWIDTH - 20, CGFLOAT_MAX) text:contentAtt];
    self.content.height = contentLayout.textBoundingSize.height;
    
    _model.cellHeight = titleHeigth + self.content.height + 125;
}



- (NSMutableAttributedString *)getStringFromHTML5String:(NSString *)htmlString {
    NSMutableAttributedString *htmlStr = [[NSMutableAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding]
                                                                                 options:@{
                                                                                           NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                           NSCharacterEncodingDocumentAttribute:
                                                                                               [NSNumber numberWithInt:NSUTF8StringEncoding],
                                                                                           }
                                                                      documentAttributes:nil error:nil];
    htmlStr.yy_color = kRGBColor(125, 125, 125);
    htmlStr.yy_lineSpacing = 5;
    htmlStr.yy_font = kFont(12);
    return htmlStr;
}

#pragma mark - 调节html中的图片大小
- (NSMutableString *)webImageFitToDeviceSize:(NSMutableString *)strContent {
    [strContent appendString:@"<html>"];
    [strContent appendString:@"<head>"];
    [strContent appendString:@"<meta charset=\"utf-8\">"];
    [strContent appendString:@"<meta id=\"viewport\" name=\"viewport\" content=\"width=device-width*0.9,initial-scale=1.0,maximum-scale=1.0,user-scalable=false\" />"];
    [strContent appendString:@"<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />"];
    [strContent appendString:@"<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\" />"];
    [strContent appendString:@"<meta name=\"black\" name=\"apple-mobile-web-app-status-bar-style\" />"];
    [strContent appendString:@"<style>img{width:35%;height:10%}</style>"];
    [strContent appendString:@"<style>table{width:100%;}</style>"];
    [strContent appendString:@"<title>webview</title>"];
    
    return strContent;
}


- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(15);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
    }];
    
    [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.title.mas_bottom).offset(15);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.content.mas_bottom).offset(10);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@(kLineHeight));
    }];
    
    [self.allPageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.line.mas_bottom).offset(15);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@(14));

    }];
    
    [self.pageViewImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.allPageView.mas_centerY);
        make.right.equalTo(self.allPageView.mas_left).offset(-3);
        make.height.width.equalTo(@(20));
    }];
    
    [self.timeImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.pageViewImage.mas_centerY);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.height.width.equalTo(@(15));
    }];
    
    [self.time mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.timeImage.mas_centerY);
        make.left.equalTo(self.timeImage.mas_right).offset(3);
        make.height.equalTo(@(14));
    }];
    
}

-(void)setFrame:(CGRect)frame
{
    frame.size.height -= 10;
    frame.origin.y += 10;
    [super setFrame:frame];
    
}
@end
