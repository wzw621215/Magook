//
//  TopicRequsetModel.m
//  NewRenWang
//
//  Created by YJ on 17/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicRequsetModel.h"

@interface TopicRequsetModel ()
/**  0：热门话题  1：全部话题 */
@property (nonatomic, assign) NSInteger topictype;
/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;
@end
@implementation TopicRequsetModel

- (instancetype)initWithTopictype:(NSInteger)topictype
                      pageIndex:(NSInteger)index {
    if (self == [super init]) {
        _topictype = topictype;
        _pageIndex = index;
    }
    return self;
}

- (NSDictionary *)params {
    return _topictype ? @{
                        @"topictype":@(_topictype),
                        @"pageSize":@"5",
                        @"pageIndex":@(_pageIndex)
                        }  : @{
                              @"pageSize":@"5",
                              @"pageIndex":@(_pageIndex)
                              };
}
- (NSString *)url {
    return kTopicListAPI;
}
@end
