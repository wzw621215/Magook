//
//  TopicRequsetModel.h
//  NewRenWang
//
//  Created by YJ on 17/2/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface TopicRequsetModel : BaseRequest

- (instancetype)initWithTopictype:(NSInteger)topictype
                        pageIndex:(NSInteger)index;

@end
