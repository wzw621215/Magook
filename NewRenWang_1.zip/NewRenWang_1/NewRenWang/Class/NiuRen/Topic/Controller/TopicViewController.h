//
//  TopicViewController.h
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface TopicViewController : BaseTableViewController

@end
