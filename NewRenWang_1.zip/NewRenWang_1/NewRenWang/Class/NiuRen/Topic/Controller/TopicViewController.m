//
//  TopicViewController.m
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicViewController.h"
#import "FilterViewCell.h"
#import "NRTeacherViewCell.h"
#import "TopicSegmentView.h"
#import "TopicViewCell.h"
#import "TopicRequsetModel.h"
#import "TopicModel.h"
#import "TopicListModel.h"
#import "WebServesViewController.h"
#import "TopicListViewController.h"
#import "NiuRenVC.h"


#import <UShareUI/UShareUI.h>
#import <UMSocialCore/UMSocialCore.h>
#import "UMShareTypeViewController.h"
@interface TopicViewController ()<TopicTagDelegate,PushNiuRenDelegate,FollowDelegate,PresentLoginDelegate,ShareDelegate,UMSocialShareMenuViewDelegate>
/** 顶部图片 */
@property (nonatomic, weak) UIImageView *topicHeadImg;
/** 筛选高度 */
@property (nonatomic, assign) CGFloat filterHelght;
/** AD */
@property (nonatomic, strong) TopicModel *topicModel;
/**  0：热门话题  1：全部话题 */
@property (nonatomic, assign) NSInteger topicType;
/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;
@end

@implementation TopicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //设置用户自定义平台
    [UMSocialUIManager setPreDefinePlatforms:@[@(UMSocialPlatformType_WechatSession),
                                               @(UMSocialPlatformType_WechatTimeLine),
                                               @(UMSocialPlatformType_WechatFavorite),
                                               @(UMSocialPlatformType_QQ),
                                               @(UMSocialPlatformType_Qzone),
                                               @(UMSocialPlatformType_Sina)
                                               ]];
    //设置分享面板的显示和隐藏的代理回调
    [UMSocialUIManager setShareMenuViewDelegate:self];
    
    self.needCellSepLine = NO;
    
    self.pageIndex = 1;
    [self requestTopicData];
    [self requestTopicListData];
    self.refreshType = BaseTableVcRefreshTypeRefreshAndLoadMore;
    
}

#pragma mark - 请求数据话题前三个：广告、标签、老师
- (void)requestTopicData {
    //请求标签和牛人数据
    BaseRequest *request = [BaseRequest requestWithUrl:kTopicAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            TopicModel *topicModel = [[TopicModel alloc] mj_setKeyValues:response];
            _topicModel = topicModel;
            //AD图片
            [self.topicHeadImg sd_setImageWithURL:[NSURL URLWithString:self.topicModel.ad.thumb_href] placeholderImage: [UIImage imageNamed:@"TopicBanner"]];
         [self reloadData];
        }
    }];
}

#pragma mark - 请求TopicList  :全部话题和热门话题
- (void)requestTopicListData {
    //请求话题列表数据
    TopicRequsetModel *topicRequest = [[TopicRequsetModel alloc] initWithTopictype:self.topicType
                                                                       pageIndex:self.pageIndex];
    [topicRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            NSArray *listData = [NSArray arrayWithArray:response[@"rows"]];
            for (int i = 0; i < listData.count; i++) {
                TopicListModel *model = [[TopicListModel alloc] mj_setKeyValues:listData[i]];
                [self.dataArray addObject:model];
            }
        }
        [self reloadData];
        [self endLoadMore];
    }];
}

- (void)refresh {
    [super refresh];
    [self.dataArray removeAllObjects];
    self.pageIndex = 1;
    [self requestTopicListData];
}

- (void)loadMore {
    [super loadMore];
    self.pageIndex++;
    [self requestTopicListData];
}

#pragma mark - 广告头部
- (UIImageView *)topicHeadImg {
    if (!_topicHeadImg) {
        UIImageView *header = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, ScreenWIDTH, 130)];
        _topicHeadImg = header;
        header.userInteractionEnabled = YES;
        header.contentMode = UIViewContentModeScaleAspectFill;
        header.clipsToBounds = YES;
        [header addActionWithTarget:self action:@selector(pushWebView)];
        self.tableView.tableHeaderView = header;
    }
    return _topicHeadImg;
}



- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return self.filterHelght;
    } else if (indexPath.section == 1) {
        return  100;
    } else {
        return self.dataArray.count ? [self.dataArray[indexPath.row] cellHeight] : 0;
    }
}

- (NSInteger)numberOfSections{
    return 3;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    if (section == 2) {
        return self.dataArray.count;
    } else {
        return 1;
    }
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0.01;
    } else if (section == 1){
        return 10;
    } else {
        return 40;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    if (section == 1) {
        return 10;
    } else {
        return 0.1;
    }
}

- (UIView *)headerAtSection:(NSInteger)section {
    if (section == 2) {
        TopicSegmentView *segment = [TopicSegmentView headerFooterViewWithTableView:self.tableView];
        [segment setSegmentViewBtnClickHandle:^(TopicSegmentView *segment, NSInteger currentIndex) {
            self.topicType = currentIndex;
            [self refresh];
        }];
        return segment;
    }
    return nil;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        FilterViewCell *cell = [FilterViewCell cellWithTableView:self.tableView];
        cell.tags = self.topicModel.tags;
        
        self.filterHelght = cell.filterHelght;
        cell.delegate = self;
        [cell setExpandBlock:^{
            [self.tableView reloadData];
        }];
        return cell;

    } else if (indexPath.section == 1) {
        NRTeacherViewCell *cell = [NRTeacherViewCell cellWithTableView:self.tableView];
        cell.NRCenterDelegate = self;
        cell.followDelegate = self;
        cell.loginDelegate = self;
        cell.NRData = self.topicModel.topic;
        return cell;
        
    } else {
        TopicViewCell *cell = [TopicViewCell cellWithTableView:self.tableView];
        cell.loginDelegate = self;
        cell.shareDelegate = self;
        cell.NRDelegate = self;
        if (self.dataArray.count) {
          cell.model = self.dataArray[indexPath.row];
        }
        return cell;
    }
}

#pragma mark -FollowDelegate
- (void)followTeacher {
    [self requestTopicData];
}
#pragma mark -PresentLoginDelegate
- (void)presentLogin{
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}

#pragma mark - PushNiuRenDelegate push到牛人中心
- (void)pushNiuRenCenter:(NSInteger)nrID{
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)nrID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/%ld.html?sn=%@",(long)nrID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
    
    /*
    NiuRenVC *niurenCenterVC = [[NiuRenVC alloc] init];
    niurenCenterVC.nrID = nrID;
    [self.navigationController pushViewController:niurenCenterVC animated:YES];
     */
}

#pragma mark - TopicTagDelegate  进入话题列表页
- (void)clickTagTopicList:(NSInteger)tagId withTag:(NSString *)tagStr{
    TopicListViewController *listVC = [[TopicListViewController alloc] init];
    listVC.topicId = tagId;
    listVC.tagStr = tagStr;
    [self.navigationController pushViewController:listVC animated:YES];
}

#pragma mark - 广告页跳转
- (void)pushWebView{
    WKWebViewController *web = [[WKWebViewController alloc] init];
    [web loadWebURLSring:self.topicModel.ad.redirectUrl];
    [self.navigationController pushViewController:web animated:YES];
}

#pragma mark - 分享
- (void)share:(NSString *)shareContent {
    [UMSocialShareUIConfig shareInstance].sharePageGroupViewConfig.sharePageGroupViewPostionType = UMSocialSharePageGroupViewPositionType_Bottom;
    [UMSocialShareUIConfig shareInstance].sharePageScrollViewConfig.shareScrollViewPageItemStyleType = UMSocialPlatformItemViewBackgroudType_None;
    [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMSocialPlatformType platformType, NSDictionary *userInfo) {
        //在回掉里面获得点击的
        
       // [self shareTextToPlatformType:platformType withShareContent:shareContent];
        
        //想要分享内容更丰富请使用UMShareTyoeViewController
        UMShareTypeViewController *VC = [[UMShareTypeViewController alloc] initWithType:platformType withShareContent:shareContent];
        [self.navigationController pushViewController:VC animated:YES];
    }];
}

//分享文本
- (void)shareTextToPlatformType:(UMSocialPlatformType)platformType withShareContent:(NSString *)shareContent
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    //设置文本
    messageObject.text =  shareContent;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
        
        if (error) {
            UMSocialLogInfo(@"分享错误：%@",error);
        }else{
            if ([data isKindOfClass:[UMSocialShareResponse class]]) {
                UMSocialShareResponse *resp = data;
                //分享结果消息
                UMSocialLogInfo(@"response message is %@",resp.message);
                //第三方原始返回的数据
                UMSocialLogInfo(@"response originalResponse data is %@",resp.originalResponse);
                
            }else{
                UMSocialLogInfo(@"response data is %@",data);
            }
        }
        [self alertWithError:error];
    }];
}

- (void)alertWithError:(NSError *)error
{
    NSString *result = nil;
    if (!error) {
        result = [NSString stringWithFormat:@"Share succeed"];
    }
    else{
        NSMutableString *str = [NSMutableString string];
        if (error.userInfo) {
            for (NSString *key in error.userInfo) {
                [str appendFormat:@"%@ = %@\n", key, error.userInfo[key]];
            }
        }
        if (error) {
            result = [NSString stringWithFormat:@"Share fail with error code: %d\n%@",(int)error.code, str];
        }
        else{
            result = [NSString stringWithFormat:@"Share fail"];
        }
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"分享"
                                                    message:result
                                                   delegate:nil
                                          cancelButtonTitle:NSLocalizedString(@"确定", @"确定")
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
