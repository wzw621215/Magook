//
//  TopicListRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicListRequest.h"
@interface TopicListRequest ()

@property (nonatomic, assign) NSInteger topicId;
/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;

@end

@implementation TopicListRequest

- (instancetype)initWithTopicId:(NSInteger)topicId
                      pageIndex:(NSInteger)index{
    if (self == [super init]) {
        _topicId = topicId;
        _pageIndex = index;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"topicId":@(_topicId),
             @"pageSize":@"10",
             @"pageIndex":@(_pageIndex)
             };
}
- (NSString *)url {
    return kTagsListAPI;
}

@end
