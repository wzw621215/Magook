//
//  TopicListViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicListViewController.h"
#import "TopicListRequest.h"
#import "TopicListModel.h"
#import "TopicViewCell.h"
#import "NiuRenVC.h"
#import <UShareUI/UShareUI.h>
#import <UMSocialCore/UMSocialCore.h>
#import "UMShareTypeViewController.h"

@interface TopicListViewController ()<PresentLoginDelegate,PushNiuRenDelegate,ShareDelegate>

/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;

@end

@implementation TopicListViewController

- (void)viewWillAppear:(BOOL)animated {
    [self refresh];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.tagStr;
    self.needCellSepLine = NO;
    [self showLoadingAnimation];
    self.pageIndex = 1;
    self.refreshType = BaseTableVcRefreshTypeRefreshAndLoadMore;
}

- (void) requestTopicList{
    TopicListRequest *tagRequest = [[TopicListRequest alloc] initWithTopicId:self.topicId pageIndex:self.pageIndex];
    [tagRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            NSArray *listData = [NSArray arrayWithArray:response[@"rows"]];
            for (int i = 0; i < listData.count; i++) {
                TopicListModel *model = [[TopicListModel alloc] mj_setKeyValues:listData[i]];
                [self.dataArray addObject:model];
            }
        }
        [self reloadData];
        [self endLoadMore];
        [self hideLoadingAnimation];
    }];
}

- (void)refresh {
    [super refresh];
    [self.dataArray removeAllObjects];
    self.pageIndex = 1;
    [self requestTopicList];
}

- (void)loadMore {
    [super loadMore];
    self.pageIndex++;
    [self requestTopicList];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
        return self.dataArray.count ? [self.dataArray[indexPath.row] cellHeight] : 0;
}

- (NSInteger)numberOfSections{
    return 1;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    TopicViewCell *cell = [TopicViewCell cellWithTableView:self.tableView];
    cell.shareDelegate = self;
    cell.NRDelegate = self;
    cell.loginDelegate = self;
    if (self.dataArray.count) {
        cell.model = self.dataArray[indexPath.row];
    }
    return cell;
}

#pragma mark - ShareDelegate 分享
- (void)share:(NSString *)shareContent {
    [UMSocialShareUIConfig shareInstance].sharePageGroupViewConfig.sharePageGroupViewPostionType = UMSocialSharePageGroupViewPositionType_Bottom;
    [UMSocialShareUIConfig shareInstance].sharePageScrollViewConfig.shareScrollViewPageItemStyleType = UMSocialPlatformItemViewBackgroudType_None;
    [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMSocialPlatformType platformType, NSDictionary *userInfo) {
        //在回掉里面获得点击的
        
        // [self shareTextToPlatformType:platformType withShareContent:shareContent];
        
        //想要分享内容更丰富请使用UMShareTyoeViewController
        UMShareTypeViewController *VC = [[UMShareTypeViewController alloc] initWithType:platformType withShareContent:shareContent];
        [self.navigationController pushViewController:VC animated:YES];
    }];
}


#pragma mark - PushNiuRenDelegate push到牛人中心
- (void)pushNiuRenCenter:(NSInteger)nrID{
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)nrID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/%ld.html?sn=%@",(long)nrID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
    
    /*
    NiuRenVC *niurenCenterVC = [[NiuRenVC alloc] init];
    niurenCenterVC.nrID = nrID;
    [self.navigationController pushViewController:niurenCenterVC animated:YES];
     */
}

#pragma mark -PresentLoginDelegate
- (void)presentLogin{
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
