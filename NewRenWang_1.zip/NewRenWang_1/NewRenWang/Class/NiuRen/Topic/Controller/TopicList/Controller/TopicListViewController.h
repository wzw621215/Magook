//
//  TopicListViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface TopicListViewController : BaseTableViewController

/**  标签类型ID   只有当时点击上面的标签才用这个参数 */
@property (nonatomic, assign) NSInteger topicId;

/** tag*/
@property (nonatomic,copy)NSString *tagStr;

@end
