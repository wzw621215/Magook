//
//  TopicViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicViewCell.h"
#import "TopicListModel.h"
#import "TopicModel.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"
#import "UpRequest.h"
#import "DownRequest.h"

@interface TopicViewCell ()
/** 线 */
@property (nonatomic, weak) UILabel *line;
/** 标签和时间 */
@property (nonatomic, weak) YYLabel *labelTime;
/** 分享 */
@property (nonatomic, weak) UIButton *share;
/** 内容 */
@property (nonatomic, weak) UILabel *contentLabel;
/** 头像 */
@property (nonatomic, weak) UIImageView *headImage;
/** 名字 */
@property (nonatomic, weak) UILabel *name;
/** 粉丝 */
@property (nonatomic, weak) UIButton *fans;
/** 赞 */
@property (nonatomic, weak) UIButton *praise;
/** 踩 */
@property (nonatomic, weak) UIButton *trample;
/** 关注 */
@property (nonatomic, weak) UIButton *concern;

@end
@implementation TopicViewCell

- (UILabel *)line {
    if (!_line) {
        UILabel *line = [[UILabel alloc] init];
        line.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;
}

- (YYLabel *)labelTime {
    if (!_labelTime) {
        YYLabel *label = [[YYLabel alloc] init];
        [self.contentView addSubview:label];
        _labelTime = label;
        label.font = kFont(15);
      
       
    }
    return _labelTime;
}

- (UIButton *)share {
    if (!_share) {
        UIButton *share = [[UIButton alloc] init];
        [self.contentView addSubview:share];
        _share = share;
        share.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [share setBackgroundImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
        [share addTarget:self action:@selector(share:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _share;
}

- (UILabel *)contentLabel {
    if (!_contentLabel) {
        UILabel *content = [[UILabel alloc] init];
        [self.contentView addSubview:content];
        _contentLabel = content;
        content.numberOfLines = 3;
        content.font = kFont(13);
       
    }
    return _contentLabel;
}

- (UIImageView *)headImage {
    if (!_headImage) {
        UIImageView *headImg = [[UIImageView alloc] init];
        headImg.image = [UIImage imageNamed:@"me_icon"];
        headImg.userInteractionEnabled = YES;
        [headImg addActionWithTarget:self action:@selector(pushNiuRen)];
        [self.contentView addSubview:headImg];
        _headImage = headImg;
        headImg.layerCornerRadius = 15;
    }
    return _headImage;
}



- (UILabel *)name {
    if (!_name) {
        UILabel *name = [[UILabel alloc] init];
        [self.contentView addSubview:name];
        _name = name;
        name.font = kFont(13);
        name.textColor = kRGBColor(125, 125, 125);
        name.text =@"张成";

    }
    return _name;
}

#pragma mark - 赞
- (UIButton *)praise {
    if (!_praise) {
        UIButton *praise = [[UIButton alloc] init];
        [self.contentView addSubview:praise];
        _praise = praise;
        [praise setImage:[UIImage imageNamed:@"strong"] forState:UIControlStateNormal];
        [praise setImage:[UIImage imageNamed:@"strong_sel"] forState:UIControlStateSelected];
        [praise setTitle:@" 0" forState:UIControlStateNormal];
        [praise setTitleColor:kRGBColor(125, 125, 125) forState:UIControlStateNormal];
        praise.titleLabel.font = kFont(13);
        [praise addTarget:self action:@selector(up:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _praise;
}

#pragma mark - 踩
- (UIButton *)trample {
    if (!_trample) {
        UIButton *trample = [[UIButton alloc] init];
        [self.contentView addSubview:trample];
        _trample = trample;
        [trample setImage:[UIImage imageNamed:@"weak"] forState:UIControlStateNormal];
        [trample setImage:[UIImage imageNamed:@"weak_sel"] forState:UIControlStateSelected];
        [trample setTitle:@" 0" forState:UIControlStateNormal];
        [trample setTitleColor:kRGBColor(125, 125, 125) forState:UIControlStateNormal];
        trample.titleLabel.font = kFont(12);
        [trample addTarget:self action:@selector(down:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _trample;
}

#pragma mark - 粉丝数
- (UIButton *)fans {
    if (!_fans) {
        UIButton *fans = [[UIButton alloc] init];
        [self.contentView addSubview:fans];
        _fans = fans;
        [fans setImage:[UIImage imageNamed:@"fans"] forState:UIControlStateNormal];
        [fans setTitle:@" 0" forState:UIControlStateNormal];
        [fans setTitleColor:kRGBColor(125, 125, 125) forState:UIControlStateNormal];
        fans.titleLabel.font = kFont(12);
    }
    return _fans;
}

#pragma mark - 关注
- (UIButton *)concern {
    if (!_concern) {
        UIButton *concern = [[UIButton alloc] init];
        [self.contentView addSubview:concern];
        _concern = concern;
        concern.titleLabel.font = kFont(12);
        [concern setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateNormal];
        [concern setTitle:@"+关注" forState:UIControlStateNormal];
        [concern setTitleColor:kOrangeColor forState:UIControlStateNormal];
        [concern setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateSelected];
        [concern setTitle:@"已关注" forState:UIControlStateSelected];
        [concern setTitleColor:kOrangeColor forState:UIControlStateSelected];
        [concern addTarget:self action:@selector(followTeacher:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _concern;
}

#pragma mark - push到牛人中心
- (void)pushNiuRen{
    if ([self.NRDelegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        [self.NRDelegate pushNiuRenCenter:self.model.user.ID];
    }
}

#pragma mark - 点赞
- (void)up:(UIButton *)button{
    if ([UserInfoManage sharedManager].isLogin) {
        UpRequest *request = [[UpRequest alloc] initWithType:1 targetid:self.model.ID];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                self.praise.selected = !self.praise.selected;
                self.model.isup = self.praise.selected;
                self.model.up = [response[@"up"] integerValue];
                [self.praise setTitle:[NSString stringWithFormat:@"%@",response[@"up"]] forState:UIControlStateNormal];
                [self.trample setTitle:[NSString stringWithFormat:@"%@",response[@"down"]] forState:UIControlStateNormal];
            }else{
                [CNNavigationBarHUD showError:message];
            }
        }];
    }else{
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }

}
#pragma mark - 点踩
- (void)down:(UIButton *)button{
    if ([UserInfoManage sharedManager].isLogin) {
        DownRequest *request = [[DownRequest alloc] initWithType:1 targetid:self.model.ID];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                self.trample.selected = !self.trample.selected;
                self.model.isdown = self.trample.selected;
                self.model.down = [response[@"down"] integerValue];
                [self.praise setTitle:[NSString stringWithFormat:@"%@",response[@"up"]] forState:UIControlStateNormal];
                [self.trample setTitle:[NSString stringWithFormat:@"%@",response[@"down"]] forState:UIControlStateNormal];
            }else{
                [CNNavigationBarHUD showError:message];
            }
        }];
    }else{
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }

}

#pragma mark - 关注按钮点击事件
- (void)followTeacher:(UIButton *)button {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if (self.concern.selected) {
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.concern.selected = NO;
                    self.model.user.isfollw = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.concern.selected = YES;
                    self.model.user.isfollw = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
    
}

#pragma mark - 分享
- (void)share:(id)sender {
    if ([self.shareDelegate respondsToSelector:@selector(share:)]) {
        [self.shareDelegate share:self.model.content];
    }
}

- (void)setModel:(TopicListModel *)model {
    
    _model = model;
    
    //标签 时间
    if (model.type == nil) model.type = kEmptyStr;
    NSMutableAttributedString *textAtt = [NSMutableAttributedString new];
    
    UIImage *stateImage = [UIImage imageNamed:@"OpSotcktime"];
    [textAtt yy_appendString:[NSString stringWithFormat:@"#%@#  ",model.type]];
    [textAtt appendAttributedString:[NSMutableAttributedString yy_attachmentStringWithContent:stateImage contentMode:UIViewContentModeCenter attachmentSize:stateImage.size alignToFont:[UIFont systemFontOfSize:15.0f] alignment:YYTextVerticalAlignmentCenter]];
    [textAtt yy_appendString:[NSString stringWithFormat:@"  %@",model.time]];
    textAtt.yy_color = kRGBColor(125, 125, 125);
    [textAtt yy_setTextHighlightRange:[textAtt.string rangeOfString:[NSString stringWithFormat:@"#%@#",model.type]] color:kOrangeColor backgroundColor:[UIColor colorWithHexString:@"#999999"] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        //点击
        
    }];
    self.labelTime.attributedText = textAtt;
    
    //内容
    NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithString:model.content];
    NSMutableParagraphStyle * paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:5];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [model.content length])];
    [self.contentLabel setAttributedText:attributedString];
     self.contentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    
    //头像
    [self.headImage sd_setImageWithURL:[NSURL URLWithString:model.user.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    
    //名字
    self.name.text = model.user.name;
    
    //粉丝数
    [self.fans setTitle:[NSString stringWithFormat:@" %@",model.user.fans] forState:UIControlStateNormal];
    
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        [self.praise setTitle:[NSString stringWithFormat:@"%ld",(long)model.up] forState:UIControlStateNormal];
        [self.trample setTitle:[NSString stringWithFormat:@"%ld",(long)model.down] forState:UIControlStateNormal];

        self.praise.selected = model.isup;
        self.trample.selected = model.isdown;
        self.concern.selected = model.user.isfollw;
    }else{
        //未登录
        [self.praise setTitle:[NSString stringWithFormat:@"%ld",(long)model.up] forState:UIControlStateNormal];
        [self.trample setTitle:[NSString stringWithFormat:@"%ld",(long)model.down] forState:UIControlStateNormal];
        self.praise.selected = NO;
        self.trample.selected = NO;
        self.concern.selected = NO;
    }
    
    //计算内容高度
    CGFloat contentHeight = [model.content boundingRectWithSize:CGSizeMake(ScreenWIDTH - 20, CGFLOAT_MAX) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13],NSParagraphStyleAttributeName:paragraphStyle} context:nil].size.height;
    //超过3行 就按3行计算
    _model.cellHeight = 95 + (contentHeight > 70 ? 70 : contentHeight);
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(0);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@(1));
    }];
    
    [self.share mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.line.mas_bottom).offset(15);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@(15));
        make.width.equalTo(@(15));
    }];
    
    [self.labelTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.share.mas_centerY);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.share.mas_left).offset(-10);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.labelTime.mas_bottom).offset(15);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
    }];
    
    [self.headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.mas_bottom).offset(10);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.height.equalTo(@30);
        make.width.equalTo(@30);
    }];
    
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
         make.centerY.equalTo(self.headImage.mas_centerY);
         make.left.equalTo(self.headImage.mas_right).offset(8);
    }];
    
    [self.fans mas_makeConstraints:^(MASConstraintMaker *make) {
         make.centerY.equalTo(self.name.mas_centerY);
         make.left.equalTo(self.name.mas_right).offset(5);
    }];
    
    [self.concern mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.name.mas_centerY);
        make.left.equalTo(self.fans.mas_right).offset(10);
        make.height.equalTo(@20);
        make.width.equalTo(@50);
    }];
    
    [self.trample mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.name.mas_centerY);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
    }];
    
    [self.praise mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.trample.mas_centerY);
        make.right.equalTo(self.trample.mas_left).offset(-10);

    }];
}
@end
