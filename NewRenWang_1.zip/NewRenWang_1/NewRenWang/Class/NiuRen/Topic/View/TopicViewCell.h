//
//  TopicViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "TopicCell.h"
@protocol ShareDelegate<NSObject>

- (void)share:(NSString *)shareContent;

@end

@class TopicListModel;
@interface TopicViewCell : BaseTableViewCell

@property(nonatomic,weak)id<PushNiuRenDelegate>NRDelegate;

@property (nonatomic,weak)id<ShareDelegate>shareDelegate;

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

/** model */
@property (nonatomic, strong) TopicListModel *model;

@end
