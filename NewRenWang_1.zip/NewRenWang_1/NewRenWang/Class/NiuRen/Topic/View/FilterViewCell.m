//
//  FilterViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "FilterViewCell.h"
#import "TopicModel.h"
@interface FilterViewCell ()
/** btn选择状态*/
@property (nonatomic, assign) BOOL selectState;
/** 原始数据 */
@property (nonatomic, strong) NSArray *tagsData;

@end
@implementation FilterViewCell

- (void)prepareForReuse {
    [super prepareForReuse];
    [self.contentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}


- (void)setTags:(NSArray <TopicTagsModel *>*)tags {
    NSMutableArray *filterArr = tags.mutableCopy;
    self.tagsData = [NSArray arrayWithArray:tags];
    //第一次进来 默认YES
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        self.selectState = YES;
    });
    //间隙
    int margin = 10;
    if (self.selectState && [tags count] > 8) {
        [filterArr removeObjectsInRange:NSMakeRange(8, [tags count]-8)];
    }
    //宽
    CGFloat width = (ScreenWIDTH - margin * 5) / 4;
    for (int i = 0; i < filterArr.count; i++) {
        int row = i/4;//行
        int col = i%4 ;//列
        UIButton *btn = [[UIButton alloc] init];
        btn.frame =  CGRectMake(10+col*(width+margin), 15+row*(30+15), width, 30);
        [btn setTitle:[filterArr[i]text] forState:UIControlStateNormal];
        btn.titleLabel.font = kFont(14);
        btn.tag = i;
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(pushTopicList:) forControlEvents:UIControlEventTouchUpInside];
        btn.layerCornerRadius = 5.0;
        [btn setLayerBorderWidth:1.0];
        [btn setLayerBorderColor:[UIColor colorWithHexString:@"#999999"]];
        [self.contentView addSubview:btn];
        
        //展开btn
        if (i == filterArr.count - 1 && tags.count > 8) {
            UIButton *expandBtn = [[UIButton alloc] init];
            expandBtn.frame =  CGRectMake(ScreenWIDTH / 2 - 10, CGRectGetMaxY(btn.frame) + 10, 20, 20);
            expandBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
            [expandBtn setBackgroundImage:[UIImage imageNamed: self.selectState ? @"down" : @"up"]  forState:UIControlStateNormal];
            expandBtn.selected = self.selectState;
            [expandBtn addTarget:self action:@selector(expandBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            [self.contentView addSubview:expandBtn];
            self.filterHelght = CGRectGetMaxY(expandBtn.frame) + 15;
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

#pragma mark - 点击标签进入到话题列表
- (void)pushTopicList:(UIButton *)button {
    if ([self.delegate respondsToSelector:@selector(clickTagTopicList:withTag:)]) {
        TopicTagsModel *model = self.tagsData [button.tag];
        [self.delegate clickTagTopicList:model.tagId withTag:model.text];
    }
}

- (void)expandBtnClick:(UIButton *)send {
    self.selectState = !send.selected;
    if (self.expandBlock) self.expandBlock();
}
@end
