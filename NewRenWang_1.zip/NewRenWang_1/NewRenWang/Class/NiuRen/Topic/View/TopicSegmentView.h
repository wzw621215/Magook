//
//  TopicSegmentView.h
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewHeaderFooterView.h"

@interface TopicSegmentView : BaseTableViewHeaderFooterView

@property (nonatomic, copy) void(^SegmentViewBtnClickHandle)(TopicSegmentView *segment, NSInteger currentIndex);

@end
