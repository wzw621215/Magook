//
//  NRTeacherViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NRTeacherViewCell.h"
#import "NRTeacherCollectionViewCell.h"
@interface NRTeacherViewCell () <UICollectionViewDelegate, UICollectionViewDataSource,FollowDelegate,PresentLoginDelegate>
@property (nonatomic, strong) UICollectionView *teacherView;
@end

static NSString *cellIdentifier = @"teacherCellIdentifier";

@implementation NRTeacherViewCell

- (UICollectionView *)teacherView {
    if (!_teacherView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        flowLayout.itemSize = CGSizeMake((ScreenWIDTH - 40)/2, 80);
        flowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
        flowLayout.minimumLineSpacing = 10;
        flowLayout.minimumInteritemSpacing = 10;
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        
        UICollectionView *teacherView = [[UICollectionView alloc] initWithFrame:self.contentView.bounds  collectionViewLayout:flowLayout];
        [self.contentView addSubview:teacherView];
        teacherView.delegate = self;
        teacherView.dataSource = self;
        _teacherView = teacherView;
        teacherView.backgroundColor = kWhiteColor;
        //注册
        [teacherView registerClass:[NRTeacherCollectionViewCell class] forCellWithReuseIdentifier:cellIdentifier];
    }
    return _teacherView;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.NRData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NRTeacherCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    cell.loginDelegate = self;
    cell.followDelegate = self;
    cell.model = self.NRData[indexPath.item];
    cell.layerCornerRadius = 3.0;
    [cell setLayerBorderWidth:1.0];
    [cell setLayerBorderColor:[UIColor colorWithHexString:@"#999999"]];
    return cell;
}

- (void)setNRData:(NSArray<TopicNRModel *> *)NRData {
    _NRData = NRData;
    [_teacherView reloadData];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.NRCenterDelegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        TopicNRModel *model = self.NRData[indexPath.item];
        [self.NRCenterDelegate pushNiuRenCenter:model.ID];
    }
}

#pragma mark -FollowDelegate
- (void)followTeacher{
    if ([self.followDelegate respondsToSelector:@selector(followTeacher)]) {
        [self.followDelegate followTeacher];
    }
}
#pragma mark -PresentLoginDelegate
- (void)presentLogin{
    if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
        [self.loginDelegate presentLogin];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.teacherView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(0);
        make.left.equalTo(self.contentView.mas_left).offset(0);
        make.right.equalTo(self.contentView.mas_right).offset(0);
        make.height.equalTo(@100);
    }];
}
@end
