//
//  TopicSegmentView.m
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicSegmentView.h"

@interface TopicSegmentView ()
@property (nonatomic, weak) UISegmentedControl *segmentView;
@end
@implementation TopicSegmentView



- (UISegmentedControl *)segmentView {
    if (!_segmentView) {
        UISegmentedControl *segmentView = [[UISegmentedControl alloc] initWithItems:@[@"热门话题",@"全部话题"]];
        [self.contentView addSubview:segmentView];
        _segmentView = segmentView;
        [segmentView setTintColor:[StaticKeyProfileManager navigationBackgroundColor]];
        segmentView.selectedSegmentIndex = 0;
        [segmentView addTarget:self action:@selector(SegmentViewBtnClick:) forControlEvents:UIControlEventValueChanged];
        self.contentView.backgroundColor = kWhiteColor;
    }
    return _segmentView;
}

- (void)SegmentViewBtnClick:(UISegmentedControl *)sender {
    if (self.SegmentViewBtnClickHandle) {
        self.SegmentViewBtnClickHandle(self, sender.selectedSegmentIndex);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.segmentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(5);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@25);
    }];
}


@end
