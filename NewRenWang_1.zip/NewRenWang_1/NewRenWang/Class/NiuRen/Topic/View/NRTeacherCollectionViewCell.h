//
//  NRTeacherCollectionViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TopicCell.h"

@class TopicNRModel;

@interface NRTeacherCollectionViewCell : UICollectionViewCell

@property (nonatomic,weak)id<FollowDelegate>followDelegate;

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;


/** model */
@property (nonatomic, strong) TopicNRModel *model;

@end
