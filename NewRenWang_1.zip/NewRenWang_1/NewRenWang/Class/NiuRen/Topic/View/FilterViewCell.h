//
//  FilterViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
@class TopicTagsModel;

@protocol TopicTagDelegate <NSObject>

- (void)clickTagTopicList:(NSInteger)tagId withTag:(NSString *)tagStr;

@end

@interface FilterViewCell : BaseTableViewCell

@property (nonatomic, strong)id <TopicTagDelegate> delegate;

/** cell高度 */
@property (nonatomic, assign) CGFloat filterHelght;

/** block */
@property (nonatomic, copy) void(^expandBlock)(void);

/** tag数据 */
@property (nonatomic, strong) NSArray<TopicTagsModel *> *tags;

@end
