//
//  NRTeacherCollectionViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/2/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NRTeacherCollectionViewCell.h"
#import "TopicModel.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

@interface NRTeacherCollectionViewCell ()
/** 头像 */
@property (nonatomic, weak) UIImageView *headImage;
/** 名字和粉丝数 */
@property (nonatomic, weak) UILabel *name;
/** 赞 */
@property (nonatomic, weak) UIButton *praise;
/** 发帖数量 */
@property (nonatomic, weak) UIButton *allPosts;
/** 关注 */
@property (nonatomic, weak) UIButton *concern;

@end

@implementation NRTeacherCollectionViewCell

- (UIImageView *)headImage {
    if (!_headImage) {
        UIImageView *headImg = [[UIImageView alloc] init];
        headImg.image = [UIImage imageNamed:@"me_icon"];
        [self.contentView addSubview:headImg];
        _headImage = headImg;
        headImg.layerCornerRadius = 40 / 2;
    }
    return _headImage;
}

- (UILabel *)name {
    if (!_name) {
        UILabel *name = [[UILabel alloc] init];
        [self.contentView addSubview:name];
         _name = name;
        name.font = kFont(12);
    }
    return _name;
}

#pragma mark - 赞
- (UIButton *)praise {
    if (!_praise) {
        UIButton *praise = [[UIButton alloc] init];
        [self.contentView addSubview:praise];
        _praise = praise;
        [praise setImage:[UIImage imageNamed:@"qiang"] forState:UIControlStateNormal];
        [praise setTitle:@" 100" forState:UIControlStateNormal];
        [praise setTitleColor:[UIColor colorWithHexString:@"#999999"] forState:UIControlStateNormal];
        praise.titleLabel.font = kFont(11);
    }
    return _praise;
}

#pragma mark - 发帖数量
- (UIButton *)allPosts {
    if (!_allPosts) {
        UIButton *allPosts = [[UIButton alloc] init];
        [self.contentView addSubview:allPosts];
        _allPosts = allPosts;
        [allPosts setImage:[UIImage imageNamed:@"postMsg"] forState:UIControlStateNormal];
        [allPosts setTitle:@" 32" forState:UIControlStateNormal];
        [allPosts setTitleColor:[UIColor colorWithHexString:@"#999999"] forState:UIControlStateNormal];
        allPosts.titleLabel.font = kFont(11);
    }
    return _allPosts;
}

#pragma mark - 关注
- (UIButton *)concern {
    if (!_concern) {
        UIButton *concern = [[UIButton alloc] init];
        [self.contentView addSubview:concern];
        _concern = concern;
        concern.titleLabel.font = kFont(13);
        [concern setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateNormal];
        [concern setTitle:@"+关注" forState:UIControlStateNormal];
        [concern setTitleColor:kOrangeColor forState:UIControlStateNormal];
        
        [concern setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateSelected];
        [concern setTitle:@"已关注" forState:UIControlStateSelected];
        [concern setTitleColor:kOrangeColor forState:UIControlStateSelected];
        [concern addTarget:self action:@selector(followTeacher:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _concern;
}

- (void)setModel:(TopicNRModel *)model {
    _model = model;
    
    [self.headImage sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    
    //名字和粉丝数
    NSString *fansCout = [NSString stringWithFormat:@"粉丝数:%@",model.fans];
    NSMutableAttributedString *aString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@/%@",model.name,fansCout]];
    
    [aString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#999999"]range:NSMakeRange(aString.length -fansCout.length, fansCout.length)];
    
    [aString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:9]range:NSMakeRange(aString.length - fansCout.length, fansCout.length)];
    
    self.name.attributedText= aString;
    
    //赞
    [self.praise setTitle:[NSString stringWithFormat:@" %@",model.up] forState:UIControlStateNormal];
    //话题数
    [self.allPosts setTitle:[NSString stringWithFormat:@" %@",model.topic] forState:UIControlStateNormal];
    
    self.concern.selected = self.model.isfollw;
}

#pragma mark - 关注按钮点击事件
- (void)followTeacher:(UIButton *)button {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if ([self.followDelegate respondsToSelector:@selector(followTeacher)]) {
            [self.followDelegate followTeacher];
        }
        if (self.concern.selected) {
            
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.concern.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.concern.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }

}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(8);
        make.left.equalTo(self.contentView.mas_left).offset(5);
        make.height.equalTo(@40);
        make.width.equalTo(@40);
    }];
    
    [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headImage.mas_top);
        make.left.equalTo(self.headImage.mas_right).offset(5);
        make.right.equalTo(self.contentView.mas_right);
    }];
    
    [self.allPosts mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.name.mas_bottom).offset(5);
        make.right.equalTo(self.contentView.mas_right);
    }];
    
    [self.praise mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.name.mas_bottom).offset(5);
        make.left.equalTo(self.headImage.mas_right).offset(5);
        make.right.equalTo(self.allPosts.mas_left).offset(-3);
    }];
    
    [self.concern mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.praise.mas_bottom).offset(5);
        make.left.equalTo(self.headImage.mas_right).offset(8);
        make.height.equalTo(@20);
        make.width.equalTo(@50);
    }];
}
@end
