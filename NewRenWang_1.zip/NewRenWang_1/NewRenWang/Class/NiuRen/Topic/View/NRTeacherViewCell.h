//
//  NRTeacherViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "TopicModel.h"
#import "TopicCell.h"

@interface NRTeacherViewCell : BaseTableViewCell

@property (nonatomic,weak)id <FollowDelegate> followDelegate;

@property (nonatomic,weak)id <PresentLoginDelegate> loginDelegate;

@property (nonatomic,weak)id <PushNiuRenDelegate> NRCenterDelegate;

/** 牛人数据 */
@property (nonatomic, strong) NSArray<TopicNRModel *> *NRData;



@end
