//
//  TopicModel.m
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicModel.h"

@implementation TopicModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"tags" : @"TopicTagsModel",
             @"topic" : @"TopicNRModel"
             };
}
@end

@implementation TopicADModel


@end

@implementation TopicTagsModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"tagId": @"ID"
             };
}

@end

@implementation TopicNRModel

@end
