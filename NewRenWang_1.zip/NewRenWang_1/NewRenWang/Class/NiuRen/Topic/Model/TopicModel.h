//
//  TopicModel.h
//  NewRenWang
//
//  Created by YJ on 17/2/18.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@class TopicADModel;
@interface TopicModel : BaseModel
/** 广告 */
@property (nonatomic, strong) TopicADModel *ad;
/** 话题标签 */
@property (nonatomic, strong) NSArray *tags;
/** NR */
@property (nonatomic, strong) NSArray *topic;

@end


@interface TopicADModel : BaseModel
/** 图片地址 */
@property (nonatomic, copy) NSString *thumb_href;
/** 标题 */
@property (nonatomic, copy) NSString *title;
/** 跳转地址 */
@property (nonatomic, copy) NSString *redirectUrl;

@end

@interface TopicTagsModel : BaseModel
/** tag文字 */
@property (nonatomic, copy) NSString *text;
///** id */
@property (nonatomic, assign) NSInteger tagId;

@end

@interface TopicNRModel : BaseModel
/** 名字 */
@property (nonatomic, copy) NSString *name;
/** id */
@property (nonatomic, assign) NSInteger ID;
/** 图片 */
@property (nonatomic, copy) NSString *avatar;
/** 粉丝 */
@property (nonatomic, copy) NSString *fans;
/** 点赞 */
@property (nonatomic, copy) NSString *up;
/** 话题数量 */
@property (nonatomic, copy) NSString *topic;
/** 是否关注 */
@property (nonatomic, assign) BOOL isfollw;

@end
