//
//  TopicListModel.m
//  NewRenWang
//
//  Created by YJ on 17/2/22.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicListModel.h"

@implementation TopicListModel

@end
