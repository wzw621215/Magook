//
//  TopicListModel.h
//  NewRenWang
//
//  Created by YJ on 17/2/22.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"
@class TopicNRModel;
@interface TopicListModel : BaseModel
/** id */
@property (nonatomic, assign) NSInteger ID;
/** 观点名称 */
@property (nonatomic, copy) NSString *type;
/** 赞 */
@property (nonatomic, assign) NSInteger up;
/** 踩 */
@property (nonatomic, assign) NSInteger down;

/** 内容 */
@property (nonatomic, copy) NSString *content;
/** 时间 */
@property (nonatomic, copy) NSString *time;

/** 是否赞 */
@property (nonatomic, assign) BOOL isup;
/** 是否踩 */
@property (nonatomic, assign) BOOL isdown;
/** 用户*/
@property (nonatomic, strong) TopicNRModel *user;
/** 高度 */
@property (nonatomic, assign) CGFloat cellHeight;
@end
