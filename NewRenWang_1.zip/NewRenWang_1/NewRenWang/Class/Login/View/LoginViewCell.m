//
//  LoginViewCell.m
//  NewRenWang
//
//  Created by JopYin on 17/1/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "LoginViewCell.h"
#import "UILabel+CountDown.h"
#import "CheckNumRequest.h"
#import "VerifyCodeRequest.h"
#import "RegisterRequest.h"
#import "PhoneVerifyRequest.h"

@interface LoginViewCell ()
/** 背景图*/
@property (nonatomic, weak) UIImageView *background;
/** 返回按钮*/
@property (nonatomic,weak) UIButton *backBtn;
/** 头像 */
@property (nonatomic, weak) UIImageView *headImage;
/** 手机号 输入框*/
@property (nonatomic, weak) UITextField *phoneTextFiled;
/** 密码 输入框 */
@property (nonatomic, weak) UITextField *passWordTextFiled;
/** 线 */
@property (nonatomic, weak) UILabel *lineOne;
/** 线 */
@property (nonatomic, weak) UILabel *lineTwo;
/** 倒计时 */
@property (nonatomic, weak) UILabel *countDown;
/** 登录 */
@property (nonatomic, weak) UIButton *loginBtn;
/** 第三方登录 */
@property (nonatomic, weak) UILabel *thirdLogin;
/** 左边线 */
@property (nonatomic, weak) UIImageView *leftLine;
/** 右边线 */
@property (nonatomic, weak) UIImageView *rightLine;
/** QQ */
@property (nonatomic, weak) UIButton *qqBtn;
/** 微信 */
@property (nonatomic, weak) UIButton *weChatBtn;
/** 微博 */
@property (nonatomic, weak) UIButton *socialBtn;
/** 记住密码 */
@property (nonatomic, weak) UIButton *rememberPassword;

@end

@implementation LoginViewCell

- (UIButton *)backBtn {
    if (!_backBtn) {
        UIButton *backBtn = [[UIButton alloc] init];
        [self.contentView addSubview:backBtn];
        [backBtn setImage:[UIImage imageNamed:@"fanhui"] forState:UIControlStateNormal];
        [backBtn setTitle:@"取消" forState:UIControlStateNormal];
        backBtn.imageEdgeInsets = UIEdgeInsetsMake(5, -30, 5, 0);
        backBtn.titleEdgeInsets = UIEdgeInsetsMake(0,-15,0,0);
        [backBtn setTitleColor:kWhiteColor forState:UIControlStateNormal];
        backBtn.titleLabel.font = kFont(14.0);
        [backBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
        _backBtn = backBtn;
    }
    return _backBtn;
}

- (UIImageView *)background {
    if (!_background) {
        UIImageView *background = [[UIImageView alloc] init];
        background.image = [UIImage imageNamed:@"bg.jpg"];
        [self.contentView addSubview:background];
        
        _background = background;
    }
    return _background;
}


- (UIImageView *)headImage {
    if (!_headImage) {
        UIImageView *headImage = [[UIImageView alloc] init];
        headImage.image = [UIImage imageNamed:@"loginIcon"];
        [self.contentView addSubview:headImage];
        headImage.layerCornerRadius =  85 / 2;
        _headImage = headImage;
    }
    return _headImage;
}

#pragma mark -
- (UITextField *)phoneTextFiled {
    if (!_phoneTextFiled) {
        UITextField *phoneTextFiled = [[UITextField alloc] init];
        [self.contentView addSubview:phoneTextFiled];
        _phoneTextFiled = phoneTextFiled;
        phoneTextFiled.textColor = kWhiteColor;
        phoneTextFiled.leftViewMode = UITextFieldViewModeAlways;
        phoneTextFiled.rightViewMode = UITextFieldViewModeAlways;
        phoneTextFiled.leftView = [self textFiledLeftImage:@"userName"];
        phoneTextFiled.text = [YDConfigurationHelper getStringValueForConfigurationKey:@"username"];
        
        UIButton  *forgetPwd = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 80, 25)];
        forgetPwd.layerCornerRadius = 8.0f;
        [forgetPwd setTitle:@"获取密码" forState:UIControlStateNormal];
        forgetPwd.backgroundColor = kRGBColor(43, 97, 121);
        [forgetPwd setTitleColor:kWhiteColor forState:UIControlStateNormal];
        [forgetPwd addTarget:self action:@selector(forgetPwd:) forControlEvents:UIControlEventTouchUpInside];
        forgetPwd.titleLabel.font = kFont(12.0f);
        phoneTextFiled.rightView = forgetPwd;
    }
    return _phoneTextFiled;
}

- (UITextField *)passWordTextFiled {
    if (!_passWordTextFiled) {
        UITextField *passWordTextFiled = [[UITextField alloc] init];
        [self.contentView addSubview:passWordTextFiled];
        _passWordTextFiled = passWordTextFiled;
        passWordTextFiled.textColor = kWhiteColor;
        passWordTextFiled.secureTextEntry = YES;
        passWordTextFiled.leftViewMode = UITextFieldViewModeAlways;
        passWordTextFiled.leftView = [self textFiledLeftImage:@"mima"];
        
    }
    return _passWordTextFiled;
}

- (UILabel *)lineOne {
    if (!_lineOne) {
        UILabel *line = [[UILabel alloc] init];
        line.backgroundColor = kRGBColor(43, 97, 121);
        [self.contentView addSubview:line];
        _lineOne = line;
    }
    return _lineOne;
}

- (UILabel *)lineTwo {
    if (!_lineTwo) {
        UILabel *line = [[UILabel alloc] init];
        line.backgroundColor = kRGBColor(43, 97, 121);
        [self.contentView addSubview:line];
        _lineTwo = line;
    }
    return _lineTwo;
}

- (UIButton *)rememberPassword {
    if (!_rememberPassword) {
        UIButton *rememberPassword = [[UIButton alloc] init];
        [self.contentView addSubview:rememberPassword];
        _rememberPassword = rememberPassword;
        [rememberPassword setTitle:@"记住密码" forState:UIControlStateNormal];
        rememberPassword.titleLabel.font = kFont(12);
        [rememberPassword setTitleColor:kRGBColor(43, 97, 121) forState:UIControlStateNormal];
        [rememberPassword setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [rememberPassword setImage:[UIImage imageNamed:@"check-in"] forState:UIControlStateSelected];
        [rememberPassword addTarget:self action:@selector(remember) forControlEvents:UIControlEventTouchUpInside];
        rememberPassword.selected = [YDConfigurationHelper getBoolValueForConfigurationKey:@"isRemember"];
    }
    return _rememberPassword;
}
- (UIButton *)loginBtn {
    if (!_loginBtn) {
        UIButton *login = [[UIButton alloc] init];
        [self.contentView addSubview:login];
        _loginBtn = login;
        login.backgroundColor = kRGBColor(43, 97, 121);
        [login setTitle:@"登录" forState:UIControlStateNormal];
        [login setTitleColor:kWhiteColor forState:UIControlStateNormal];
        login.layerCornerRadius = 16.0f;
        [login addTarget:self action:@selector(LoginBtnDidLogin) forControlEvents:UIControlEventTouchUpInside];
    }
    return _loginBtn;
}

- (UILabel *)thirdLogin {
    if (!_thirdLogin) {
        UILabel *thirdLogin = [[UILabel alloc] init];
        [self.contentView addSubview:thirdLogin];
        _thirdLogin = thirdLogin;
        thirdLogin.text = @"第三方登录";
        thirdLogin.font = kFont(14);
        thirdLogin.textColor = kRGBColor(43, 97, 121);
    }
    return _thirdLogin;
}

- (UIImageView *)leftLine {
    if (!_leftLine) {
        UIImageView *line = [[UIImageView alloc] init];
        line.image = [UIImage imageWithColor:kRGBColor(43, 97, 121)];
        [self.contentView addSubview:line];
        _leftLine = line;
    }
    return _leftLine;
}

-(UIImageView *)rightLine {
    if (!_rightLine) {
        UIImageView *line = [[UIImageView alloc] init];
        line.image = [UIImage imageWithColor:kRGBColor(43, 97, 121)];
        [self.contentView addSubview:line];
        _rightLine = line;

    }
    return _rightLine;
}

- (UIButton *)qqBtn {
    if (!_qqBtn) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:btn];
        _qqBtn = btn;
        [btn setBackgroundImage:[UIImage imageNamed:@"qq"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(loginWithQQ:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _qqBtn;
}

- (UIButton *)weChatBtn {
    if (!_weChatBtn) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:btn];
        _weChatBtn = btn;
        [btn setBackgroundImage:[UIImage imageNamed:@"weixin"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(loginWithWechat:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _weChatBtn;
}

- (UIButton *)socialBtn {
    if (!_socialBtn) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.contentView addSubview:btn];
        _socialBtn = btn;
        [btn setBackgroundImage:[UIImage imageNamed:@"xinlang"] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(loginWithSina:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _socialBtn;
}

- (UIView *)textFiledLeftImage:(NSString *)imageName {
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, 18, 19)];
    image.contentMode = UIViewContentModeScaleAspectFit;
    image.image = [UIImage imageNamed:imageName];
    return image;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.background.frame = self.contentView.bounds;
    self.passWordTextFiled.text = [YDConfigurationHelper getStringValueForConfigurationKey:@"password"];
    
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(15);
        make.top.equalTo(self.contentView.mas_top).offset(30);
        make.width.equalTo(@70);
        make.height.equalTo(@25);
    }];
    
    [self.headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).offset(H(70, 568));
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@85);
        make.width.equalTo(@85);
    }];
    
    [self.phoneTextFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headImage.mas_bottom).offset(H(50, 667));
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@38);
        make.width.equalTo(@(ScreenWIDTH - ScreenWIDTH / 375 * 80));
        
    }];
    
    [self.lineOne mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.phoneTextFiled.mas_bottom).offset(2);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@kLineHeight);
        make.width.equalTo(self.phoneTextFiled.mas_width);
    }];
    
    [self.passWordTextFiled mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineOne.mas_bottom).offset(15);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@38);
        make.width.equalTo(self.phoneTextFiled.mas_width);
        
    }];
    
    [self.lineTwo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passWordTextFiled.mas_bottom).offset(2);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@kLineHeight);
        make.width.equalTo(self.phoneTextFiled.mas_width);
    }];
    
    [self.rememberPassword mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineTwo.mas_bottom).offset(15);
        make.right.equalTo(self.lineTwo.mas_right).offset(0);
        make.height.equalTo(@20);
    }];
    
    [self.loginBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.rememberPassword.mas_bottom).offset(35);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@40);
        make.width.equalTo(self.phoneTextFiled.mas_width);
    }];
    
    [self.thirdLogin mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.loginBtn.mas_bottom).offset(50);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@20);

    }];
    
    [self.leftLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.thirdLogin.mas_centerY);
        make.right.equalTo(self.thirdLogin.mas_left).offset(-5);
        make.left.equalTo(self.contentView.mas_left).offset(0);
        make.height.equalTo(@(kLineHeight));
    }];
    
    [self.rightLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.thirdLogin.mas_centerY);
        make.left.equalTo(self.thirdLogin.mas_right).offset(5);
        make.right.equalTo(self.contentView.mas_right).offset(0);
        make.height.equalTo(@(kLineHeight));
    }];
    
    [self.weChatBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.thirdLogin.mas_bottom).offset(40);
        make.centerX.mas_equalTo(self.contentView.mas_centerX);
        make.height.equalTo(@40);
        make.width.equalTo(@40);
    }];
    
    [self.qqBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.weChatBtn.mas_centerY);
        make.right.equalTo(self.weChatBtn.mas_left).offset(-40);
        make.width.height.equalTo(self.weChatBtn);
    }];
    
    [self.socialBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.weChatBtn.mas_centerY);
        make.left.equalTo(self.weChatBtn.mas_right).offset(40);
        make.width.height.equalTo(self.weChatBtn);
    }];
}
#pragma mark -QQ 登录
- (void)loginWithQQ:(id)sender {
    if ([self.delegate respondsToSelector:@selector(qqLogin)]) {
        [self.delegate qqLogin];
    }
}

#pragma mark -微信 登录
- (void)loginWithWechat:(id)sender {
    if ([self.delegate respondsToSelector:@selector(wechatLogin)]) {
        [self.delegate wechatLogin];
    }
}
#pragma mark -Sina 登录
- (void)loginWithSina:(id)sender {
    if ([self.delegate respondsToSelector:@selector(sinaLogin)]) {
        [self.delegate sinaLogin];
    }
}

#pragma mark - 记住密码
- (void)remember {
    self.rememberPassword.selected = !self.rememberPassword.selected;
    
    if (self.rememberPassword.selected) {
        [YDConfigurationHelper setBoolValueForConfigurationKey:@"isRemember" withValue:YES];
    }else{
        [YDConfigurationHelper setBoolValueForConfigurationKey:@"isRemember" withValue:NO];
        [YDConfigurationHelper removeUserDataForkey:@"password"];
    }
}

#pragma mark -  获取密码
- (void)forgetPwd:(id)sender{
    if (![_phoneTextFiled.text isPhoneNumber]) {
        [ShowMessage showMessageWithTitle:@"请输入正确的手机号"];
        return;
    }
    CheckNumRequest *checkRequest = [[CheckNumRequest alloc] initWithiphoneNum:self.phoneTextFiled.text];
    [checkRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            if ([response isKindOfClass:[NSDictionary class]]) {
                if ([response[@"exists"] boolValue]) {
                    if ([self.delegate respondsToSelector:@selector(forgetPassWord:)]) {
                        [self.delegate forgetPassWord:self.phoneTextFiled.text];
                    }
                }else{
                    //未注册的手机号
                    [self requestPhoneCode];
                    [CNNavigationBarHUD showSuccess:@"输入验证码登录"];
                }
            }
        }else{
            
        }
    }];
}
#pragma mark - 未注册的手机号  获取验证码
- (void)requestPhoneCode{
    PhoneVerifyRequest *request = [[PhoneVerifyRequest alloc] initWithIphoneNum:self.phoneTextFiled.text passW:nil];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [ShowMessage showMessageWithTitle:@"密码已经发送"];
    }];
}

#pragma mark - 登录按钮
- (void)LoginBtnDidLogin {
    if (![_phoneTextFiled.text isPhoneNumber]) {
        [ShowMessage showMessageWithTitle:@"请输入正确的手机号"];
        return;
    }
    if ([_phoneTextFiled.text isBlank] || [_passWordTextFiled.text isBlank]) {
        [ShowMessage showMessageWithTitle:@"用户名或者密码不能为空"];
        return;
    }
    CheckNumRequest *checkRequest = [[CheckNumRequest alloc] initWithiphoneNum:self.phoneTextFiled.text];
    [checkRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            if ([response[@"exists"] boolValue]) {
                if ([self.delegate respondsToSelector:@selector(loginView:didLoginWithUserName:password:)]) {
                    [self.delegate loginView:self didLoginWithUserName:self.phoneTextFiled.text password:self.passWordTextFiled.text];
                }
            }else{
                //未注册的用户则要去验证验证码
                VerifyCodeRequest *codeRequest = [[VerifyCodeRequest alloc] initWithIphoneNum:self.phoneTextFiled.text code:self.passWordTextFiled.text];
                [codeRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                    if (success) {
                        [self registerUserName];
                    }else{
                        [CNNavigationBarHUD showError:message];
                    }
                }];
            }
        }
    }];
}

#pragma mark - 注册
- (void)registerUserName {
    RegisterRequest *regiRequest = [[RegisterRequest alloc] initWithUsername:self.phoneTextFiled.text password:self.passWordTextFiled.text];
    [regiRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            if ([self.delegate respondsToSelector:@selector(loginView:didLoginWithUserName:password:)]) {
                [self.delegate loginView:self didLoginWithUserName:self.phoneTextFiled.text password:self.passWordTextFiled.text];
            }
        }else{
            [CNNavigationBarHUD showError:message];
        }
    }];
}

#pragma mark - 返回
- (void)back{
    if ([self.delegate respondsToSelector:@selector(back)]) {
        [self.delegate back];
    }
}

@end
