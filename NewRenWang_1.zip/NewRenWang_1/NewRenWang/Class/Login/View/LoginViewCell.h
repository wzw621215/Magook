//
//  LoginViewCell.h
//  NewRenWang
//
//  Created by JopYin on 17/1/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
@class LoginViewCell;
@protocol LoginSucceedDelegate <NSObject>

- (void)loginView:(LoginViewCell *)loginView didLoginWithUserName:(NSString *)userName password:(NSString *)password;

/** 返回*/
- (void)back;

/**忘记密码  重置密码*/
- (void)forgetPassWord:(NSString *)phoneNum;

- (void)qqLogin;

- (void)wechatLogin;

- (void)sinaLogin;

@end

@interface LoginViewCell : BaseTableViewCell
/** 登录成功代理 */
@property (nonatomic, weak) id<LoginSucceedDelegate>delegate;


@end
