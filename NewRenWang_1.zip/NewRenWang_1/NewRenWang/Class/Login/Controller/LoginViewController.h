//
//  LoginViewController.h
//  NewRenWang
//
//  Created by JopYin on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface LoginViewController : BaseTableViewController

@end
