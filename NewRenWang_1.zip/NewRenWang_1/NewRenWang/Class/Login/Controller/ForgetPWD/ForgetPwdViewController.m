//
//  ForgetPwdViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ForgetPwdViewController.h"
#import "UILabel+CountDown.h"
#import "PhoneVerifyRequest.h"
#import "VerifyCodeRequest.h"
#import "ResetPwdRequest.h"

@interface ForgetPwdViewController ()
@property (weak, nonatomic) IBOutlet UITextField *phoneCode;
@property (weak, nonatomic) IBOutlet UITextField *mima;
@property (weak, nonatomic) IBOutlet UIView *countDownView;
@property (weak, nonatomic) IBOutlet UILabel *countDown;

@property (weak, nonatomic) IBOutlet UIButton *okLogin;

@end

@implementation ForgetPwdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"重置密码";
    [self.countDownView setLayerCornerRadius:2 borderWidth:0.8 borderColor:kRGBColor(230, 230, 230)];
    [self.countDown addActionWithTarget:self action:@selector(startCountDown)];
    
    //[self requestPhoneCode];
}

#pragma mark - 获取验证码
- (void)requestPhoneCode{
    PhoneVerifyRequest *request = [[PhoneVerifyRequest alloc] initWithIphoneNum:self.phoneNum passW:nil];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        
    }];
}

#pragma mark - 倒计时
- (void)startCountDown {
    [self requestPhoneCode];
    [self.countDown startWithTime:59 title:@"重新获取" countDownTitle:@"s" mainColor:kWhiteColor countColor:kWhiteColor];
}


- (IBAction)login:(id)sender {
    VerifyCodeRequest *codeRequest = [[VerifyCodeRequest alloc] initWithIphoneNum:self.phoneNum code:self.phoneCode.text];
    [codeRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            [self resetMima:response];
        }
    }];
}

#pragma mark - 重置密码
- (void)resetMima:(NSString *)ticket{
    if ([self.mima.text isBlank]) {
        [CNNavigationBarHUD showError:@"请输入密码"];
        return ;
    }
    if (self.mima.text.length <6 || self.mima.text.length >12) {
        [CNNavigationBarHUD showError:@"密码长度不符合要求"];
        return;
    }else {
        NSInteger check = [self checkIsHaveNumAndLetter:self.mima.text];
        if (check == ConfirmPasswordResult_HaveOther) {
            [CNNavigationBarHUD showError:@"密码只能包含数字和字母"];
            return ;
        }
    }
    
    ResetPwdRequest *resetRequest = [[ResetPwdRequest alloc] initWithTicket:ticket passW:self.mima.text];
    [resetRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
             [CNNavigationBarHUD showSuccess:response];
            
  //          if ([self.delegate respondsToSelector:@selector(successResetWithPassWord:)]) {
       //         [self.delegate successResetWithPassWord:self.mima.text];
      //      }
            [YDConfigurationHelper removeUserDataForkey:@"password"];
            [self pop];
        }else{
             [CNNavigationBarHUD showSuccess:response];
        }
    }];
}

- (NSInteger)checkIsHaveNumAndLetter:(NSString*)pPassword{
    //數字條件
    NSRegularExpression *tNumRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"[0-9]" options:NSRegularExpressionCaseInsensitive error:nil];
    
    //符合數字條件的有幾個字元
    NSInteger tNumMatchCount = [tNumRegularExpression numberOfMatchesInString:pPassword
                                                                      options:NSMatchingReportProgress
                                                                        range:NSMakeRange(0, pPassword.length)];
    
    //英文字條件
    NSRegularExpression *tLetterRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"[A-Za-z]" options:NSRegularExpressionCaseInsensitive error:nil];
    
    //符合英文字條件的有幾個字元
    NSInteger tLetterMatchCount = [tLetterRegularExpression numberOfMatchesInString:pPassword
                                                                            options:NSMatchingReportProgress
                                                                              range:NSMakeRange(0, pPassword.length)];
    
    if (tNumMatchCount == pPassword.length){
        //全部符合數字，表示沒有英文
        return ConfirmPasswordResult_HaveNoChar;
    }else if (tLetterMatchCount == pPassword.length){
        //全部符合英文，表示沒有數字
        return ConfirmPasswordResult_HaveNoNum;
    }else if (tNumMatchCount + tLetterMatchCount != pPassword.length){
        return ConfirmPasswordResult_HaveOther;
    }else{
        //符合英文和符合數字條件的相加等於密碼長度
        return ConfirmPasswordResult_Success;
    }
}

- (void)dealloc {
    [self.countDown stopTime];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
