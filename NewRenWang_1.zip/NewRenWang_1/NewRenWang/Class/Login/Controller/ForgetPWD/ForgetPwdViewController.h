//
//  ForgetPwdViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

typedef NS_ENUM(NSInteger, ConfirmPWDResult) {
    ConfirmPasswordResult_HaveNoChar = 0,
    ConfirmPasswordResult_HaveNoNum,
    ConfirmPasswordResult_HaveOther,
    ConfirmPasswordResult_Success
};

@protocol ForgetPsdDelegate <NSObject>

- (void)successResetWithPassWord:(NSString *)password;

@end

@interface ForgetPwdViewController : BaseViewController

@property (nonatomic, weak)id <ForgetPsdDelegate> delegate;

@property (nonatomic, copy)NSString *phoneNum;

@end
