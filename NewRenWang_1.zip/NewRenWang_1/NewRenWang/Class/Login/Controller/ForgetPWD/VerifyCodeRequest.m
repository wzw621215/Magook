//
//  VerifyCodeRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "VerifyCodeRequest.h"
@interface VerifyCodeRequest()

/** 手机号*/
@property (nonatomic, copy) NSString *iphoneNum;
/** 验证码 */
@property (nonatomic, copy) NSString *code;

@end

@implementation VerifyCodeRequest

- (instancetype)initWithIphoneNum:(NSString *)iphoneNum code:(NSString *)code {
    if (self == [super init]) {
        _iphoneNum = iphoneNum;
        _code = code;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kCheckCodeAPI;
}

- (NSDictionary *)params {
    return  @{
                             @"mobile":_iphoneNum,
                             @"code":_code
                             };
}

@end
