//
//  ResetPwdRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ResetPwdRequest.h"
@interface ResetPwdRequest()

/** 票据*/
@property (nonatomic, copy) NSString *ticket;
/** 密码 */
@property (nonatomic, copy) NSString *password;

@end

@implementation ResetPwdRequest

- (instancetype)initWithTicket:(NSString *)ticket passW:(NSString *)password {
    if (self == [super init]) {
        _ticket = ticket;
        _password = password;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kResetAPI;
}

- (NSDictionary *)params {
    return @{
             @"ticket":_ticket,
             @"password":_password
             };
}


@end
