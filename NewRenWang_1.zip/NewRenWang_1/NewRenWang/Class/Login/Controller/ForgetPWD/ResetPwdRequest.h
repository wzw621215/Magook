//
//  ResetPwdRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface ResetPwdRequest : BaseRequest
- (instancetype)initWithTicket:(NSString *)ticket passW:(NSString *)password;
@end
