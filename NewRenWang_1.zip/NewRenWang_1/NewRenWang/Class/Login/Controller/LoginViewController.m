//
//  LoginViewController.m
//  NewRenWang
//
//  Created by JopYin on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "LoginViewController.h"
#import "LoginRequset.h"
#import "HeaderOptionalView.h"
#import "CustomSlideViewController.h"
#import "LoginViewCell.h"
#import "UserInfoModel.h"
#import "ForgetPwdViewController.h"
#import <UMSocialCore/UMSocialCore.h>
#import "ThirdLoginRequest.h"
#import "PhoneVerifyRequest.h"

@interface LoginViewController () <LoginSucceedDelegate>

@property(nonatomic,copy)NSString *phoneNum;

@property (nonatomic,assign)BOOL isExists;    //判断手机号是否注册

@end

@implementation LoginViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [self reloadData];
    
}

#pragma  mark - 显示导航栏
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置背景颜色
    self.tableView.backgroundColor = kRGBColor(5, 22, 35);
    self.tableView.scrollEnabled = NO;
}


- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    return ScreenHEIGHT ;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSections {
    return 1;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    return 0.1;
}
- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    LoginViewCell *cell = [LoginViewCell cellWithTableView:self.tableView];
    cell.delegate = self;
    cell.backgroundColor = kClearColor;
    return cell;
}

#pragma mark - 登录请求接口  LoginSucceedDelegate
//18852360209
- (void)loginView:(LoginViewCell *)loginView didLoginWithUserName:(NSString *)userName password:(NSString *)password {
    //  登录成功 存储用户信息
    LoginRequset *request = [[LoginRequset alloc] initWithUsername:userName password:password];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        CNLog(@"%@",response);
        if (success) {
            [YDConfigurationHelper setStringValueForConfigurationKey:@"username" withValue:userName];
            if ([YDConfigurationHelper getBoolValueForConfigurationKey:@"isRemember"]) {
                [YDConfigurationHelper setStringValueForConfigurationKey:@"password" withValue:password];
            }
            [YDConfigurationHelper setStringValueForConfigurationKey:@"oldPsd" withValue:password];
            [FileCacheManager saveUserData:@YES forKey:kHasLoginFlag];
            [FileCacheManager saveUserData:response[@"token"] forKey:kToken];
            [self requestInfomation];
        }else{
            [CNNavigationBarHUD showError:message];
        }
    }];
}

- (void)requestInfomation {
    BaseRequest *request = [BaseRequest requestWithUrl:kUserInfoAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            [[UserInfoManage sharedManager] didLoginInWithUserInfo:response];
            [self dismiss];
        }
    }];
}


#pragma mark - 点击获取密码 重置密码
- (void)forgetPassWord:(NSString *)phoneNum{
    PhoneVerifyRequest *request = [[PhoneVerifyRequest alloc] initWithIphoneNum:phoneNum passW:nil];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        
    }];
    
    ForgetPwdViewController * forgetVC = [[ForgetPwdViewController alloc] init];
    self.phoneNum = phoneNum;
    forgetVC.phoneNum = phoneNum;
    [self.navigationController pushViewController:forgetVC animated:YES];
}

- (void)back {
    [self dismiss];
}

- (CAGradientLayer *)backgroundLayer {
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = self.view.bounds;
    gradientLayer.colors = @[(__bridge id)[StaticKeyProfileManager navigationBackgroundColor].CGColor,(__bridge id)kRGBColor(40, 51, 53).CGColor];
    gradientLayer.startPoint = CGPointMake(0.5, 0);
    gradientLayer.endPoint = CGPointMake(0.5, 1);
    gradientLayer.locations = @[@0.65,@1];
    return gradientLayer;
}


- (void)dealloc {
    NSLog(@"%s",__func__);
}

#pragma mark -QQ 登录
- (void)qqLogin{
    [[UMSocialManager defaultManager] getUserInfoWithPlatform:UMSocialPlatformType_QQ currentViewController:nil completion:^(id result, NSError *error) {
        if (error) {
            
        } else {
            UMSocialUserInfoResponse *resp = result;
            ThirdLoginRequest *thirdRequest = [[ThirdLoginRequest alloc] initWithOpenid:resp.uid token:resp.accessToken type:5 nickname:resp.name icon:resp.iconurl];
            [thirdRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    [FileCacheManager saveUserData:@YES forKey:kHasLoginFlag];
                    [FileCacheManager saveUserData:response[@"token"] forKey:kToken];
                    [self requestInfomation];
                }
            }];            
        }
    }];

}

#pragma mark -微信 登录
- (void)wechatLogin{
    [[UMSocialManager defaultManager] getUserInfoWithPlatform:UMSocialPlatformType_WechatSession currentViewController:nil completion:^(id result, NSError *error) {
        if (error) {
            
        } else {
            UMSocialUserInfoResponse *resp = result;
            ThirdLoginRequest *thirdRequest = [[ThirdLoginRequest alloc] initWithOpenid:resp.openid token:resp.accessToken type:6 nickname:resp.name icon:resp.iconurl];
            [thirdRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    [FileCacheManager saveUserData:@YES forKey:kHasLoginFlag];
                    [FileCacheManager saveUserData:response[@"token"] forKey:kToken];
                    [self requestInfomation];
                }
            }];
        }
    }];

}

#pragma mark -Sina 登录
- (void)sinaLogin{
    [[UMSocialManager defaultManager] getUserInfoWithPlatform:UMSocialPlatformType_Sina currentViewController:self completion:^(id result, NSError *error) {
        if (error) {
            
        } else {
            UMSocialUserInfoResponse *resp = result;
            ThirdLoginRequest *thirdRequest = [[ThirdLoginRequest alloc] initWithOpenid:resp.uid token:resp.accessToken type:4 nickname:resp.name icon:resp.iconurl];
            [thirdRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    [FileCacheManager saveUserData:@YES forKey:kHasLoginFlag];
                    [FileCacheManager saveUserData:response[@"token"] forKey:kToken];
                    [self requestInfomation];
                }
            }];
        }
    }];
}


- (void)getUserInForPlatform:(UMSocialPlatformType)platformType {
    [[UMSocialManager defaultManager] getUserInfoWithPlatform:platformType currentViewController:self completion:^(id result, NSError *error) {
        UMSocialUserInfoResponse *resp = result;
        //第三方登录数据（为空表示平台未提供）
        NSLog(@"uid:%@",resp.uid);             //用户唯一标识
        NSLog(@"openid:%@",resp.openid);
        NSLog(@"accessToken:%@",resp.accessToken);
        NSLog(@"refreshToken:%@",resp.refreshToken);
        NSLog(@"expiration:%@",resp.expiration);
        
        //用户数据
        NSLog(@"name:%@",resp.name);
        NSLog(@"iconurl:%@",resp.iconurl);
        NSLog(@"gender:%@",resp.gender);
        
        //第三方平台SDK原始数据
        NSLog(@"originalResponse:%@",resp.originalResponse);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
