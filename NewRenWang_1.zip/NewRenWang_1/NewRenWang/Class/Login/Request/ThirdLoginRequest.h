//
//  ThirdLoginRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface ThirdLoginRequest : BaseRequest

- (instancetype)initWithOpenid:(NSString *)openid token:(NSString *)token type:(NSInteger)type nickname:(NSString *)nickname icon:(NSString *)icon;

@end
