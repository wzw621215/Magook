//
//  ThirdLoginRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ThirdLoginRequest.h"
@interface ThirdLoginRequest()

/** openid uid*/
@property (nonatomic, copy) NSString *openid;
/** token */
@property (nonatomic, copy) NSString *token;
/** source */
@property (nonatomic, copy) NSString *source;
/** type */
@property (nonatomic, assign) NSInteger type;
/** 第三方昵称 */
@property (nonatomic, copy) NSString *nickname;
/** 第三方头像 */
@property (nonatomic, copy) NSString *icon;

@end

@implementation ThirdLoginRequest

- (instancetype)initWithOpenid:(NSString *)openid token:(NSString *)token type:(NSInteger)type nickname:(NSString *)nickname icon:(NSString *)icon{
    if (self == [super init]) {
        _openid = openid;
        _token = token;
        _type = type;
        _nickname = nickname;
        _icon = icon;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kThirdLoginAPI;
}

//[@"牛人网" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
- (NSDictionary *)params {
    return @{
             @"openid" : _openid,
             @"token":  _token,
             @"source" :@"\"牛人网App\"",
             @"type":@(_type),
             @"nickname":_nickname,
             @"icon":_icon
             };
}


@end
