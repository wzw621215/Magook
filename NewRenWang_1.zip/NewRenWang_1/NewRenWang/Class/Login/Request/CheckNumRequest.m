//
//  CheckNumRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/30.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "CheckNumRequest.h"
@interface CheckNumRequest()
/** 账号*/
@property (nonatomic, copy) NSString *iphoneNum;

@end

@implementation CheckNumRequest

- (instancetype)initWithiphoneNum:(NSString *)iphoneNum {
    if (self == [super init]) {
        _iphoneNum = iphoneNum;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kCheckNumAPI;
}


- (NSDictionary *)params {
    return @{
             @"type" : @"1",
             @"value": _iphoneNum
             };
}

@end
