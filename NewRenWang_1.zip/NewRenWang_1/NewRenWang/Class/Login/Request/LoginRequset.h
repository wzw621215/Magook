//
//  LoginRequset.h
//  NewRenWang
//
//  Created by JopYin on 17/1/13.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface LoginRequset : BaseRequest

- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password;

@end
