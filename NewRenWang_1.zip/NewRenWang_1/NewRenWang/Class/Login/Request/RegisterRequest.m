//
//  RegisterRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/30.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RegisterRequest.h"
@interface RegisterRequest()

/** 账号*/
@property (nonatomic, copy) NSString *userName;
/** 密码 */
@property (nonatomic, copy) NSString *password;

@end

@implementation RegisterRequest

- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password {
    if (self == [super init]) {
        _userName = username;
        _password = password;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kRegisterAPI;
}


- (NSDictionary *)params {
    return @{
             @"mobileEmail" : _userName,
             @"userName":_userName,
             @"password":  _password,
             @"source" :@"\"牛人网App\"",
             };
}

@end
