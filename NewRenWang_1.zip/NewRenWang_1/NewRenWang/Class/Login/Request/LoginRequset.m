//
//  LoginRequset.m
//  NewRenWang
//
//  Created by JopYin on 17/1/13.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "LoginRequset.h"

@interface LoginRequset ()
/** 账号*/
@property (nonatomic, copy) NSString *userName;
/** 密码 */
@property (nonatomic, copy) NSString *password;


@end

@implementation LoginRequset

- (instancetype)initWithUsername:(NSString *)username password:(NSString *)password {
    if (self == [super init]) {
        _userName = username;
        _password = password;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kLoginAPI;
}

//[@"牛人网" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
- (NSDictionary *)params {
    return @{
             @"mobile" : _userName,
             @"pword":  _password,
             @"source" :@"\"牛人网\"",
             };
}

@end
