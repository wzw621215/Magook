//
//  adviserNoticePresenter.m
//  InvestmentAdviser
//
//  Created by lhg on 2017/2/22.
//  Copyright © 2017年 lhg. All rights reserved.
//

#import "adviserNoticePresenter.h"

@implementation adviserNoticePresenter
- (NSString *)headerSorbIdentifier{
    return AdviserSection2ID;
}
- (NSString *)presenterIdenditifier{
    return AdviserNoticeCellID;
}
- (CGSize)calculateCellSize:(CGSize)size{
    return CGSizeMake(0, 300);
}
- (CGSize)calculateHeaderSize:(CGSize)size{
    return CGSizeMake(0, 40);
}
@end
