//
//  adviserintroductionPresenter.m
//  InvestmentAdviser
//
//  Created by lhg on 2017/2/22.
//  Copyright © 2017年 lhg. All rights reserved.
//

#import "adviserintroductionPresenter.h"

@implementation adviserintroductionPresenter
- (NSString *)headerSorbIdentifier{
    return nil;
}
- (NSString *)presenterIdenditifier{
    return AdviserIntroductionCellID;
}
- (CGSize)calculateCellSize:(CGSize)size{
    return CGSizeMake(0, 300);
}
- (CGSize)calculateHeaderSize:(CGSize)size{
    return CGSizeMake(0, 0);
}

@end
