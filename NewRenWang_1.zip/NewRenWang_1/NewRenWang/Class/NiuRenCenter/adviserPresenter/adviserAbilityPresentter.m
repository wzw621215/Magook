//
//  adviserAbilityPresentter.m
//  InvestmentAdviser
//
//  Created by lhg on 2017/2/23.
//  Copyright © 2017年 lhg. All rights reserved.
//

#import "adviserAbilityPresentter.h"

@implementation adviserAbilityPresentter
- (NSString *)headerSorbIdentifier{
    return nil;
}

#pragma mark - 设置cell高度
- (CGSize)calculateCellSize:(CGSize)size{
    return CGSizeMake(0, 110);
}


- (CGSize)calculateHeaderSize:(CGSize)size{
    return CGSizeMake(0, 0);
}

- (NSString *)presenterIdenditifier{
    return AdviserAbilityCellID;
}
@end
