//
//  adviserNoticePresenter.h
//  InvestmentAdviser
//
//  Created by lhg on 2017/2/22.
//  Copyright © 2017年 lhg. All rights reserved.
//

#import "LHGCommonPresenter.h"
#import "AdviserNoticeModel.h"
@interface adviserNoticePresenter : LHGCommonPresenter<PresenterSorbProtocol>

@end
