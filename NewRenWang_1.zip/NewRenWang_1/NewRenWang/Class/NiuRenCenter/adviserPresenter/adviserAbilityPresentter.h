//
//  adviserAbilityPresentter.h
//  InvestmentAdviser
//
//  Created by lhg on 2017/2/23.
//  Copyright © 2017年 lhg. All rights reserved.
//

#import "LHGCommonPresenter.h"
#import "AbilityCommunityModel.h"
@interface adviserAbilityPresentter : LHGCommonPresenter

@end
