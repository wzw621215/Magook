//
//  NiuRenInfoRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/27.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuRenInfoRequest.h"
@interface NiuRenInfoRequest()

/*牛人ID*/
@property(nonatomic, assign)NSInteger niuRenID;

@end

@implementation NiuRenInfoRequest


- (instancetype)initWithNiuRenID:(NSInteger)niuRenID{
    if (self == [super init]) {
        _niuRenID = niuRenID;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"nid":@(_niuRenID)
             };
}

- (NSString *)url{
    return kNiuRenInfoAPI;
}

@end
