//
//  NiuRenVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/27.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface NiuRenVC : BaseViewController

@property (nonatomic,assign)NSInteger nrID;

@end
