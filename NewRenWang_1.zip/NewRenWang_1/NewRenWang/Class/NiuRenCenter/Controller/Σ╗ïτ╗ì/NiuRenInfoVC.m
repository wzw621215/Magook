//
//  NiuRenInfoVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/27.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuRenInfoVC.h"
#import "LHGCommonPresenter.h"
#import "AdviserIntroduceModel.h"
#import "HomeSectionHeadView.h"
#import "AdviserIntroduceCell.h"
#import "AdviserSection2Cell.h"
#import "AdviserNoticeCell.h"
#import "AdiviserNodataCell.h"

@interface NiuRenInfoVC ()

@end

@implementation NiuRenInfoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.needCellSepLine = NO;
    
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    LHGCommonPresenter *presenter = self.dataArray[indexPath.section];
    if (presenter.itemList && presenter.itemList.count>0) {
        CGSize size = [presenter calculateCellSize:CGSizeZero];
        if (indexPath.section == 0) {
            AdviserIntroduceModel *model = presenter.itemList[0];
            if (model.nextOpen) {
                return 110 + model.introductionHeight;
            }else{
                return 110+100;
            }
        }
        return size.height;
    }else{
        return 100;
    }
}
- (NSInteger)numberOfSections{
    return self.dataArray.count;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    LHGCommonPresenter<PresenterSorbProtocol> *presenter = self.dataArray[section];
    CGSize size = [presenter calculateHeaderSize:CGSizeZero];
    return size.height;
}

- (UIView *)headerAtSection:(NSInteger)section{
    if (section == 2) {
        HomeSectionHeadView *sectionHeadView = [HomeSectionHeadView headerFooterViewWithTableView:self.tableView];
        sectionHeadView.title.text = @"最新公告";
        sectionHeadView.rightBtn.hidden = YES;
        return sectionHeadView;
    }
    return nil;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath{
    LHGCommonPresenter *presenter = self.dataArray[indexPath.section];
    if (presenter.itemList &&presenter.itemList.count > 0) {
        id dataModel =presenter.itemList[indexPath.row];
        if (indexPath.section == 0) {
            AdviserIntroduceCell *introduceCell = [AdviserIntroduceCell nibCellWithTableView:self.tableView];
            introduceCell.selectionStyle = UITableViewCellSelectionStyleNone;
            [introduceCell presentDataModel:dataModel withTarget:self];
            return introduceCell;
        }else if (indexPath.section ==1){
            AdviserSection2Cell *abilityCell = [AdviserSection2Cell nibCellWithTableView:self.tableView];
            abilityCell.selectionStyle = UITableViewCellSelectionStyleNone;
            [abilityCell presentDataModel:dataModel withTarget:self];
            return abilityCell;
        }else{
            AdviserNoticeCell *noticeCell = [AdviserNoticeCell nibCellWithTableView:self.tableView];
            noticeCell.selectionStyle = UITableViewCellSelectionStyleNone;
            [noticeCell presentDataModel:dataModel withTarget:self];
            return noticeCell;
        }
    }else{
        AdiviserNodataCell *cell = [AdiviserNodataCell nibCellWithTableView:self.tableView];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}


#pragma mark -- AdviserIntroduceCellDelegate  介绍中第一组的展开箭头
- (void)adviserIntroduceCellAction:(NSString *)actionKey{
    if ([actionKey isEqualToString:@"adviserIntroduction_Down"]) {
        NSLog(@"展开介绍详情");
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
