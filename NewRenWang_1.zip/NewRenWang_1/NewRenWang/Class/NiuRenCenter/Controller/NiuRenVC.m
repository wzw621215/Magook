//
//  NiuRenVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/27.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NiuRenVC.h"
#import "SGSegmentedControl.h"

#import "adviserNoticePresenter.h"
#import "adviserintroductionPresenter.h"
#import "adviserAbilityPresentter.h"

#import "AdviserModel.h"
#import "NiuRenInfoRequest.h"

#import "NiuRenInfoVC.h"
#import "NiuRenOpinionVC.h"
#import "NiuRenCouserVC.h"

#import "NiuRenHeaderView.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

#import "ZXVideoPlayerController.h"
#import "ZXVideo.h"

@interface NiuRenVC ()<SGSegmentedControlStaticDelegate,UIScrollViewDelegate,NiuRenHeadDelegate,PlayVideoDelegate>

@property (nonatomic, strong) SGSegmentedControlStatic *topSView;
@property (nonatomic, strong) SGSegmentedControlBottomView *bottomSView;


@property (nonatomic,strong)NiuRenHeaderView *headerView; //头部视图
@property (nonatomic, strong)UIButton *liveBtn;         //底部正在直播
@property(nonatomic, strong)UIButton *foucsBtn;         //底部关注按钮

@property(nonatomic, retain)NSMutableArray *introductionArr;   //介绍数组

@property(nonatomic, copy)NSString *SectionCacheKey;

@property(nonatomic, strong)AdviserModel *adviserObj;

@property(nonatomic,strong)NiuRenInfoVC *niuRenInfoVC;

@property (nonatomic, strong) ZXVideoPlayerController *videoController;

@end

@implementation NiuRenVC

#pragma  mark - 跳转页面，隐藏导航栏
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

#pragma  mark - 显示导航栏
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIView *statusBarView=[[UIView alloc] initWithFrame:CGRectMake(0, 0,ScreenWIDTH, 20)];
    statusBarView.backgroundColor=[UIColor blackColor];
    [self.view addSubview:statusBarView];
    [self createUI];
    [self loadData];
    
    
}

#pragma mark - 添加子控制器
- (void)addChildVC {
    NiuRenInfoVC *oneVC = [[NiuRenInfoVC alloc] init];
    self.niuRenInfoVC = oneVC;
    [self addChildViewController:oneVC];
    
    NiuRenOpinionVC *twoVC = [[NiuRenOpinionVC alloc] init];
    twoVC.nrID = self.nrID;
    [self addChildViewController:twoVC];
    
    NiuRenCouserVC *threeVC = [[NiuRenCouserVC alloc] init];
    threeVC.delegate = self;
    threeVC.nrID = self.nrID;
    [self addChildViewController:threeVC];
    
    NSArray *childVC = @[oneVC, twoVC, threeVC];
    NSArray *title_arr = @[@"介绍", @"观点", @"公开课"];
    
    self.bottomSView = [[SGSegmentedControlBottomView alloc] initWithFrame:CGRectMake(0, 240, ScreenWIDTH, ScreenHEIGHT-50-240)];
    _bottomSView.childViewController = childVC;
    _bottomSView.backgroundColor = [UIColor clearColor];
    _bottomSView.delegate = self;
    //_bottomView.scrollEnabled = NO;
    [self.view addSubview:_bottomSView];
    
    self.topSView = [SGSegmentedControlStatic segmentedControlWithFrame:CGRectMake(0, CGRectGetMaxY(self.headerView.frame), ScreenWIDTH, 40) delegate:self childVcTitle:title_arr indicatorIsFull:NO];
    // 必须实现的方法
    [self.topSView SG_setUpSegmentedControlType:^(SGSegmentedControlStaticType *segmentedControlStaticType, NSArray *__autoreleasing *nomalImageArr, NSArray *__autoreleasing *selectedImageArr) {
        *segmentedControlStaticType = SGSegmentedControlStaticTypeDefault;
    }];
    [self.topSView SG_setUpSegmentedControlStyle:^(UIColor *__autoreleasing *segmentedControlColor, UIColor *__autoreleasing *titleColor, UIColor *__autoreleasing *selectedTitleColor, UIColor *__autoreleasing *indicatorColor, BOOL *isShowIndicor) {
        *selectedTitleColor = kRGBColor(200, 0, 0);
        *indicatorColor = kRGBColor(200, 0, 0);
    }];
    self.topSView.selectedIndex = 0;
    [self.view addSubview:_topSView];

}

- (void)createUI {
    
    NiuRenHeaderView *headView = [NiuRenHeaderView headView];
    headView.delegate = self;
    self.headerView = headView;
    [self.view addSubview:headView];
    
    [self addChildVC];
    
    

    UIView *buttonView = [[UIButton alloc]initWithFrame:CGRectMake(0, ScreenHEIGHT-50, ScreenWIDTH, 50)];
    buttonView.backgroundColor = [UIColor whiteColor];
    
    UIView *topLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWIDTH, 1)];
    topLine.backgroundColor = kRGBColor(230, 230, 230);
    [buttonView addSubview:topLine];
    
    UIButton *liveBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 1, ScreenWIDTH/2, buttonView.frame.size.height)];
    [liveBtn setTitle:@"正在直播" forState:UIControlStateSelected];
    [liveBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [liveBtn setImage:[UIImage imageNamed:@"live"] forState:UIControlStateSelected];
    
    [liveBtn setTitle:@"尚未直播" forState:UIControlStateNormal];
    [liveBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [liveBtn setImage:[UIImage imageNamed:@"live_black"] forState:UIControlStateNormal];
    
    liveBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    
    [liveBtn addTarget:self action:@selector(liveClick:) forControlEvents:UIControlEventTouchUpInside];
    [buttonView addSubview:liveBtn];
    self.liveBtn = liveBtn;
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(liveBtn.frame), 10, 1, 30)];
    line.backgroundColor = kRGBColor(230, 230, 230);
    [buttonView addSubview:line];
    
    UIButton *focusBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(liveBtn.frame)+1, 1, ScreenWIDTH/2, buttonView.frame.size.height)];
    [focusBtn setTitle:@"添加关注" forState:UIControlStateNormal];
    [focusBtn setTitle:@"取消关注" forState:UIControlStateSelected];
    [focusBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [focusBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateSelected];
    [focusBtn setImage:[UIImage imageNamed:@"addStock"] forState:UIControlStateNormal];
    [focusBtn setImage:[UIImage imageNamed:@"deleteStock"] forState:UIControlStateSelected];
    focusBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    [focusBtn addTarget:self action:@selector(focusClick:) forControlEvents:UIControlEventTouchUpInside];
    [buttonView addSubview:focusBtn];
    self.foucsBtn = focusBtn;
    [self.view addSubview:buttonView];
    
    
}

- (void)playVideo:(ZXVideo*)video{
    if (!self.videoController) {
        
//        self.videoController = [[ZXVideoPlayerController alloc] initWithFrame:CGRectMake(0, 0, kZXVideoPlayerOriginalWidth, kZXVideoPlayerOriginalHeight)];
        self.videoController = [[ZXVideoPlayerController alloc] initWithFrame:CGRectMake(0, 0, kZXVideoPlayerOriginalWidth, self.headerView.height)];
        __weak typeof(self) weakSelf = self;
        
        
        self.videoController.videoPlayerGoBackBlock = ^{
            
            __strong typeof(self) strongSelf = weakSelf;
            
            [strongSelf.navigationController popViewControllerAnimated:YES];
            [strongSelf.navigationController setNavigationBarHidden:NO animated:YES];
            
            [[NSUserDefaults standardUserDefaults] setObject:@0 forKey:@"ZXVideoPlayer_DidLockScreen"];
            
            strongSelf.videoController = nil;
        };
        
        self.videoController.videoPlayerWillChangeToOriginalScreenModeBlock = ^(){
            NSLog(@"切换为竖屏模式");
            
            
        };
        
        self.videoController.videoPlayerWillChangeToFullScreenModeBlock = ^(){
            NSLog(@"切换为全屏模式");
            weakSelf.videoController.frame = CGRectMake(0, 0, ScreenHEIGHT, ScreenWIDTH);
        };
        
        [self.videoController showInView:self.view];
    }
    
    self.videoController.video = video;
}


#pragma mark -请求介绍
- (void)loadData{
    NiuRenInfoRequest *request = [[NiuRenInfoRequest alloc] initWithNiuRenID:self.nrID];;
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            self.liveBtn.selected = ([response[@"roomingid"] integerValue]== -1)?NO:YES;
            self.foucsBtn.selected = [response[@"isfollw"] boolValue];
            
            AdviserModel *adviserModel = [[AdviserModel alloc] initWithDictionary:response];
            self.adviserObj = adviserModel;
            
            self.headerView.dataModel = adviserModel;
            
            //介绍第一组
            AdviserIntroduceModel *model = [[AdviserIntroduceModel alloc]init];
            model.reputArr = adviserModel.reputArray;        //称号数组
            model.introduction = adviserModel.introduction;  //介绍
            model.reputation = adviserModel.reputation;      //称号
            model.style = adviserModel.style;                //风格
            model.nextOpen = NO;
            NSMutableParagraphStyle *parastyle = [[NSMutableParagraphStyle alloc]init];
            [parastyle setLineSpacing:5.0];//行距
            [parastyle setFirstLineHeadIndent:10];
            
            NSDictionary *textGrap = @{
                                       NSFontAttributeName:[UIFont systemFontOfSize:14.0],
                                       NSKernAttributeName:@(1.5),
                                       NSParagraphStyleAttributeName:parastyle,
                                       };
            CGSize size = [model.introduction boundingRectWithSize:CGSizeMake(ScreenWIDTH-20, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin |NSStringDrawingUsesFontLeading attributes:textGrap context:nil].size;
            model.introductionHeight = size.height;
            
            adviserintroductionPresenter *introduction = [[adviserintroductionPresenter alloc] presenterDataModel: nil];
            introduction.itemList = @[model];
            
            
            //介绍第二组
            AbilityCommunityModel *abilityModel = [[AbilityCommunityModel alloc]init];
            abilityModel.ability = self.adviserObj.ability;
            
            adviserAbilityPresentter *ability = [[adviserAbilityPresentter alloc]presenterDataModel:nil];
            ability.itemList = @[abilityModel];
            
            //介绍:最新公告
            AdviserNoticeModel *noticeModel = [[AdviserNoticeModel alloc]init];
            noticeModel.notice = self.adviserObj.announcement;
            
            adviserNoticePresenter *notice = [[adviserNoticePresenter alloc] presenterDataModel:nil];
            notice.itemList = @[noticeModel];

            [self.introductionArr addObject:introduction];
            [self.introductionArr addObject:ability];
            [self.introductionArr addObject:notice];
            
            self.niuRenInfoVC.dataArray = self.introductionArr;
            [self.niuRenInfoVC reloadData];
        }
    }];
}


#pragma mark -- NiuRenHeadDelegate
- (void)tapKeyPath:(NSString *)key{
    if ([key isEqualToString:@"coures"]) {
        CNLog(@"点击课程");
        self.topSView.selectedIndex = 2;
        
    }else if ([key isEqualToString:@"fans"]){
        CNLog(@"点击粉丝");
    }else if ([key isEqualToString:@"opinions"]){
        CNLog(@"点击观点");
        self.topSView.selectedIndex = 1;
    }else if ([key isEqualToString:@"back"]){
        [self pop];
    }
}


#pragma mark -SGSegmentedControlStaticDelegate
- (void)SGSegmentedControlStatic:(SGSegmentedControlStatic *)segmentedControlStatic didSelectTitleAtIndex:(NSInteger)index {
    CNLog(@"index - - %ld", (long)index);
    // 计算滚动的位置
    CGFloat offsetX = index * self.view.frame.size.width;
    self.bottomSView.contentOffset = CGPointMake(offsetX, 0);
    [self.bottomSView showChildVCViewWithIndex:index outsideVC:self];
}
#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    // 计算滚动到哪一页
    NSInteger index = scrollView.contentOffset.x / scrollView.frame.size.width;
    // 1.添加子控制器view
    [self.bottomSView showChildVCViewWithIndex:index outsideVC:self];
    // 2.把对应的标题选中
    [self.topSView changeThePositionOfTheSelectedBtnWithScrollView:scrollView];
}

#pragma mark --处理点击事件
#pragma mark --添加关注
- (void)focusClick:(UIButton *)btn {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if (self.foucsBtn.selected) {
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.nrID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.foucsBtn.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.nrID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    
                    self.foucsBtn.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        LoginViewController *login = [[LoginViewController alloc] init];
        BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
        [self presentVc:nav];
    }
}

#pragma mark--正在直播
- (void)liveClick:(UIButton *)btn {
    btn.selected = !btn.selected;
    if (btn.selected) {
        //直播
        self.liveBtn.backgroundColor = kRGBColor(178, 14, 42);
        NSLog(@"正在直播");
    }else{
        //无直播
        self.liveBtn.backgroundColor = [UIColor whiteColor];
        NSLog(@"不在直播");
        
    }
}


- (NSMutableArray *)introductionArr{
    if (_introductionArr == nil) {
        _introductionArr = [NSMutableArray  array];
    }
    return _introductionArr;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
