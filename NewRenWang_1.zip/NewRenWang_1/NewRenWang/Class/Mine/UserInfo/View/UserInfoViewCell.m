//
//  UserInfoViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/1/20.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfoViewCell.h"

@interface UserInfoViewCell ()
/** 头像 */
@property (nonatomic, weak) UIImageView *headImage;
/** 用户名 */
@property (nonatomic, weak) UILabel *userName;
/** 账户信息 */
@property (nonatomic, weak) UILabel *account;
@end

@implementation UserInfoViewCell

- (void)layoutSubviews {
     [super layoutSubviews];
    self.headImage.frame = CGRectMake(15, 15, 65, 65);
    self.userName.frame = CGRectMake(CGRectGetMaxX(self.headImage.frame) + 15, 20, ScreenWIDTH - 140, 20);
    self.account.frame = CGRectMake(self.userName.mj_x, CGRectGetMaxY(self.userName.frame) + 15, ScreenWIDTH - 140, 15);
}

- (UIImageView *)headImage {
    if (_headImage == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        if ([self getImageFromLocal]){
            img.image = [self getImageFromLocal];
        }else{
            [img sd_setImageWithURL:[NSURL URLWithString:[UserInfoManage sharedManager].currentUserInfo.icon] placeholderImage:[UIImage imageNamed:@"me_icon"]];
        }
        [self.contentView addSubview:img];
        _headImage = img;
        img.layer.masksToBounds = YES;
        img.layerCornerRadius = 65 / 2;
    }
    return _headImage;
}

- (UILabel *)userName {
    if (!_userName) {
        UILabel *userName = [[UILabel alloc] init];
        [self.contentView addSubview:userName];
        _userName = userName;
        userName.text = [UserInfoManage sharedManager].currentUserInfo.nickname;
        userName.font = kFont(15);
    }
    return _userName;
}

- (UILabel *)account {
    if (!_account) {
        UILabel *account = [[UILabel alloc] init];
        [self.contentView addSubview:account];
        _account = account;
        account.text = [NSString stringWithFormat:@"账户：%@",[UserInfoManage sharedManager].currentUserInfo.uname];
        account.font = kFont(13);
        account.textColor = kRGBColor(125, 125, 125);
    }
    return _account;
}

#pragma mark - 创建图片路径
-(NSString *)getImageSavePath{
    // 本地沙盒目录
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    //指定新建文件夹路径
    NSString *imageFilePath = [path stringByAppendingPathComponent:@"MyIcon"];
    return imageFilePath;
}
#pragma mark - 根据文件路径获取图片的data
- (UIImage *)getImageFromLocal {
    NSData *data = [[NSFileManager defaultManager] contentsAtPath:[self getImageSavePath]];
    UIImage *image = [UIImage imageWithData:data];
    return image;
}
@end
