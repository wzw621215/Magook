//
//  UserInfoViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/1/20.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@class UserInfoModel;
@interface UserInfoViewCell : BaseTableViewCell
/** model */
@property (nonatomic, strong) UserInfoModel *userInfoModel;

@end
