//
//  UserSetViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/1/20.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserSetViewCell.h"

@interface UserSetViewCell ()
/** 设置图片 */
@property (nonatomic, weak) UIImageView *setImage;
/** 设置名字 */
@property (nonatomic, weak) UILabel *setLabel;
@end

@implementation UserSetViewCell

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath {
    UserSetViewCell *cell = [UserSetViewCell cellWithTableView:tableView];
     cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.section == 1) {
        cell.setLabel.text = @"修改密码";
        cell.setImage.image = [UIImage imageNamed:@"修改密码"];
    }
//    else if (indexPath.section == 2) {
//        if (indexPath.row == 0) {
//            cell.setLabel.text = @"手机认证";
//            cell.setImage.image = [UIImage imageNamed:@"手机认证"];
//        }else if (indexPath.row == 1){
//            cell.setLabel.text = @"邮箱认证";
//            cell.setImage.image = [UIImage imageNamed:@"邮箱认证"];
//        }else{
//            cell.setLabel.text = @"实名认证";
//            cell.setImage.image = [UIImage imageNamed:@"实名认证"];
//        }
//    }
    else {
         cell.setLabel.text = @"退出登录";
         cell.accessoryType = UITableViewCellAccessoryNone;
         cell.setImage.image = [UIImage imageNamed:@"out"];
    }
    return cell;
}


- (void)layoutSubviews {
    [super layoutSubviews];
    self.setImage.frame = CGRectMake(15, 10, 26, 26);
    self.setLabel.frame = CGRectMake(55, self.contentView.mj_h * 0.5 - 10, ScreenWIDTH - 65, 20);
    
}

- (UIImageView *)setImage {
    if (_setImage == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.image = [UIImage imageNamed:@"身份认证_s"];
        [self.contentView addSubview:img];
        _setImage = img;
    }
    return _setImage;
}

- (UILabel *)setLabel {
    if (!_setLabel) {
        UILabel *setLabel = [[UILabel alloc] init];
        [self.contentView addSubview:setLabel];
        _setLabel = setLabel;
        setLabel.text = @"设置";
        setLabel.font = kFont(14);
    }
    return _setLabel;
}
@end
