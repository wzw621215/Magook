//
//  UserInfoModel.h
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface UserInfoModel :BaseModel
/** 用户id */
@property (nonatomic, assign) NSInteger userid;
/** 用户名 */
@property (nonatomic, copy) NSString *uname;
/** 昵称 */
@property (nonatomic, copy) NSString *nickname;
/** 头像 */
@property (nonatomic, copy) NSString *icon;
/** 手机 */
@property (nonatomic, copy) NSString *mobile;
/** 邮箱 */
@property (nonatomic, copy) NSString *email;
/** 上次登录时间 */
@property (nonatomic, copy) NSString *previouslogintime;
/** 关注的老师数量*/
@property (nonatomic, assign)NSInteger myfollwcount;

/** 性别*/
@property (nonatomic,copy)NSString *gender;
/** 城市*/
@property (nonatomic,copy)NSString *city;
/** age*/
@property (nonatomic,copy)NSString *age;
/** stockAge*/
@property (nonatomic,copy)NSString *stockAge;
/** money*/
@property (nonatomic,copy)NSString *money;
/** style*/
@property (nonatomic,copy)NSString *style;
/** motto*/
@property (nonatomic,copy)NSString *motto;

@end
