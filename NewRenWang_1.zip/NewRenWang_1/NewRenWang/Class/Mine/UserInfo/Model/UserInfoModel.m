//
//  UserInfoModel.m
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfoModel.h"

@implementation UserInfoModel

- (instancetype)init {
    if (self =[super init]) {
        self.uname = @"牛人网";
        self.nickname = @"牛人网";
        self.mobile = @"182****1843";
        self.email = @"6055@qq.com";
        self.previouslogintime = @"2017/01/01";
        self.icon = @"me_icon";
        self.gender = @"未设置";
        self.city = @"未设置";
        self.age = @"未设置";
        self.stockAge = @"未设置";
        self.money = @"未设置";
        self.style = @"未设置";
        self.motto = @"未设置";
    }
    return self;
}

@end
