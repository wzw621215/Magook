//
//  CodeRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "CodeRequest.h"

@interface CodeRequest()
/** 验证码*/
@property (nonatomic, copy) NSString *code;
/** type */
@property (nonatomic, copy) NSString *phoneType;

@end

@implementation CodeRequest

- (instancetype)initWithCode:(NSString *)code phoneType:(NSString *)phoneType {
    if (self == [super init]) {
        _code = code;
        _phoneType = phoneType;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kBindPhoneCodeAPI;
}

- (NSDictionary *)params {
    return @{
             @"code":_code,
             @"type":_phoneType
             };
}

@end
