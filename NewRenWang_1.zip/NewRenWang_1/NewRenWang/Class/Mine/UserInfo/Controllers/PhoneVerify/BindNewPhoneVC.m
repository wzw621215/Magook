//
//  BindNewPhoneVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BindNewPhoneVC.h"
#import "PhoneVerifyRequest.h"
#import "VerifyCodeVC.h"

@interface BindNewPhoneVC ()
@property (weak, nonatomic) IBOutlet UIView *background;
@property (weak, nonatomic) IBOutlet UITextField *phoneNum;

@end

@implementation BindNewPhoneVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"手机绑定";
    [self.background.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.background.layer setBorderWidth:0.5];
    [self.background.layer setMasksToBounds:YES];
    self.background.layer.cornerRadius = 3.0f;
}
- (IBAction)sendCode:(id)sender {
    if ([NSString isValidateMobile:self.phoneNum.text]) {
        PhoneVerifyRequest *request = [[PhoneVerifyRequest alloc] initWithIphoneNum:self.phoneNum.text passW:nil];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                VerifyCodeVC *codeVerify = [[VerifyCodeVC alloc] init];
                codeVerify.phoneType = @"1";
                [self.navigationController pushViewController:codeVerify animated:YES];
            }else{
                [CNNavigationBarHUD showError:@"修改出错未能修改"];
            }
        }];
    }else{
        [CNNavigationBarHUD showError:@"输入正确的手机号"];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
