//
//  PhoneVerifyRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "PhoneVerifyRequest.h"
@interface PhoneVerifyRequest()

/** 手机号*/
@property (nonatomic, copy) NSString *iphoneNum;
/** 当前用户密码 */
@property (nonatomic, copy) NSString *passW;

@end

@implementation PhoneVerifyRequest

- (instancetype)initWithIphoneNum:(NSString *)iphoneNum passW:(NSString *)passW {
    if (self == [super init]) {
        _iphoneNum = iphoneNum;
        _passW = passW;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kBindPhoneAPI;
}

- (NSDictionary *)params {
    if (_passW == nil) {
        return @{@"mobile":_iphoneNum};
    }else{
        return @{
                 @"mobile":_iphoneNum,
                 @"psd":_passW
                 };
    }
}

@end
