//
//  VerifyCodeVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "VerifyCodeVC.h"
#import "UITextField+PlaceholderColor.h"
#import "CodeRequest.h"
#import "BindPhoneSucesVC.h"

@interface VerifyCodeVC ()
@property (weak, nonatomic) IBOutlet UITextField *code;
@property (weak, nonatomic) IBOutlet UIView *codeView;

@end

@implementation VerifyCodeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"手机绑定";
    [self.codeView.layer setMasksToBounds:YES];
    [self.codeView.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.codeView.layer setBorderWidth:0.5];
    self.codeView.layer.cornerRadius = 3;
    [self.code placeholderColor:kBlackColor];
    
}
- (IBAction)codeVerify:(id)sender {
    if ([self.code.text isValid]&&[self.code.text isOnlyNumbers]) {
        CodeRequest *codeRequest = [[CodeRequest alloc] initWithCode:self.code.text phoneType:self.phoneType];
        [codeRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                BindPhoneSucesVC *bindSuccess = [[BindPhoneSucesVC alloc] init];
                [self.navigationController pushViewController:bindSuccess animated:YES];
            }
        }];
    }else{
        [CNNavigationBarHUD showError:@"请输入正确验证码"];
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
