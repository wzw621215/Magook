//
//  PhoneVerifyVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "PhoneVerifyVC.h"
#import "PhoneVerifyRequest.h"
#import "UserInfoManage.h"
#import "VerifyCodeVC.h"

@interface PhoneVerifyVC ()

@property (weak, nonatomic) IBOutlet UILabel *currentNum;
@property (weak, nonatomic) IBOutlet UITextField *loginMima;
@property (weak, nonatomic) IBOutlet UITextField *iphoneNewNum;
@property (weak, nonatomic) IBOutlet UIButton *cancel;

@end

@implementation PhoneVerifyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"换绑手机";
    [self.cancel.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.cancel.layer setBorderWidth:0.5];
    [self.cancel.layer setMasksToBounds:YES];
    self.currentNum.text = [NSString stringWithFormat:@"您当前绑定的手机号：%@", [UserInfoManage sharedManager].currentUserInfo.mobile];
}

- (IBAction)cancel:(id)sender {
    
    
    
    
}
- (IBAction)determine:(id)sender {
    if ([self.loginMima.text isBlank] ||[self.iphoneNewNum.text isBlank]) {
        [CNNavigationBarHUD showError:@"请输入"];
    }else if (![NSString isValidateMobile:self.iphoneNewNum.text]) {
        [CNNavigationBarHUD showError:@"输入正确的手机号"];
    }else {
        PhoneVerifyRequest *request = [[PhoneVerifyRequest alloc] initWithIphoneNum:self.iphoneNewNum.text passW:self.loginMima.text];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                VerifyCodeVC *codeVerify = [[VerifyCodeVC alloc] init];
                codeVerify.phoneType = @"2";
                [self.navigationController pushViewController:codeVerify animated:YES];
            }else{
                [CNNavigationBarHUD showError:@"修改出错未能修改"];
            }
        }];
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
