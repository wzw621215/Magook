//
//  UserInfoViewController.m
//  NewRenWang
//
//  Created by YJ on 17/1/19.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfoViewController.h"
#import "UserInfoViewCell.h"
#import "UserSetViewCell.h"
#import "UserInfoModel.h"
#import "ChangePassWordVC.h"
#import "PhoneVerifyVC.h"
#import "BindNewPhoneVC.h"
#import "EmailVerifyVC.h"
#import "EmailBindViewController.h"
#import "NameVerifyVC.h"
#import "UserInfomationVC.h"
@interface UserInfoViewController ()

@end

@implementation UserInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"我的帐户";
    self.tableView.scrollEnabled = NO;
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 95;
    } else {
        return 50;
    }
}

- (NSInteger)numberOfSections {
//    return 4; // 显示三个认证
    return 3;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
//    if (section == 2 ) {
//        return 3;
//    } else {
//        return 1;
//    }
    return 1;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0.1;
    } else {
        return 10;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    return 0.1;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
       UserInfoViewCell *cell = [UserInfoViewCell cellWithTableView:self.tableView];
       cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
       return cell;
    } else {
        UserSetViewCell *cell = [UserSetViewCell cellOfTableView:self.tableView indexPath:indexPath];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        UserInfomationVC *userInfomation = [[UserInfomationVC alloc] init];
        [self.navigationController pushViewController:userInfomation animated:YES];
    }else if (indexPath.section == 1) {
        //修改密码
        ChangePassWordVC *changePsd = [[ChangePassWordVC alloc] init];
        [self.navigationController pushViewController:changePsd animated:YES];
    }
//    else if (indexPath.section == 2){
//        if (indexPath.row == 0) {
//            //手机认证
//            if ([[UserInfoManage sharedManager].currentUserInfo.mobile isValid]) {
//                PhoneVerifyVC *bindPhone = [[PhoneVerifyVC alloc] init];
//                [self.navigationController pushViewController:bindPhone animated:YES];
//            }else{
//                BindNewPhoneVC *bindPhone = [[BindNewPhoneVC alloc] init];
//                [self.navigationController pushViewController:bindPhone animated:YES];
//            }
//        }else if (indexPath.row == 1){
//            //邮箱认证
//            if ([[UserInfoManage sharedManager].currentUserInfo.email isEffectiveEmail]) {
//                EmailBindViewController *emailBindVC = [[EmailBindViewController alloc] init];
//                [self.navigationController pushViewController:emailBindVC animated:YES];
//            }else{
//                EmailVerifyVC *emailVerify = [[EmailVerifyVC alloc] init];
//                [self.navigationController pushViewController:emailVerify animated:YES];
//            }
//        }else{
//            //实名认证
//            NameVerifyVC *nameVerify = [[NameVerifyVC alloc] init];
//            [self.navigationController pushViewController:nameVerify animated:YES];
//        }
//    }
    else {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否退出登录" preferredStyle:(UIAlertControllerStyleAlert)];
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //退出登录
            [[UserInfoManage sharedManager] didLoginOut];
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [alertController addAction:action];
        UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertController addAction:action1];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
