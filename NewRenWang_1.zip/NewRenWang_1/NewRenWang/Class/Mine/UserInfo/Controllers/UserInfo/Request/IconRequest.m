//
//  IconRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "IconRequest.h"
@interface IconRequest ()

@property (nonatomic, copy) NSString * avatar;

@end

@implementation IconRequest

- (instancetype)initWithAvatar:(NSString *)avatar {
    if (self == [super init]) {
        _avatar = avatar;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kIconAPI;
}

- (NSDictionary *)params {
    return @{
             @"avatar":_avatar
             };
}

@end
