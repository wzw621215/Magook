//
//  GenderRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "GenderRequest.h"
@interface GenderRequest ()

@property (nonatomic, assign) NSInteger gender;

@end

@implementation GenderRequest

- (instancetype)initWithGender:(NSInteger )gender {
    if (self == [super init]) {
        _gender = gender;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kGenderAPI;
}

- (NSDictionary *)params {
    return @{
             @"sex":@(_gender)
             };
}


@end
