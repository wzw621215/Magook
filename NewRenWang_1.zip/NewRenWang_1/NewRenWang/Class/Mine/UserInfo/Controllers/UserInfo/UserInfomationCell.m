//
//  UserInfomationCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfomationCell.h"
#import "UserInfomation.h"

@interface UserInfomationCell()

/** 设置图片 */
@property (nonatomic, weak) UIImageView *icon;
/** 设置名字 */
@property (nonatomic, weak) UILabel *title;
/**右侧的箭头*/
@property (nonatomic,weak)UIImageView *arrowImg;

@property (nonatomic,weak)UIView *line;

@property (nonatomic,weak)UILabel *content;

@end

@implementation UserInfomationCell

#pragma mark- 更新数据
- (void)updateDataBy:(NSDictionary *)dictionary {
    self.title.text = dictionary[kInfomationTitle];
    BOOL isHaveArrow = [dictionary[kInfomationArrow] boolValue];
    self.arrowImg.hidden = !isHaveArrow;
    BOOL isHaveImg = [dictionary[kInfomationIsHaveImg] boolValue];
    if (isHaveImg) {
        self.icon.hidden = NO;
        if ([self getImageFromLocal]){
            self.icon.image = [self getImageFromLocal];
        }else{
            [self.icon sd_setImageWithURL:[NSURL URLWithString:[UserInfoManage sharedManager].currentUserInfo.icon] placeholderImage:[UIImage imageNamed:@"me_icon"]];
        }
        self.content.text = @"";
    }else{
        self.icon.hidden = YES;
        self.content.text = dictionary[kInfomationValue];
    }
}
- (UILabel *)title {
    if (!_title) {
        UILabel *title = [[UILabel alloc] init];
        [self.contentView addSubview:title];
        title.textColor = kBlackColor;
        title.font = kFont(14);
        _title = title;
    }
    return _title;
}
- (UIImageView *)icon {
    if (_icon == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.layer.masksToBounds = YES;
        img.layer.cornerRadius = 30;
        [self.contentView addSubview:img];
        _icon = img;
    }
    return _icon;
}
- (UILabel *)content {
    if (!_content) {
        UILabel *content = [[UILabel alloc] init];
        [self.contentView addSubview:content];
        content.textColor = kRGBColor(125, 125, 125);
        content.font = kFont(14);
        content.textAlignment = NSTextAlignmentRight;
        _content = content;
    }
    return _content;
}
- (UIImageView *)arrowImg {
    if (_arrowImg == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.image = [UIImage imageNamed:@"arrow_right"];
        [self.contentView addSubview:img];
        _arrowImg = img;
    }
    return _arrowImg;
}
- (UIView *)line{
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(240, 240, 240);
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(15);
        make.width.equalTo(@40);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.height.equalTo(@30);
    }];
    [self.arrowImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.width.height.equalTo(@15);
        make.centerY.equalTo(self.contentView.mas_centerY);
    }];
    [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.arrowImg.mas_left).offset(-25);
        make.left.equalTo(self.title.mas_right).offset(15);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.height.equalTo(@30);
    }];
    
    [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.arrowImg.mas_left).offset(-25);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.width.height.equalTo(@60);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right);
        make.left.equalTo(self.contentView.mas_left);
        make.bottom.equalTo(self.contentView.mas_bottom);
        make.height.equalTo(@1);
    }];
}
#pragma mark - 创建图片路径
-(NSString *)getImageSavePath{
    // 本地沙盒目录
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    //指定新建文件夹路径
    NSString *imageFilePath = [path stringByAppendingPathComponent:@"MyIcon"];
    return imageFilePath;
}
#pragma mark - 根据文件路径获取图片的data
- (UIImage *)getImageFromLocal {
    NSData *data = [[NSFileManager defaultManager] contentsAtPath:[self getImageSavePath]];
    UIImage *image = [UIImage imageWithData:data];
    return image;
}

@end
