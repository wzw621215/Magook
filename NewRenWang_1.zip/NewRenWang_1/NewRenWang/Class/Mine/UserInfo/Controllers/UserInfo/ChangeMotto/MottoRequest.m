//
//  MottoRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MottoRequest.h"
@interface MottoRequest()

/**签名*/
@property (nonatomic,copy)NSString *autograph;

@end

@implementation MottoRequest

- (instancetype)initWithMotto:(NSString * ) autograph{
    if (self == [super init]) {
        _autograph = autograph;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kMottoAPI;
}

- (NSDictionary *)params {
    return @{
             @"autograph":_autograph
             };
}

@end
