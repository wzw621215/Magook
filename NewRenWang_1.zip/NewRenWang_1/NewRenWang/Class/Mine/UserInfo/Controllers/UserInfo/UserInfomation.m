//
//  UserInfomation.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfomation.h"
#import "UserInfoManage.h"

@implementation UserInfomation

+ (NSArray *)infomationDataSource:(NSMutableDictionary *)dic{
    NSDictionary *dic1 = @{
                           kInfomationIsHaveImg :@(YES),
                           kInfomationImg :dic[kIcon],
                           kInfomationTitle :@"头像",
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic2 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle:@"昵称",
                           kInfomationValue:dic[kNickName],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic3 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"账号",
                           kInfomationValue:dic[kUname],
                           kInfomationArrow:@(NO)
                           };
    NSDictionary *dic4 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"性别",
                           kInfomationValue:dic[KGender],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic5 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"城市",
                           kInfomationValue:dic[kCity],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic6 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"年龄",
                           kInfomationValue:dic[KAge],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic7 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"股龄",
                           kInfomationValue:dic[kStockAge],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic8 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"资金",
                           kInfomationValue:dic[kMoney],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic9 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"风格",
                           kInfomationValue:dic[kStyle],
                           kInfomationArrow:@(YES)
                           };
    NSDictionary *dic10 = @{
                           kInfomationIsHaveImg :@(NO),
                           kInfomationTitle :@"签名",
                           kInfomationValue:dic[kMotto],
                           kInfomationArrow:@(YES)
                           };
    return @[@[dic1,dic2,dic3],@[dic4,dic5,dic6,dic7,dic8,dic9,dic10]];
}

@end
