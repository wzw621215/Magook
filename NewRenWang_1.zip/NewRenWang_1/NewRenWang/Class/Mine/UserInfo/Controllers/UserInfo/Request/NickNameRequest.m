//
//  NickNameRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NickNameRequest.h"
@interface NickNameRequest()

@property (nonatomic, copy) NSString *nickName;

@end

@implementation NickNameRequest

- (instancetype)initWithNickName:(NSString *)nickName {
    if (self == [super init]) {
        _nickName = nickName;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kNickNameAPI;
}

- (NSDictionary *)params {
    return @{
             @"nickName":_nickName
             };
}

@end
