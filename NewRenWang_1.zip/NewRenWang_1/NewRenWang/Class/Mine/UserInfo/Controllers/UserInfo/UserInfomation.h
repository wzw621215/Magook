//
//  UserInfomation.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <Foundation/Foundation.h>
static NSString *kInfomationTitle  = @"kInfomationTitle";
static NSString *kInfomationValue  = @"kInfomationValue";
static NSString *kInfomationArrow  = @"kInfomationArrow";
static NSString *kInfomationImg    = @"kInfomationImg";
static NSString *kInfomationIsHaveImg    = @"kInfomationIsHaveImg";

static NSString *kIcon     = @"icon";
static NSString *kNickName = @"nickName";
static NSString *kUname    = @"uname";
static NSString *KGender   = @"gender";
static NSString *kCity     = @"city";
static NSString *KAge      = @"age";
static NSString *kStockAge = @"stockAge";
static NSString *kMoney    = @"money";
static NSString *kStyle    = @"style";
static NSString *kMotto    = @"motto";

@interface UserInfomation : NSObject

+ (NSArray *)infomationDataSource:(NSMutableDictionary *)dic;

@end
