//
//  UserInfomationVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UserInfomationVC.h"
#import "UserInfomation.h"
#import "UserInfomationCell.h"
#import "UserInfoManage.h"
#import "SelectView.h"
#import "MySheetView.h"
#import "MottoViewController.h"
#import "NickNameRequest.h"
#import "GenderRequest.h"
#import "IconRequest.h"
#import "GTMBase64.h"

@interface UserInfomationVC ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,MottoDelegate>{
    NSArray *_infomationArray;
}
@property (nonatomic,strong)NSMutableDictionary *dic;
@property (nonatomic,strong)UserInfoModel *model;

@end

@implementation UserInfomationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"个人信息";
//    self.tableView.scrollEnabled = NO;
    self.needCellSepLine = NO;
    self.dic = [NSMutableDictionary dictionary];
    self.model = [UserInfoManage sharedManager].currentUserInfo;
    [self.dic setObject:_model.icon forKey:kIcon];
    [self.dic setObject:_model.nickname forKey:kNickName];
    [self.dic setObject:_model.uname forKey:kUname];
    [self.dic setObject:_model.gender forKey:KGender];
    [self.dic setObject:_model.city forKey:kCity];
    [self.dic setObject:_model.age forKey:KAge];
    [self.dic setObject:_model.stockAge forKey:kStockAge];
    [self.dic setObject:_model.money forKey:kMoney];
    [self.dic setObject:_model.style forKey:kStyle];
    [self.dic setObject:_model.motto forKey:kMotto];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0 && indexPath.row == 0) {
        return 90;
    }
    return 50;
}

- (NSInteger)numberOfSections {
    return 2;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 3;
    }
    return 7;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else {
        return 10;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    return 0.1;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    _infomationArray = [UserInfomation infomationDataSource:self.dic];
    NSArray *listSectionArray = _infomationArray[indexPath.section];
    NSDictionary *dic = listSectionArray[indexPath.row];
    UserInfomationCell *cell = [UserInfomationCell cellWithTableView:self.tableView];
    [cell updateDataBy:dic];
    return cell;
}


- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            //编辑头像
            [self setupImagePickerController];
        }else if (indexPath.row == 1){
            //修改昵称
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TextFieldType;
            selectView.isShowCancelBtn = YES;
            selectView.isShowSureBtn = YES;
            selectView.isShowTitle = YES;
            selectView.labelText = self.model.nickname;
            [selectView addTitleArray:nil andTitleString:@"修改昵称" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                
            } withSureButtonBlock:^(NSString *_Nullable string){
                if (![string isEqualToString:self.model.nickname]) {
                    self.model.nickname = string;
                    [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                    [self.dic setObject:self.model.nickname forKey:kNickName];
                    [self reloadData];
                    NickNameRequest *request = [[NickNameRequest alloc] initWithNickName:string];
                    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                        if (success) {
                            [CNNavigationBarHUD showSuccess:@"修改成功"];
                        }
                    }];
                }
                
            }];
            [self.view addSubview:selectView];
        }
    }else{
        if (indexPath.row == 0) {
            //修改性别
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TableViewType;
            selectView.isShowCancelBtn = NO;
            selectView.isShowSureBtn = NO;
            selectView.isShowTitle = YES;
            selectView.contentText = self.model.gender;
            NSArray *arr= @[@"男",@"女",@"保密"];
            [selectView addTitleArray:arr andTitleString:@"修改性别" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                if (![string isEqualToString:self.model.gender]) {
                    self.model.gender = string;
                    [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                    [self.dic setObject:self.model.gender forKey:KGender];
                    [self reloadData];
//                    GenderRequest *request = [[GenderRequest alloc] initWithGender:index+1];
//                    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
//                        if (success) {
//                            [CNNavigationBarHUD showSuccess:@"修改成功"];
//                        }
//                    }];
                }
                
            } withSureButtonBlock:^(NSString *_Nullable string){
                CNLog(@"%@",string);
            }];
            [self.view addSubview:selectView];
        }else if (indexPath.row == 1){
            //修改城市
        }else if (indexPath.row == 2){
            //修改年龄
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TableViewType;
            selectView.isShowCancelBtn = NO;
            selectView.isShowSureBtn = NO;
            selectView.isShowTitle = YES;
            selectView.contentText = self.model.age;
            NSArray *arr= @[@"60后",@"70后",@"80后",@"90后"];
            [selectView addTitleArray:arr andTitleString:@"编辑年龄" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                self.model.age = string;
                [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                [self.dic setObject:self.model.age forKey:KAge];
                [self reloadData];
            } withSureButtonBlock:^(NSString *_Nullable string){
                CNLog(@"%@",string);
            }];
            [self.view addSubview:selectView];
        }else if (indexPath.row == 3){
            //修改股龄
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TableViewType;
            selectView.isShowCancelBtn = NO;
            selectView.isShowSureBtn = NO;
            selectView.isShowTitle = YES;
            selectView.contentText = self.model.stockAge;
            NSArray *arr= @[@"0-1年",@"1-3年",@"3-10年",@"10年以上"];
            [selectView addTitleArray:arr andTitleString:@"编辑股龄" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                self.model.stockAge = string;
                [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                [self.dic setObject:self.model.stockAge forKey:kStockAge];
                [self reloadData];
            } withSureButtonBlock:^(NSString *_Nullable string){
                CNLog(@"%@",string);
            }];
            [self.view addSubview:selectView];
        }else if (indexPath.row == 4){
            //修改资金
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TableViewType;
            selectView.isShowCancelBtn = NO;
            selectView.isShowSureBtn = NO;
            selectView.isShowTitle = YES;
            selectView.contentText = self.model.money;
            NSArray *arr= @[@"2万以下",@"2-10万",@"10-30万",@"30-100万",@"100万以上"];
            [selectView addTitleArray:arr andTitleString:@"编辑资金" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                self.model.money = string;
                [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                [self.dic setObject:self.model.money forKey:kMoney];
                [self reloadData];
            } withSureButtonBlock:^(NSString *_Nullable string){
                CNLog(@"%@",string);
            }];
            [self.view addSubview:selectView];
        }else if (indexPath.row == 5){
            //修改风格
            SelectView *selectView = [[SelectView alloc] initWithFrame:self.view.bounds];
            selectView.choose_type = TableViewType;
            selectView.isShowCancelBtn = NO;
            selectView.isShowSureBtn = NO;
            selectView.isShowTitle = YES;
            selectView.contentText = self.model.style;
            NSArray *arr= @[@"超短线(T+0/1)",@"短线(T+5/20)",@"中长线"];
            [selectView addTitleArray:arr andTitleString:@"编辑风格" animated:YES completionHandler:^(NSString * _Nullable string, NSInteger index) {
                self.model.style = string;
                [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
                [self.dic setObject:self.model.style forKey:kStyle];
                [self reloadData];
            } withSureButtonBlock:^(NSString *_Nullable string){
                CNLog(@"%@",string);
            }];
            [self.view addSubview:selectView];
        }else if (indexPath.row == 6){
            //修改签名
            MottoViewController *motto = [[MottoViewController alloc] init];
            motto.delegate = self;
            [self.navigationController pushViewController:motto animated:YES];
        }
    }
}

#pragma mark - 实现代理MottoDelegate  修改签名
- (void)postWithMotto:(NSString *)motto {
    self.model.motto = motto;
    [[UserInfoManage sharedManager] resetUserInfoWithUserInfo:self.model];
    [self.dic setObject:self.model.motto forKey:kMotto];
    [self reloadData];
}

#pragma mark - 选取相册照片或者拍照
- (void)setupImagePickerController {
    //调用系统相册的类
    UIImagePickerController *pickerController = [[UIImagePickerController alloc] init];
    //设置选取的照片是否可编辑
    pickerController.allowsEditing = YES;
    //选择完成图片或则点击取消按钮都是通过代理来操作我们所需要的逻辑过程
    pickerController.delegate = self;

    MySheetView *view = [MySheetView new];
    view.buttonNameArray = @[@"拍照",@"从相册选择"];
    [view handleMyBlock:^(UIButton *selectButton, NSString *title) {
        if ([title isEqualToString:@"拍照"]) {
            //设置相册呈现的样式
            pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;             //设置相机呈现的样式
            
        }else if([title isEqualToString:@"从相册选择"]){
            pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;        //设置相册呈现的样式
        }
        //使用模态呈现相册
        [self.navigationController presentViewController:pickerController
                                                animated:YES
                                              completion:^{
                                                  
                                              }];
    }];
    [view show:self];
}
#pragma mark - 照片选择完成和取消之后都是通过代理来实现，如果不实现点击之后的方法系统就无法王下走就会卡在照片界面
//选择照片完成之后的代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    NSLog(@"%s,info == %@",__func__,info);
    
    UIImage *resultImage = [self fixOrientation:[info objectForKey:UIImagePickerControllerEditedImage]];

    [self saveImageToPhotos:resultImage];
    
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    [self reloadData];
}
//点击取消按钮所执行的方法
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    //这是捕获点击右上角cancel按钮所触发的事件，如果我们需要在点击cancel按钮的时候做一些其他逻辑操作。就需要实现该代理方法，如果不做任何逻辑操作，就可以不实现
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)saveImageToPhotos:(UIImage*)image {
    NSString *imageFilePath = [self getImageSavePath];
    NSData *data = nil;
    //判断图片是不是png格式的文件
    NSString *mimeType = nil;
    if (UIImagePNGRepresentation(image)) {
        //返回为png图像。
        data = UIImagePNGRepresentation(image);
        mimeType = @"image/png";
    }else {
        // 返回为JPEG图像   将取得的图片写入本地的沙盒中，其中0.5表示压缩比例，1表示不压缩，数值越小压缩比例越大
        data = UIImageJPEGRepresentation(image, 0.5);
        mimeType = @"image/jpeg";
        
    }
    if (data.length/1024/1204 > 5) {
        [CNNavigationBarHUD showError:@"图片过大"];
        return ;
    }
    NSString * base64Str = [NSString stringWithFormat:@"data:%@;base64,%@",mimeType,[GTMBase64 stringByEncodingData:data]];
//    NSString * base64Str = [NSString stringWithFormat:@"data:%@;base64,%@",mimeType,[data base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength]];
    
    IconRequest *request = [[IconRequest alloc] initWithAvatar:base64Str];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            
        }
    }];
    
    BOOL success = [[NSFileManager defaultManager] createFileAtPath:imageFilePath contents:data attributes:nil];
    if (success){
        NSLog(@"写入本地成功");
    }
    
}


#pragma mark - 裁剪图片
- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize image:(UIImage *)resultImg
{
    UIImage *sourceImage = resultImg;
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth= width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width= scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil)
        NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}

- (UIImage *)fixOrientation:(UIImage *)aImage {
    if (aImage.imageOrientation == UIImageOrientationUp)
        
        return aImage;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (aImage.imageOrientation) {
            
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, aImage.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, aImage.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        default:
            break;
    }
    
    switch (aImage.imageOrientation) {
            
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, aImage.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        default:
            break;
    }
    
    CGContextRef ctx = CGBitmapContextCreate(NULL, aImage.size.width, aImage.size.height,
                                             
                                             CGImageGetBitsPerComponent(aImage.CGImage), 0,
                                             CGImageGetColorSpace(aImage.CGImage),
                                             CGImageGetBitmapInfo(aImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (aImage.imageOrientation) {
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.height,aImage.size.width), aImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.width,aImage.size.height), aImage.CGImage);
            break;
    }
    
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}
#pragma mark - 创建图片路径
-(NSString *)getImageSavePath{
    // 本地沙盒目录
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    //指定新建文件夹路径
    NSString *imageFilePath = [path stringByAppendingPathComponent:@"MyIcon"];
    return imageFilePath;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
