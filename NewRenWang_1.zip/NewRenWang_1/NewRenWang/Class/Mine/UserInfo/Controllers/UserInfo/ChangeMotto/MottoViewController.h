//
//  MottoViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"
@protocol MottoDelegate <NSObject>

- (void)postWithMotto:(NSString *)motto;

@end

@interface MottoViewController : BaseViewController

@property (nonatomic,weak)id <MottoDelegate> delegate;

@end
