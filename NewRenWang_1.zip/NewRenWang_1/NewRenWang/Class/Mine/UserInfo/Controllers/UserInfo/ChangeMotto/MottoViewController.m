//
//  MottoViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MottoViewController.h"
#import "UIPlaceholderTextView.h"
#import "MottoRequest.h"
#define MAX_LIMIT_NUMS 50   // 来限制最大输入只能50个字符

@interface MottoViewController ()<UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *limitNum;
@property (weak, nonatomic) IBOutlet UIPlaceholderTextView *content;

@end

@implementation MottoViewController

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [self.content removeobserver];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.content addObserver];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIButton* someButton= [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 30)];
    
    [someButton setTitle:@"保存" forState:UIControlStateNormal];
    someButton.titleLabel.font = kFont(16.0f);
    [someButton setTitleColor:kWhiteColor forState:0];
    [someButton setShowsTouchWhenHighlighted:NO];
    [someButton addTarget:self action:@selector(sendMottoToServer) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem* someBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:someButton];
    [self.navigationItem setRightBarButtonItem:someBarButtonItem];
    
    self.title = @"修改签名";
    self.content.layer.cornerRadius = 5;
    self.content.layer.masksToBounds = YES;
    self.content.layer.borderColor = kGrayColor.CGColor;
    self.content.layer.borderWidth = 0.5;
    self.content.delegate = self;
    self.content.placeholder = @"请输入您的签名";
    [self.view bringSubviewToFront:_limitNum];
}

- (void) sendMottoToServer{
    if ([self.delegate respondsToSelector:@selector(postWithMotto:)]) {
        [self.delegate postWithMotto:self.content.text];
    }
//    MottoRequest *request = [[MottoRequest alloc] initWithMotto:self.content.text];
//    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
//        if (success) {
//            
//        }
//    }];
}


#pragma mark - UITextViewDelegate
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSString *comcatstr = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSInteger caninputlen = MAX_LIMIT_NUMS - comcatstr.length;
    
    if (caninputlen >= 0) {
        return YES;
    } else {
        NSInteger len = text.length + caninputlen;
        
        // 防止当text.length + caninputlen < 0时，使得rg.length为一个非法最大正数出错
        NSRange rg = {0,MAX(len,0)};
        if (rg.length > 0) {
            NSString *s = [text substringWithRange:rg];
            [textView setText:[textView.text stringByReplacingCharactersInRange:range withString:s]];
        }
        return NO;
    }
}


- (void)textViewDidChange:(UITextView *)textView {
    NSString  *nsTextContent = textView.text;
    NSInteger existTextNum = nsTextContent.length;
    
    if (existTextNum > MAX_LIMIT_NUMS) {
        // 截取到最大位置的字符
        NSString *s = [nsTextContent substringToIndex:MAX_LIMIT_NUMS];
        [textView setText:s];
    }
    self.limitNum.text = [NSString stringWithFormat:@"%ld/%d",MIN(MAX_LIMIT_NUMS, existTextNum),MAX_LIMIT_NUMS];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
