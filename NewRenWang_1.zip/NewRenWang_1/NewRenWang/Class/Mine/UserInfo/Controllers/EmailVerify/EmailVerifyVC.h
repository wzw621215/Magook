//
//  EmailVerifyVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface EmailVerifyVC : BaseViewController

@end
