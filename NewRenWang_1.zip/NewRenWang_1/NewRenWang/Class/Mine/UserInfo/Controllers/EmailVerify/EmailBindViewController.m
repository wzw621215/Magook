//
//  EmailBindViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "EmailBindViewController.h"
#import "UserInfoManage.h"
#import "EmailSuccessVC.h"
#import "EmailRequest.h"

@interface EmailBindViewController ()
@property (weak, nonatomic) IBOutlet UILabel *currentEmail;
@property (weak, nonatomic) IBOutlet UIButton *cancel;
@property (weak, nonatomic) IBOutlet UITextField *mima;
@property (weak, nonatomic) IBOutlet UITextField *emailNew;

@end

@implementation EmailBindViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"换绑邮箱";
    [self.cancel.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.cancel.layer setBorderWidth:0.5];
    [self.cancel.layer setMasksToBounds:YES];
    self.cancel.layer.cornerRadius = 3.0f;
    self.currentEmail.text = [NSString stringWithFormat:@"您当前绑定的邮箱：%@", [UserInfoManage sharedManager].currentUserInfo.email];
}
- (IBAction)sendEmail:(id)sender {
    
    
    
    if ([self.mima.text isBlank] ||[self.emailNew.text isBlank]) {
        [CNNavigationBarHUD showError:@"请输入"];
    }else if (![self.emailNew.text isEffectiveEmail]) {
        [CNNavigationBarHUD showError:@"请填写有效的邮箱"];
    }else {
        EmailSuccessVC *emailSucces = [[EmailSuccessVC alloc] init];
        emailSucces.emailStr = self.emailNew.text;
        [self.navigationController pushViewController:emailSucces animated:YES];
//        EmailRequest *emailRequest = [[EmailRequest alloc] initWithEmail:self.emailNew.text passW:nil];
//        [emailRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
//            if (success) {
//
//            }
//        }];
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
