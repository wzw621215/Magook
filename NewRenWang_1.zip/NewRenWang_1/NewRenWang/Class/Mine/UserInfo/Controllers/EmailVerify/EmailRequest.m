//
//  EmailRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "EmailRequest.h"
@interface EmailRequest()

/** email*/
@property (nonatomic, copy) NSString *email;
/** 当前用户密码 */
@property (nonatomic, copy) NSString *passW;

@end

@implementation EmailRequest

- (instancetype)initWithEmail:(NSString *)email passW:(NSString *)passW {
    if (self == [super init]) {
        _email = email;
        _passW = passW;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kBindEmailAPI;
}

- (NSDictionary *)params {
    return _passW ? @{
                      @"email":_email,
                      @"psd":_passW
                      }  : @{
                             @"email":_email
                             };
}


@end
