//
//  EmailVerifyVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "EmailVerifyVC.h"
#import "EmailRequest.h"
#import "EmailSuccessVC.h"

@interface EmailVerifyVC ()

@property (weak, nonatomic) IBOutlet UIView *background;

@property (weak, nonatomic) IBOutlet UITextField *email;

@end

@implementation EmailVerifyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"邮箱绑定";
    [self.background.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.background.layer setBorderWidth:0.5];
    [self.background.layer setMasksToBounds:YES];
    self.background.layer.cornerRadius = 3.0f;
    
}

- (IBAction)sendEmail:(id)sender {
    if ([self.email.text isEffectiveEmail]) {
        EmailSuccessVC *emailSucces = [[EmailSuccessVC alloc] init];
        emailSucces.emailStr = self.email.text;
        [self.navigationController pushViewController:emailSucces animated:YES];
//        EmailRequest *emailRequest = [[EmailRequest alloc] initWithEmail:self.email.text passW:nil];
//        [emailRequest sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
//            if (success) {
//                
//            }
//        }];
    }else{
        [CNNavigationBarHUD showError:@"请填写有效的邮箱"];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
