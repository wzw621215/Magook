//
//  EmailRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface EmailRequest : BaseRequest
- (instancetype)initWithEmail:(NSString *)email passW:(NSString *)passW;

@end
