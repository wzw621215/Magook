//
//  ChangeRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ChangeRequest.h"
@interface ChangeRequest()

/** 旧密码*/
@property (nonatomic, copy) NSString *oldPsd;
/** 新密码 */
@property (nonatomic, copy) NSString *psdNew;
/** 重复密码 */
@property (nonatomic, copy) NSString *repeatPsd;

@end

@implementation ChangeRequest

- (instancetype)initWithOldPsd:(NSString *)oldPsd psdNew:(NSString *)psdNew aginPsd:(NSString *)repeatPsd{
    if (self == [super init]) {
        _oldPsd = oldPsd;
        _psdNew = psdNew;
        _repeatPsd = repeatPsd;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSString *)url {
    return kChangePsdAPI;
}

- (NSDictionary *)params {
    return @{
             @"oldPsd":_oldPsd,
             @"newPsd":_psdNew,
             @"repeatPsd":_repeatPsd
             };
}

@end
