//
//  ChangePassWordVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ChangePassWordVC.h"
#import "ChangeRequest.h"
#import "ChangeSuccessVC.h"

@interface ChangePassWordVC ()

@property (weak, nonatomic) IBOutlet UITextField *oldPsd;
@property (weak, nonatomic) IBOutlet UITextField *setNewPsd;
@property (weak, nonatomic) IBOutlet UITextField *aginPsd;

@end

@implementation ChangePassWordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"修改密码";
}

- (IBAction)change:(id)sender {
    NSString *oldPsd = [YDConfigurationHelper getStringValueForConfigurationKey:@"oldPsd"];
    if ([self.oldPsd.text isBlank] ||[self.setNewPsd.text isBlank] ||[self.aginPsd.text isBlank]) {
        [CNNavigationBarHUD showError:@"请输入相应密码"];
    }else if (![self.oldPsd.text isEqualToString:oldPsd]){
        [CNNavigationBarHUD showError:@"原密码不正确"];
    }else if (![self.setNewPsd.text isEqualToString:self.aginPsd.text]) {
       [CNNavigationBarHUD showError:@"确认密码和新密码不一致"];
    }else {
        ChangeRequest *request = [[ChangeRequest alloc] initWithOldPsd:self.oldPsd.text psdNew:self.setNewPsd.text aginPsd:self.aginPsd.text];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                [YDConfigurationHelper setStringValueForConfigurationKey:@"oldPsd" withValue:self.aginPsd.text];
                [YDConfigurationHelper removeUserDataForkey:@"password"];
                [YDConfigurationHelper removeUserDataForkey:@"isRemember"];
                [self popToRootVc];
                LoginViewController *login = [[LoginViewController alloc] init];
                BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
                [self presentVc:nav];
               // ChangeSuccessVC *successVC = [[ChangeSuccessVC alloc] init];
               // [self.navigationController pushViewController:successVC animated:YES];
            }else{
                [CNNavigationBarHUD showError:response];
            }
        }];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
