//
//  ChangeRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface ChangeRequest : BaseRequest

- (instancetype)initWithOldPsd:(NSString *)oldPsd psdNew:(NSString *)psdNew aginPsd:(NSString *)repeatPsd;

@end
