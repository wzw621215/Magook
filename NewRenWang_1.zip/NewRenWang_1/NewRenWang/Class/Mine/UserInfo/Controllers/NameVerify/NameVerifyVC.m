//
//  NameVerifyVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/9.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NameVerifyVC.h"
#import "MySheetView.h"
#import "GTMBase64.h"

@interface NameVerifyVC () <UINavigationControllerDelegate,UIImagePickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *identityCard;
@property (weak, nonatomic) IBOutlet UIView *cardFront;
@property (weak, nonatomic) IBOutlet UIView *cardContrary;

@property (weak, nonatomic) IBOutlet UIImageView *imageContrary;
@property (weak, nonatomic) IBOutlet UIImageView *imageFront;
@property (assign, nonatomic)BOOL isCardFront;                  //是否是照片正面

@end

@implementation NameVerifyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"实名认证";
    [self.cardFront.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.cardFront.layer setBorderWidth:0.5];
    [self.cardContrary.layer setBorderColor:kRGBColor(230, 230, 230).CGColor];
    [self.cardContrary.layer setBorderWidth:0.5];
    [self.imageFront addActionWithTarget:self  action:@selector(pressFront)];
    [self.imageContrary addActionWithTarget:self  action:@selector(pressContrary)];
}

#pragma mark - 点击上面
- (void)pressFront{
    self.isCardFront = YES;
    
    [self setupImagePickerController];
}

#pragma mark - 点击下面
- (void)pressContrary{
    self.isCardFront = NO;
    [self setupImagePickerController];
}

- (void)setupImagePickerController {
    //调用系统相册的类
    UIImagePickerController *pickerController = [[UIImagePickerController alloc] init];
    //设置选取的照片是否可编辑
    pickerController.allowsEditing = YES;
    //选择完成图片或则点击取消按钮都是通过代理来操作我们所需要的逻辑过程
    pickerController.delegate = self;
    //设置相册呈现的样式
    //    UIImagePickerControllerSourceTypePhotoLibrary,       直接全部呈现系统相册
    //    UIImagePickerControllerSourceTypeCamera,             调取摄像头
    //    UIImagePickerControllerSourceTypeSavedPhotosAlbum    图片分组列表样式
    MySheetView *view = [MySheetView new];
    view.buttonNameArray = @[@"拍照",@"从相册选择"];
    [view handleMyBlock:^(UIButton *selectButton, NSString *title) {
        if ([title isEqualToString:@"拍照"]) {
            pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            
        }else if([title isEqualToString:@"从相册选择"]){
            pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        }
        //使用模态呈现相册
        [self.navigationController presentViewController:pickerController
                                                animated:YES
                                              completion:^{
                                                  
                                              }];
    }];
    [view show:self];
}

#pragma mark - 照片选择完成和取消之后都是通过代理来实现，如果不实现点击之后的方法系统就无法王下走就会卡在照片界面
//选择照片完成之后的代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    //info是所选择照片的信息
//    UIImagePickerControllerEditedImage  //编辑过的图片
//    UIImagePickerControllerOriginalImage //原图
//    NSLog(@"%@",info);
    //刚才已经看info中的键值对，可以从info中取出一个UIImage对象，将取出的对象赋给button/UIImageview的image
    
    UIImage *resultImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    NSData *data = nil;
    if (UIImagePNGRepresentation(resultImage)) {
        data = UIImagePNGRepresentation(resultImage);
    }else {
        data = UIImageJPEGRepresentation(resultImage, 1.0);
    }
//1.第三方转码
//    data = [GTMBase64 encodeData:data];
//    NSString *base64Str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSString *base64Str = [GTMBase64 stringByEncodingData:data];
//    data = [GTMBase64 decodeData:data];
    data = [GTMBase64 decodeString:base64Str];
    UIImage *base64Image = [UIImage imageWithData: data];
    
    if (self.isCardFront) {
        self.imageFront.image = resultImage;
        self.imageContrary.image = base64Image;
    }else{
        self.imageContrary.image = resultImage;
    }
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

//点击取消按钮所执行的方法
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    //这是捕获点击右上角cancel按钮所触发的事件，如果我们需要在点击cancel按钮的时候做一些其他逻辑操作。就需要实现该代理方法，如果不做任何逻辑操作，就可以不实现
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)sendVerify:(id)sender {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
