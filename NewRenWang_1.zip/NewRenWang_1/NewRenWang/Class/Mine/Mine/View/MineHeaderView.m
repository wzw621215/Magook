//
//  MineHeaderView.m
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MineHeaderView.h"
#import <YYText/YYText.h>
@interface MineHeaderView ()

/** 头像 */
@property (nonatomic, weak) UIImageView *headImage;
/** 用户名字 */
@property (nonatomic, weak) YYLabel *userName;
/** 登录时间 */
@property (nonatomic, weak) UILabel *loginTime;
/** 实名认证 */
@property (nonatomic, weak) UIImageView *certification;
/** 手机认证 */
@property (nonatomic, weak) UIImageView *certificationPhone;
/** 牛人认证 */
@property (nonatomic, weak) UIImageView *certificationGenius;
/** 个人中心*/
@property (nonatomic, weak) UILabel *title;

@end

@implementation MineHeaderView

- (void)setup {
    self.frame = CGRectMake(0, 0, ScreenWIDTH, 180);
    //背景图片
    UIImageView *bgImage = [[UIImageView alloc] initWithFrame:self.frame];
    bgImage.userInteractionEnabled = YES;
    bgImage.image = [UIImage imageNamed:@"headerBG"];
    [self addSubview:bgImage];
    _bgImage = bgImage;
    
    // 头像
    UIImageView *head = [[UIImageView alloc] init];
    head.userInteractionEnabled = YES;
    [head addActionWithTarget:self action:@selector(loginBtnDidLogin)];
    head.backgroundColor = kLightGrayColor;
    head.layerCornerRadius = 85 * 0.5;
    [self addSubview:head];
    _headImage = head;
    
    //用户名或者立即登录
    YYLabel *userName = [[YYLabel alloc] init];
    
    [userName addActionWithTarget:self action:@selector(loginBtnDidLogin)];
    [self addSubview:userName];
    _userName = userName;
    
    //判断是否登录
    if (![UserInfoManage sharedManager].isLogin) {
        UILabel *title = [[UILabel alloc] init];
        title.text = @"个人中心";
        title.font = kFont(17.0f);
        title.textColor = kWhiteColor;
        _title = title;
         [self addSubview:title];
        
        //头像
        head.image = [UIImage imageNamed:@"me_icon"];
        
        //用户名
        userName.font = kFont(17);
        userName.text = @"立即登录";
        userName.textColor = kWhiteColor;
        userName.textAlignment = NSTextAlignmentCenter;
        [userName setLayerCornerRadius:3.0 borderWidth:1 borderColor:kWhiteColor];
    } else {
        //头像
        if ([self getImageFromLocal]){
            head.image = [self getImageFromLocal];
        }else{
            [head sd_setImageWithURL:[NSURL URLWithString:[UserInfoManage sharedManager].currentUserInfo.icon] placeholderImage:[UIImage imageNamed:@"me_icon"]];
        }
        
        ///////
        NSMutableAttributedString *textImage = [NSMutableAttributedString new];
        UIImage *stateImage = [UIImage imageNamed:@"edit"];
        [textImage yy_appendString:[NSString stringWithFormat:@"%@  ",[UserInfoManage sharedManager].currentUserInfo.nickname]];
        [textImage appendAttributedString:[NSMutableAttributedString yy_attachmentStringWithContent:stateImage contentMode:UIViewContentModeCenter attachmentSize:CGSizeMake(15, 15) alignToFont:[UIFont systemFontOfSize:15.0f] alignment:YYTextVerticalAlignmentCenter]];
        userName.attributedText = textImage;
        userName.font = kFont(15);
        userName.textColor = kWhiteColor;
        
        //登录时间 或者 欢迎您
        UILabel *loginTime = [[UILabel alloc] init];
        loginTime.textColor = kWhiteColor;
        loginTime.font = kFont(12);
        [self addSubview:loginTime];
        _loginTime = loginTime;
        loginTime.text = [NSString stringWithFormat:@"上次登录时间：%@",[UserInfoManage sharedManager].currentUserInfo.previouslogintime];
        //实名认证
        UIImageView *certification = [[UIImageView alloc] init];
        certification.image = [UIImage imageNamed:@"people"];
        [self addSubview:certification];
        _certification = certification;
        
        //手机认证
        UIImageView *certificationPhone = [[UIImageView alloc] init];
        certificationPhone.image = [UIImage imageNamed:@"phone"];
        [self addSubview:certificationPhone];
        _certificationPhone = certificationPhone;
        
        //牛人认证
        UIImageView *certificationGenius = [[UIImageView alloc] init];
        certificationGenius.image = [UIImage imageNamed:@"identity"];
        [self addSubview:certificationGenius];
        _certificationGenius = certificationGenius;
    }
}


- (void)layoutSubviews {
    [super layoutSubviews];
   
    [self.headImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.equalTo(@85);
        make.left.equalTo(self.mas_left).offset(15);
        make.centerY.equalTo(self.mas_centerY).offset(10);
    }];
    
    if ([UserInfoManage sharedManager].isLogin) {
        [self.userName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@20);
            make.centerY.equalTo(self.headImage.mas_centerY).offset(-20);
            make.left.equalTo(self.headImage.mas_right).offset(10);
            make.right.equalTo(self.mas_right).offset(-10);
           
        }];
        
        [self.loginTime mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@13);
            make.top.equalTo(self.userName.mas_bottom).offset(10);
            make.left.equalTo(self.headImage.mas_right).offset(10);
            make.right.equalTo(self.mas_right).offset(-10);
        }];
        
        [self.certification mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.equalTo(@10);
            make.top.equalTo(self.loginTime.mas_bottom).offset(10);
            make.left.equalTo(self.headImage.mas_right).offset(10);
            
        }];
        
        [self.certificationPhone mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.equalTo(@10);
            make.centerY.mas_equalTo(self.certification.mas_centerY);
            make.left.equalTo(self.certification.mas_right).offset(10);
        }];
        
        [self.certificationGenius mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.equalTo(@10);
            make.centerY.mas_equalTo(self.certification.mas_centerY);
            make.left.equalTo(self.certificationPhone.mas_right).offset(10);
        }];

    }else{
        [self.userName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@25);
            make.centerY.equalTo(self.headImage.mas_centerY);
            make.left.equalTo(self.headImage.mas_right).offset(10);
            make.width.equalTo(@80);
    
        }];
        [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@25);
            make.centerX.equalTo(self.mas_centerX);
            make.top.equalTo(self.mas_top).offset(30);
            make.width.equalTo(@75);
        }];
    }
}


- (void)reloadData {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self setup];
}

- (void)loginBtnDidLogin {
    if (self.UserDidLoginBlock) {
        self.UserDidLoginBlock();
    }
}
- (void)resetUserInfo {

}

#pragma mark - 创建图片路径
-(NSString *)getImageSavePath{
    // 本地沙盒目录
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    //指定新建文件夹路径
    NSString *imageFilePath = [path stringByAppendingPathComponent:@"MyIcon"];
    return imageFilePath;
}
#pragma mark - 根据文件路径获取图片的data
- (UIImage *)getImageFromLocal {
    NSData *data = [[NSFileManager defaultManager] contentsAtPath:[self getImageSavePath]];
    UIImage *image = [UIImage imageWithData:data];
    return image;
}
@end
