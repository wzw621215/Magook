//
//  MineDataViewCell.h
//  NewRenWang
//
//  Created by YJ on 17/1/22.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@class MineDataViewCell;

typedef NS_ENUM(NSUInteger, MineDataType) {
    MineDataTypeOptional = 0, //自选
    MineDataTypeConcern,      //关注
    MineDataTypeAskStock,     //问股
    MineDataTypeApprentice    //拜师
};


@protocol MineDataViewDidSelectDelegate <NSObject>

- (void)mineDataView:(MineDataViewCell *)tableViewCell didSelectIndexs:(MineDataType)index;

@end

@interface MineDataViewCell : BaseTableViewCell
/** 代理 */
@property (nonatomic, weak) id<MineDataViewDidSelectDelegate>delegate;

@end
