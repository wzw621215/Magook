//
//  MineHeaderView.h
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MineHeaderView : UIView

- (void)reloadData;
/** 背景 */
@property (nonatomic, weak) UIImageView *bgImage;  
/** 立即登陆 */
@property (nonatomic, copy) void(^UserDidLoginBlock)();

@end
