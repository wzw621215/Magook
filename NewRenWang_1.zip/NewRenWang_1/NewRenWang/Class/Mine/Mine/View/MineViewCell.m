//
//  MineViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/1/20.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MineViewCell.h"
@interface MineViewCell()

/** 设置图片 */
@property (nonatomic, weak) UIImageView *setImage;
/** 设置名字 */
@property (nonatomic, weak) UILabel *setLabel;

@end

@implementation MineViewCell

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath {
    MineViewCell *cell = [MineViewCell cellWithTableView:tableView];
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.setLabel.text = @"问题反馈";
            cell.setImage.image = [UIImage imageNamed:@"me_wt"];
        }else{
            cell.setLabel.text = @"关于我们";
            cell.setImage.image = [UIImage imageNamed:@"me_wm"];
        }
    } else {
        cell.setLabel.text = @"设置";
        cell.setImage.image = [UIImage imageNamed:@"me_sz"];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


- (void)layoutSubviews {
    [super layoutSubviews];
    self.setImage.frame = CGRectMake(15, 10, 26, 26);
    self.setLabel.frame = CGRectMake(55, self.contentView.mj_h * 0.5 - 10, ScreenWIDTH - 65, 20);
    
}

- (UIImageView *)setImage {
    if (_setImage == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.image = [UIImage imageNamed:@"身份认证_s"];
        [self.contentView addSubview:img];
        _setImage = img;
    }
    return _setImage;
}

- (UILabel *)setLabel {
    if (!_setLabel) {
        UILabel *setLabel = [[UILabel alloc] init];
        [self.contentView addSubview:setLabel];
        _setLabel = setLabel;
        setLabel.text = @"设置";
        setLabel.font = kFont(14);
    }
    return _setLabel;
}


@end
