//
//  MineDataViewCell.m
//  NewRenWang
//
//  Created by YJ on 17/1/22.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MineDataViewCell.h"

@interface MineDataViewCell ()
/** 自选 */
@property (nonatomic, weak) UIButton *optional;
/** 关注 */
@property (nonatomic, weak) UIButton *concern;
/** 问股 */
@property (nonatomic, weak) UIButton *askStock;
/** 拜师 */
@property (nonatomic, weak) UIButton *apprentice;
/** 线 */
@property (nonatomic, weak) CALayer *lineOne;
/** 线 */
@property (nonatomic, weak) CALayer *lineTwo;
/** 线 */
@property (nonatomic, weak) CALayer *lineThree;
@end

@implementation MineDataViewCell


- (UIButton *)optional {
    if (!_optional) {
        UIButton *optional = [self creatMineDataButton:MineDataTypeOptional];
        [self.contentView addSubview:optional];
        _optional = optional;
        
    }
    return _optional;
}

- (UIButton *)concern {
    if (!_concern) {
        UIButton *concern = [self creatMineDataButton:MineDataTypeConcern];
        [self.contentView addSubview:concern];
        _concern = concern;
    }
    return _concern;
}

- (UIButton *)askStock {
    if (!_askStock) {
        UIButton *askStock = [self creatMineDataButton:MineDataTypeAskStock];
        [self.contentView addSubview:askStock];
        _askStock = askStock;
    }
    return _askStock;
}

- (UIButton *)apprentice {
    if (!_apprentice) {
        UIButton *apprentice = [self creatMineDataButton:MineDataTypeApprentice];
        [self.contentView addSubview:apprentice];
        _apprentice = apprentice;
    }
    return _apprentice;
}

- (CALayer *)lineOne {
    if (!_lineOne) {
        CALayer *line = [self creatLineLayer];
        [self.contentView.layer addSublayer:line];
        _lineOne = line;
    }
    return _lineOne;
}

- (CALayer *)lineTwo {
    if (!_lineTwo) {
        CALayer *line = [self creatLineLayer];
        [self.contentView.layer addSublayer:line];
        _lineTwo = line;
    }
    return _lineTwo;
}

- (CALayer *)lineThree {
    if (!_lineThree) {
        CALayer *line = [self creatLineLayer];
        [self.contentView.layer addSublayer:line];
        _lineThree = line;
    }
    return _lineThree;
}

- (CALayer *)creatLineLayer {
    CALayer *line = [CALayer layer];
    line.backgroundColor = [UIColor colorWithHexString:@"0xdddddd"].CGColor;
    return line;
}

- (UIButton *)creatMineDataButton:(MineDataType)tag {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"0000000\n00000000" forState:UIControlStateNormal];
    [btn setTitleColor:kBlackColor forState:UIControlStateNormal];
    btn.titleLabel.textAlignment = NSTextAlignmentCenter;
    btn.tag = tag;
    [btn addTarget:self action:@selector(mineBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.titleLabel.numberOfLines = 0;
    btn.backgroundColor = kWhiteColor;
    return btn;
}

- (void)mineBtnClick:(UIButton *)btn {
    if ([self.delegate respondsToSelector:@selector(mineDataView:didSelectIndexs:)]) {
        [self.delegate mineDataView:self didSelectIndexs:btn.tag];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.optional mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(ScreenWIDTH / 4));
        make.height.equalTo(@60);
        make.left.equalTo(self.mas_left).offset(0);
        
    }];
    
    [self.concern mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(ScreenWIDTH/4));
        make.height.equalTo(@60);
        make.left.equalTo(self.mas_left).offset(ScreenWIDTH/4);
    }];

    [self.askStock mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(ScreenWIDTH/4));
        make.height.equalTo(@60);
        make.left.equalTo(self.mas_left).offset(ScreenWIDTH/2);
    }];
    
    [self.apprentice mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(ScreenWIDTH/4));
        make.height.equalTo(@60);
        make.left.equalTo(self.mas_left).offset(ScreenWIDTH/2 + ScreenWIDTH/4);
    }];
    
    self.lineOne.frame = CGRectMake(ScreenWIDTH / 4 - kLineHeight, 5, kLineHeight, 50);
    self.lineTwo.frame = CGRectMake(ScreenWIDTH / 2, 5, kLineHeight, 50);
    self.lineThree.frame = CGRectMake(ScreenWIDTH / 2 + ScreenWIDTH / 4, 5, kLineHeight, 50);
    
    NSInteger favCount = [[SearchStock shareManager] allFavStock].count;  //自选股数量
    NSInteger followCount = [UserInfoManage sharedManager].currentUserInfo.myfollwcount;
    self.optional.titleLabel.attributedText = [self attStringWithString:[NSString stringWithFormat:@"自选\n%ld",favCount] keyWord:@"自选"];
    self.concern.titleLabel.attributedText = [self attStringWithString:[UserInfoManage sharedManager].isLogin ? [NSString stringWithFormat:@"关注\n%ld",followCount]: @"关注\n0" keyWord:@"关注" ];
    self.askStock.titleLabel.attributedText = [self attStringWithString:[UserInfoManage sharedManager].isLogin ? @"问股\n0" : @"问股\n0" keyWord:@"问股"];
    self.apprentice.titleLabel.attributedText = [self attStringWithString:[UserInfoManage sharedManager].isLogin ? @"拜师\n0" : @"拜师\n0" keyWord:@"拜师"];
   
}

- (NSAttributedString *)attStringWithString:(NSString *)string
                                    keyWord:(NSString *)keyWord {
   
    return [Utils attStringWithString:string keyWord:keyWord font:kFont(15) highlightedColor:kBlackColor textColor:[UIColor colorWithHexString:@"0x999999"]];
}

@end
