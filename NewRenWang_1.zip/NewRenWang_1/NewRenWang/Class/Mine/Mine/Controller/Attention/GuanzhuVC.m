//
//  GuanzhuVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "GuanzhuVC.h"
#import "AttentionCell.h"
#import "AttebtionRequest.h"
#import "AttentionModel.h"

@interface GuanzhuVC ()<FollowDelegate>

@property(nonatomic, assign)NSInteger pageIndex;

/**  老师总数*/
@property(nonatomic, assign)NSInteger count;

@end

@implementation GuanzhuVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"我的关注";
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.needCellSepLine = NO;
    self.pageIndex = 1;
    [self requesFollowList];
    self.refreshType = BaseTableVcRefreshTypeRefreshAndLoadMore;
    
}

- (void)requesFollowList{
    NSInteger uid = [UserInfoManage sharedManager].currentUserInfo.userid;
    AttebtionRequest *request = [[AttebtionRequest alloc] initWithPageIndex:self.pageIndex withUid:uid];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        [self endRefresh];
        if (success) {
            NSArray *rows = [NSArray arrayWithArray:response[@"rows"]];
            for (NSDictionary *dic in rows) {
                AttentionModel *model = [[AttentionModel alloc] mj_setKeyValues:dic];
                [self.dataArray addObject:model];
            }
        }
        [self reloadData];
        [self endLoadMore];
    }];
}

- (void)refresh {
    [super refresh];
    [self.dataArray removeAllObjects];
    self.pageIndex = 1;
    [self requesFollowList];
}

- (void)loadMore {
    [super loadMore];
    if (self.dataArray.count % 10 != 0){
        [CNNavigationBarHUD showSuccess:@"数据全部加载完"];
        [self endLoadMore];
    }else {
        self.pageIndex++;
        [self requesFollowList];
    }
}


- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    return 135;
}

- (NSInteger)numberOfSections{
    return 1;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section{
    return 0.0f;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    return 0.0f;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    AttentionCell *cell = [AttentionCell nibCellWithTableView:self.tableView];
    cell.model = [self.dataArray objectAtIndexCheck:indexPath.row];
    cell.followDelegate = self;
    return cell;
}

#pragma mark -FollowDelegate 取消关注  更新数据并刷新界面
- (void)followTeacher {
    [self refresh];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
