//
//  AttebtionRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "AttebtionRequest.h"
@interface AttebtionRequest()
/** userId*/
@property (nonatomic, assign)NSInteger uid;

/** 第几页 默认从1开始*/
@property (nonatomic, assign) NSInteger pageIndex;

@end

@implementation AttebtionRequest

- (instancetype)initWithPageIndex:(NSInteger)index withUid:(NSInteger)uid{
    if (self == [super init]) {
        _pageIndex = index;
        _uid = uid;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"uid":@(_uid),
             @"pageSize":@"10",
             @"pageIndex":@(_pageIndex)
             };
}

- (NSString *)url {
    
    return kFollowListAPI;
}

@end
