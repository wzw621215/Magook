//
//  AttentionCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "AttentionCell.h"
#import "DeleFollowRequest.h"

@interface AttentionCell()
@property (weak, nonatomic) IBOutlet UIImageView *teacherImg;
@property (weak, nonatomic) IBOutlet UILabel *name;

@property (weak, nonatomic) IBOutlet UILabel *reputation;
@property (weak, nonatomic) IBOutlet UILabel *introduction;
@property (weak, nonatomic) IBOutlet UILabel *fans;
@property (weak, nonatomic) IBOutlet UILabel *point;
@property (weak, nonatomic) IBOutlet UILabel *course;

@end

@implementation AttentionCell

- (void)setModel:(AttentionModel *)model {
    _model = model;
    [self.teacherImg sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    self.name.text = model.name;
    self.reputation.text = model.reputation;
    
    NSMutableAttributedString *introAtt = [[NSMutableAttributedString alloc] initWithString:model.introduction];
    introAtt.yy_color = [UIColor colorWithHexString:@"#999999"];
    introAtt.yy_lineSpacing = 5;
    introAtt.yy_font = kFont(12);
    self.introduction.attributedText = introAtt;
    
    self.fans.text = [NSString stringWithFormat:@"粉丝：%ld",model.fans];
    self.point.text = [NSString stringWithFormat:@"观点：%ld",model.point_num];
    self.course.text = [NSString stringWithFormat:@"课程：%ld",model.course_num];
}

- (IBAction)cancelFollow:(id)sender {
    DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.ID];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            if ([self.followDelegate respondsToSelector:@selector(followTeacher)]) {
                [self.followDelegate followTeacher];
            }
            
        }
    }];

}

-(void)setFrame:(CGRect)frame
{
    frame.size.height -= 8;
    frame.origin.y += 8;
    [super setFrame:frame];
    
}

@end
