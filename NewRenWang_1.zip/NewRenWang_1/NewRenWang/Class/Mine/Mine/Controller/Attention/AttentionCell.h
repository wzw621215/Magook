//
//  AttentionCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "AttentionModel.h"
#import "TopicCell.h"

@interface AttentionCell : BaseTableViewCell

@property (nonatomic,weak)id< FollowDelegate>followDelegate;

@property (nonatomic, strong)AttentionModel *model;

@end
