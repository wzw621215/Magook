//
//  AttebtionRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface AttebtionRequest : BaseRequest

- (instancetype)initWithPageIndex:(NSInteger)index withUid:(NSInteger)uid;

@end
