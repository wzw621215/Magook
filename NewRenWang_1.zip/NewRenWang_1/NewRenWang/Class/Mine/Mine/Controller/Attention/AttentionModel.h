//
//  AttentionModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/21.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface AttentionModel : BaseModel
/** 课程数量*/
@property (nonatomic,assign)NSInteger course_num;
/** 粉丝数*/
@property (nonatomic,assign)NSInteger fans;
/** 头像*/
@property (nonatomic,copy)NSString * icon;
/** 老师ID*/
@property (nonatomic,assign)NSInteger ID;
/** 介绍*/
@property (nonatomic,copy)NSString * introduction;
/** 姓名*/
@property (nonatomic,copy)NSString * name;
/** 观点数*/
@property (nonatomic,assign)NSInteger point_num;
/** 称号*/
@property (nonatomic,copy)NSString * reputation;

@end
