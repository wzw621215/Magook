//
//  HQRefreshVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HQRefreshVC.h"
#import "HQRefreshCell.h"
#import "HQRefreshHeadView.h"

@interface HQRefreshVC ()

@end

@implementation HQRefreshVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"行情刷新";
    self.tableView.scrollEnabled = NO;
    self.needCellSepLine = NO;
    
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    return 49;
}

- (NSInteger)numberOfSections {
    return 2;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 4;
    }
    return 3;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    return 40;
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    return 0.1;
}

#pragma mark - 加载section的头部视图
- (UIView *)headerAtSection:(NSInteger)section{
    HQRefreshHeadView *headView = [HQRefreshHeadView headerFooterViewWithTableView:self.tableView indexPath:section];
    return headView;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    HQRefreshCell *cell = [HQRefreshCell cellOfTableView:self.tableView indexPath:indexPath];
    return cell;
}


- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    HQRefreshCell *hcell = [self.tableView cellForRowAtIndexPath:indexPath];
//    if (<#condition#>) {
//        <#statements#>
//    }
//    hcell.icon.hidden = NO;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
