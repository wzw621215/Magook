//
//  HQRefreshCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HQRefreshCell.h"

@interface HQRefreshCell()

@property (nonatomic,weak)UIView *line;
@property (nonatomic, weak)UILabel *secondLabel;

@end

@implementation HQRefreshCell

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"不刷新";
            cell.icon.hidden = YES;
            return cell;
        }else if (indexPath.row == 1){
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"5秒";
            cell.icon.hidden = YES;
            return cell;
        }else if (indexPath.row == 2){
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"10秒";
            cell.icon.hidden = NO;
            return cell;
        }else{
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"30秒";
            cell.icon.hidden = YES;
            return cell;
        }
    } else {
        if (indexPath.row == 0) {
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"5秒";
            cell.icon.hidden = YES;
            return cell;
        }else if (indexPath.row == 1){
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"10秒";
            cell.icon.hidden = NO;
            return cell;
        }else{
            HQRefreshCell *cell = [HQRefreshCell cellWithTableView:tableView];
            cell.secondLabel.text = @"30秒";
            cell.icon.hidden = YES;
            return cell;
        }
    }
}

- (UIImageView *)icon {
    if (!_icon) {
        UIImageView *icon = [[UIImageView alloc] init];
        icon.image = [UIImage imageNamed:@"refreshSet"];
        [self.contentView addSubview:icon];
        _icon = icon;
    }
    return _icon;
}

- (UILabel *)secondLabel {
    if (!_secondLabel) {
        UILabel *secondLabel = [[UILabel alloc] init];
        secondLabel.font = kFont(13.0);
        secondLabel.textColor = kBlackColor;
        [self.contentView addSubview:secondLabel];
        _secondLabel = secondLabel;
    }
    return _secondLabel;
}

- (UIView *)line {
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(210, 210, 210);
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.contentView.backgroundColor = kWhiteColor;
    [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).offset(10);
        make.width.equalTo(@25);
        make.height.equalTo(@25);
    }];
    [self.secondLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.icon.mas_right).offset(10);
        make.width.equalTo(@200);
        make.height.equalTo(@20);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView.mas_bottom);
        make.width.equalTo(self.contentView.mas_width);
        make.height.equalTo(@0.5);
    }];
}

@end
