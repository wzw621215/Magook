//
//  HQRefreshCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface HQRefreshCell : BaseTableViewCell


@property (nonatomic, weak)UIImageView *icon;

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;


@end
