//
//  HQRefreshHeadView.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HQRefreshHeadView.h"
@interface HQRefreshHeadView()

@property (nonatomic,weak)UIImageView *icon;

@property (nonatomic,weak)UILabel *netTitle;

@property (nonatomic,weak)UIView *line;

@end

@implementation HQRefreshHeadView

+ (instancetype)headerFooterViewWithTableView:(UITableView *)tableView indexPath:(NSInteger)section {
    HQRefreshHeadView *headView = [HQRefreshHeadView headerFooterViewWithTableView:tableView];
    if (section == 0) {
        headView.icon.image = [UIImage imageNamed:@"4G"];
        headView.netTitle.text = @"2G/3G/4G 网络";
    }else{
        headView.icon.image = [UIImage imageNamed:@"wifi"];
        headView.netTitle.text = @"Wifi 网络";
    }
    return headView;
}

- (UIImageView *)icon {
    if (!_icon) {
        UIImageView *icon = [[UIImageView alloc] init];
        [self.contentView addSubview:icon];
        _icon = icon;
    }
    return _icon;
}

- (UILabel *)netTitle{
    if (!_netTitle) {
        UILabel *netTitle = [[UILabel alloc] init];
        netTitle.font = kFont(13);
        netTitle.textColor = kRGBColor(125, 125, 125);
        [self.contentView addSubview:netTitle];
        _netTitle = netTitle;
    }
    return _netTitle;
}

- (UIView *)line {
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(210, 210, 210);
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;

}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.contentView.backgroundColor = kRGBColor(244, 244, 244);
    
    [self.icon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).offset(10);
        make.width.equalTo(@20);
        make.height.equalTo(@20);
    }];
    
    [self.netTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.icon.mas_right).offset(10);
        make.width.equalTo(@150);
        make.height.equalTo(@20);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView.mas_bottom);
        make.width.equalTo(self.contentView.mas_width);
        make.height.equalTo(@0.5);
    }];
    
}

@end
