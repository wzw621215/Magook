//
//  SettingViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface SettingViewController : BaseTableViewController

@end
