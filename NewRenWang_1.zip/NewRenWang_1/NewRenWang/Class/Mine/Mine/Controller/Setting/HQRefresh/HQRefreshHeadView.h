//
//  HQRefreshHeadView.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewHeaderFooterView.h"

@interface HQRefreshHeadView : BaseTableViewHeaderFooterView

+ (instancetype)headerFooterViewWithTableView:(UITableView *)tableView indexPath:(NSInteger)section;

@end
