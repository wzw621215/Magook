//
//  SettingViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingCell.h"
#import "SettingDataSource.h"
#import "RefreshViewController.h"
#import "SearchHistoryCacheManager.h"

@interface SettingViewController ()
{
    NSArray *_settingArray;
}
@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"设置";
    self.tableView.scrollEnabled = NO;
    
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    return 49;
}

- (NSInteger)numberOfSections {
    return 2;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    return 1;
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else {
        return 10;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    return 0.1;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    _settingArray = [SettingDataSource settingViewDataSource];
    NSArray *listSectionArray = _settingArray[indexPath.section];
    NSDictionary *dic = listSectionArray[indexPath.row];
    SettingCell *cell = [SettingCell cellOfTableView:self.tableView indexPath:indexPath];
    [cell updateDataBy:dic];
    return cell;
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    if (indexPath.section == 0) {
        RefreshViewController *refreshVC = [[RefreshViewController alloc] init];
        [self.navigationController pushViewController:refreshVC animated:YES];
    }else{
        [[SDImageCache sharedImageCache] clearDisk];
        [[SearchHistoryCacheManager shareInstance] removeCache];  //删除最近浏览的股票
        [CNNavigationBarHUD showSuccess:@"成功清除缓存"];
        [self.tableView reloadData];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
