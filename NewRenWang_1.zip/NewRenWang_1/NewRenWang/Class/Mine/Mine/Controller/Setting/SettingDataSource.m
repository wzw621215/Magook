//
//  SettingDataSource.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "SettingDataSource.h"

@implementation SettingDataSource

#pragma mark 设置页面数据源
+ (NSArray *)settingViewDataSource {

    CGFloat size = [[SDImageCache sharedImageCache] getSize]/1024.0/1024.0;
    NSString *cacheString = size > 1 ? [NSString stringWithFormat:@"%.2fM", size] : [NSString stringWithFormat:@"%.2fKB", size * 1024.0];
    
    NSDictionary *hqDictionary = @{
                                   kSettingDataSourceImg  :@"行情刷新",
                                   kSettingDataSourceTitle: @"行情刷新",
                                   kSettingDataSourceArrow: @(YES),
                                   kSettingDataSourceButton: @(NO)};
    NSDictionary *cleanCacheDictionary = @{
                                           kSettingDataSourceImg  :@"清除缓存",
                                           kSettingDataSourceTitle: @"清理缓存",
                                           kSettingDataSourceValue: cacheString,
                                           kSettingDataSourceArrow: @(NO),
                                           kSettingDataSourceButton: @(NO)};
    return @[@[hqDictionary], @[cleanCacheDictionary]];
}




@end



















