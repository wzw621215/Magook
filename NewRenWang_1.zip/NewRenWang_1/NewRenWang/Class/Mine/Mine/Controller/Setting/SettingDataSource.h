//
//  SettingDataSource.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <Foundation/Foundation.h>
static NSString *kSettingDataSourceImg    = @"kSettingDataSourceImg";
static NSString *kSettingDataSourceTitle  = @"kSettingDataSourceTitle";
static NSString *kSettingDataSourceValue  = @"kSettingDataSourceValue";
static NSString *kSettingDataSourceArrow  = @"kSettingDataSourceArrow";
static NSString *kSettingDataSourceButton = @"kSettingDataSourceButton";

@interface SettingDataSource : NSObject

+ (NSArray *)settingViewDataSource;

@end
