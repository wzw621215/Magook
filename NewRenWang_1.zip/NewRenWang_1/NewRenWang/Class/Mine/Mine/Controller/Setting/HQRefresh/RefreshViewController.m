//
//  RefreshViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "RefreshViewController.h"

@interface RefreshViewController ()


@property (weak, nonatomic) IBOutlet UIImageView *wifi_30s;
@property (weak, nonatomic) IBOutlet UIImageView *wifi_10s;
@property (weak, nonatomic) IBOutlet UIImageView *wifi_row5s;

@property (weak, nonatomic) IBOutlet UIImageView *wlan_row30s;
@property (weak, nonatomic) IBOutlet UIImageView *wlan_row10s;
@property (weak, nonatomic) IBOutlet UIImageView *wlan_row5s;
@property (weak, nonatomic) IBOutlet UIImageView *wlan_no;

@property (nonatomic,weak)UIImageView *tmpWlan;

@property (nonatomic,weak)UIImageView *tmpWifi;

@end

@implementation RefreshViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"行情刷新";
    NSInteger wlanSecond = [YDConfigurationHelper getIntergerValueForConfigurationKey:@"WlanFrequency"];
    NSInteger wifiSecond = [YDConfigurationHelper getIntergerValueForConfigurationKey:@"WifiFrequency"];
    switch (wlanSecond) {
        case 360000:
            self.tmpWlan = self.wlan_no;
            break;
        case 5:
            self.tmpWlan = self.wlan_row5s;
            break;
        case 10:
            self.tmpWlan = self.wlan_row10s;
            break;
        case 30:
            self.tmpWlan = self.wlan_row30s;
            break;
            
        default:
            break;
    }
    switch (wifiSecond) {
        case 5:
            self.tmpWifi = self.wifi_row5s;
            break;
        case 10:
            self.tmpWifi = self.wifi_10s;
            break;
        case 30:
            self.tmpWifi = self.wifi_30s;
            break;
            
        default:
            break;
    }
    self.tmpWifi.hidden = NO;
    self.tmpWlan.hidden = NO;
}
- (IBAction)wlanSecond:(id)sender {
    UIButton *button = (UIButton *)sender;
    if (self.tmpWlan != nil) {
        self.tmpWlan.hidden = YES;
    }
    switch (button.tag) {
        case 1:
            self.wlan_no.hidden = NO;
            self.tmpWlan = self.wlan_no;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WlanFrequency" withValue:360000];
            break;
        case 2:
            self.wlan_row5s.hidden = NO;
            self.tmpWlan = self.wlan_row5s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WlanFrequency" withValue:5];
            break;
        case 3:
            self.wlan_row10s.hidden = NO;
            self.tmpWlan = self.wlan_row10s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WlanFrequency" withValue:10];
            break;
        case 4:
            self.wlan_row30s.hidden = NO;
            self.tmpWlan = self.wlan_row30s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WlanFrequency" withValue:30];
            break;
            
        default:
            break;
    }

}
- (IBAction)wifiSecond:(id)sender {
    UIButton *button = (UIButton *)sender;
    if (self.tmpWifi != nil) {
        self.tmpWifi.hidden = YES;
    }
    switch (button.tag) {
        case 10:
            self.wifi_row5s.hidden = NO;
            self.tmpWifi = self.wifi_row5s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WifiFrequency" withValue:5];
            break;
        case 11:
            self.wifi_10s.hidden = NO;
            self.tmpWifi = self.wifi_10s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WifiFrequency" withValue:10];
            break;
        case 12:
            self.wifi_30s.hidden = NO;
            self.tmpWifi = self.wifi_30s;
            [YDConfigurationHelper setIntergerValueForConfigurationKey:@"WifiFrequency" withValue:30];
            break;
        default:
            break;
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
