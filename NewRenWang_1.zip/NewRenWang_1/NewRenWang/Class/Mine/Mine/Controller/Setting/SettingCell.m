//
//  SettingCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "SettingCell.h"
#import "SettingDataSource.h"
@interface SettingCell()

@property (nonatomic, weak) UIImageView *iconImage;

@property (nonatomic, weak) UILabel *setLabel;

@property (nonatomic, weak) UILabel *cacheLabel;

@property (nonatomic, weak) UIImageView *arrowImg;

@end


@implementation SettingCell

#pragma mark 更新数据
- (void)updateDataBy:(NSDictionary *)dictionary {
    self.setLabel.text = dictionary[kSettingDataSourceTitle];
    [self.iconImage setImage:[UIImage imageNamed:dictionary[kSettingDataSourceImg]]];

    BOOL isButton = [dictionary[kSettingDataSourceArrow] boolValue];
    
    if (isButton) {
        self.arrowImg.hidden = NO;
        
    } else {
        self.arrowImg.hidden = YES;
        
        NSString *cacheString = dictionary[kSettingDataSourceValue];
        if ([cacheString isValid]) {
            self.cacheLabel.text = cacheString;
        } else {
            self.cacheLabel.text = @"";
        }
    }
}

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath {
    SettingCell *cell = [SettingCell cellWithTableView:tableView];
    return cell;
}


- (void)layoutSubviews {
    [super layoutSubviews];
    self.iconImage.frame = CGRectMake(15, 10, 30, 30);
    self.setLabel.frame = CGRectMake(55, self.contentView.mj_h * 0.5 - 10, ScreenWIDTH - 65, 20);
    [self.arrowImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-20);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.width.equalTo(@15);
        make.height.equalTo(@15);
    }];
    [self.cacheLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-20);
        make.centerY.equalTo(self.contentView.mas_centerY);
        make.width.equalTo(@60);
        make.height.equalTo(@25);
    }];

}
- (UIImageView *)arrowImg {
    if (_arrowImg == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.image = [UIImage imageNamed:@"arrow_right"];
        [self.contentView addSubview:img];
        _arrowImg = img;
    }
    return _arrowImg;
}

- (UILabel *)cacheLabel {
    if (!_cacheLabel) {
        UILabel *cacheLabel = [[UILabel alloc] init];
        [self.contentView addSubview:cacheLabel];
        cacheLabel.textColor = kRGBColor(125, 125, 125);
        cacheLabel.textAlignment = NSTextAlignmentRight;
        cacheLabel.font = kFont(12);
        _cacheLabel = cacheLabel;
    }
    return _cacheLabel;
}

- (UIImageView *)iconImage {
    if (_iconImage == nil) {
        UIImageView *img = [[UIImageView alloc] init];
        img.image = [UIImage imageNamed:@"身份认证_s"];
        [self.contentView addSubview:img];
        _iconImage = img;
    }
    return _iconImage;
}

- (UILabel *)setLabel {
    if (!_setLabel) {
        UILabel *setLabel = [[UILabel alloc] init];
        [self.contentView addSubview:setLabel];
        _setLabel = setLabel;
        setLabel.text = @"设置";
        setLabel.font = kFont(14);
    }
    return _setLabel;
}


@end
