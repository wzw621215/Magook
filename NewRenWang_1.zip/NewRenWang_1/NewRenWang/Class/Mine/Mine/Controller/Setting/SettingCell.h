//
//  SettingCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface SettingCell : BaseTableViewCell

+ (instancetype)cellOfTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;

- (void)updateDataBy:(NSDictionary *)dictionary;

@end
