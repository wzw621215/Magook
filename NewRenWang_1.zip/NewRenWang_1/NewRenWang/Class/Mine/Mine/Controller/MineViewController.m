//
//  MineViewController.m
//  NewRenWang
//
//  Created by YJ on 17/1/12.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "MineViewController.h"
#import "MineHeaderView.h"
#import "LoginViewController.h"
#import "UserInfoViewController.h"
#import "MineViewCell.h"
#import "MineDataViewCell.h"
#import "BTSQuestionViewController.h"
#import "AboutMeVC.h"
#import "SettingViewController.h"
#import "GuanzhuVC.h"
#import "MarketViewController.h"
@interface MineViewController () <UIScrollViewDelegate, MineDataViewDidSelectDelegate>
/** 头部个人信息 */
@property (nonatomic, weak) MineHeaderView *headerView;

@end

@implementation MineViewController

#pragma  mark - 跳转页面，隐藏导航栏
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [_headerView reloadData];
    [self.tableView reloadData];
    self.tableView.scrollEnabled = NO;
}

#pragma  mark - 显示导航栏
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //头部 
    MineHeaderView *headView = [[MineHeaderView alloc] init];
    //跳转登陆页面
    [headView setUserDidLoginBlock:^{
        // 判断是否登录
        if ([[UserInfoManage sharedManager] isLogin]) {
            UserInfoViewController *userInfo = [[UserInfoViewController alloc] init];
            [self.navigationController pushViewController:userInfo animated:YES];

        } else {
            LoginViewController *login = [[LoginViewController alloc] init];
            BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
            [self presentVc:nav];
        }
    }];
  
    _headerView = headView;
    self.tableView.tableHeaderView = self.headerView;
}

#pragma mark - 重写父类方法
- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 60;
    } else {
       return 49;
    }
}

- (NSInteger)numberOfSections {
    return 3;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section {
    if (section == 1) {
        return 2;
    } else {
        return 1;
    }
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else {
      return 10;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section {
    return 0.1;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        MineDataViewCell *cell = [MineDataViewCell cellWithTableView:self.tableView];
        cell.delegate = self;
        return cell;
    } else {
        MineViewCell *cell = [MineViewCell cellOfTableView:self.tableView indexPath:indexPath];
        return cell;
    }
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell {
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            BTSQuestionViewController *question = [[BTSQuestionViewController alloc] init];
            [self.navigationController pushViewController:question animated:YES];
        }else {
            AboutMeVC *aboutMe = [[AboutMeVC alloc] init];
            [self.navigationController pushViewController:aboutMe animated:YES];
        }
    }else if (indexPath.section == 2){
        SettingViewController *settingVC = [[SettingViewController alloc] init];
        [self.navigationController pushViewController:settingVC animated:YES];
    }
}

#pragma mark --第一组的代理
- (void)mineDataView:(MineDataViewCell *)tableViewCell didSelectIndexs:(MineDataType)index {
    switch (index) {
        case MineDataTypeOptional:
        {
            //获取根视图控制器
            UITabBarController *tabBar = (UITabBarController*)[[UIApplication.sharedApplication.delegate window] rootViewController];
            //修改tabBar选中的视图
            tabBar.selectedViewController = tabBar.viewControllers[2];
        }
            break;
            
        case MineDataTypeConcern:
        {
            if ([[UserInfoManage sharedManager] isLogin]) {
                GuanzhuVC *guanzhu = [[GuanzhuVC alloc] init];
                [self.navigationController pushViewController:guanzhu animated:YES];
                
            } else {
                LoginViewController *login = [[LoginViewController alloc] init];
                BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
                [self presentVc:nav];
            }
        }
            break;
            
        case MineDataTypeAskStock:
            CNLog(@"问股");
            break;
            
        case MineDataTypeApprentice:
            CNLog(@"拜师");
            break;
            
        default:
            break;
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //缩放
    CGFloat headerImageHeight = -scrollView.contentOffset.y;
    if (headerImageHeight > 0) {
       self.headerView.bgImage.frame = CGRectMake(self.headerView.mj_x - headerImageHeight / 2, self.headerView.mj_y - headerImageHeight, self.headerView.mj_w + headerImageHeight, self.headerView.mj_h + headerImageHeight);
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
