//
//  BTSQuestionViewController.h
//  BigTimeStrategy
//
//  @Author: wsh on 16/6/20.
//  Copyright © 2016年 安徽黄埔. All rights reserved.
//

#import "BaseViewController.h"

@interface BTSQuestionViewController : BaseViewController


@end
