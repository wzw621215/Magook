//
//  UIPlaceholderTextView.m
//  BigTimeStrategy
//
//  @Author: wsh on 16/6/20.
//  Copyright © 2016年 安徽黄埔. All rights reserved.
//

#import "UIPlaceholderTextView.h"

@interface UIPlaceholderTextView ()

@property (nonatomic, strong) UIColor *placeTextColor;   // 占位文字的颜色


- (void)beginEditing:(NSNotification *)notification;


- (void)endEditing:(NSNotification *)notification;

@end

@implementation UIPlaceholderTextView

@synthesize placeholder;

#pragma mark - 初始化方法
- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        [self awakeFromNib];
    }
    return self;
}

#pragma mark - 当用nib创建时会调用此方法
- (void)awakeFromNib {
    [super awakeFromNib];
    self.placeTextColor = [UIColor blackColor];
    [self addObserver];
}

#pragma mark - 添加和移除观察者
- (void)addObserver {  // 添加观察者
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(beginEditing:) name:UITextViewTextDidBeginEditingNotification object:self];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(endEditing:) name:UITextViewTextDidEndEditingNotification object:self];
}

- (void)removeobserver {  // 移除观察者
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark - Setter/Getters
/**
 *  @author wsh, 2016-06-24
 *
 *  @brief  设置占位内容
 *
 *  @param aPlaceholder 占位文字
 */
- (void)setPlaceholder:(NSString *)aPlaceholder {
    placeholder = aPlaceholder;
    [self endEditing:nil];
}

/**
 *  @author wsh, 2016-06-24
 *
 *  @brief text的Setter方法
 *
 *  @return 返回text
 */
- (NSString *)text {
    NSString* text = [super text];
    if ([text isEqualToString:placeholder]) return @"";
    return text;
}

/**
 *  @author wsh, 2016-06-24
 *
 *  @brief 开始编辑事件
 *
 *  @param notification 通知
 */
- (void)beginEditing:(NSNotification *)notification {
    if ([super.text isEqualToString:placeholder]) {
        super.text = nil;
        // 字体颜色
        [super setTextColor:self.placeTextColor];
    }
}

/**
 *  @author wsh, 2016-06-24
 *
 *  @brief 结束编辑
 *
 *  @param notification 通知
 */
- (void)endEditing:(NSNotification*) notification {
    if ([super.text isEqualToString:@""] || self.text == nil) {
        super.text = placeholder;
        // 注释颜色
        [super setTextColor:[UIColor lightGrayColor]];
    }
}

@end
