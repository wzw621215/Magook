//
//  UIPlaceholderTextView.h
//  BigTimeStrategy
//
//  @Author: wsh on 16/6/20.
//  Copyright © 2016年 安徽黄埔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIPlaceholderTextView : UITextView

/**占位符*/
@property(nonatomic, strong) NSString *placeholder;

/**
 *  @author wsh, 2016-06-20
 *
 *  @brief 添加通知
 */
- (void)addObserver;

/**
 *  @author wsh, 2016-06-20
 *
 *  @brief 移除通知
 */
- (void)removeobserver;

@end
