//
//  BTSQuestionViewController.m
//  BigTimeStrategy
//
//  @Author: wsh on 16/6/20.
//  Copyright © 2016年 安徽黄埔. All rights reserved.
//

#import "BTSQuestionViewController.h"
#import "UIPlaceholderTextView.h"

#define MAX_LIMIT_NUMS 200   // 来限制最大输入只能150个字符
@interface BTSQuestionViewController () <UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UIPlaceholderTextView *contenTv;  // 输入的字数
@property (weak, nonatomic) IBOutlet UILabel *limitNum;                // 输入的字数
@property (weak, nonatomic) IBOutlet UIButton *commitBtn;              // 提交按钮

@end

@implementation BTSQuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"问题反馈";

    self.contenTv.layer.cornerRadius = 5;
    self.contenTv.layer.masksToBounds = YES;
    self.contenTv.layer.borderColor = kGrayColor.CGColor;
    self.contenTv.layer.borderWidth = 0.5;
    self.contenTv.delegate = self;
    self.contenTv.placeholder = @"请输入您反馈的问题";
    

    [self.view bringSubviewToFront:_limitNum];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [self.contenTv removeobserver];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.contenTv addObserver];
}

#pragma mark - 提交问题按钮的点击事件
- (IBAction)commitQuestion:(id)sender {
    if (self.contenTv.text.length == 0) {
        [ShowMessage showMessageWithTitle:@"请输入您的问题"];
        return;
    }else{
        [CNNavigationBarHUD showSuccess:@"我们已经收到您的问题"];
    }
}

#pragma mark - UITextViewDelegate
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}


- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSString *comcatstr = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSInteger caninputlen = MAX_LIMIT_NUMS - comcatstr.length;
    
    if (caninputlen >= 0) {
        return YES;
    } else {
        NSInteger len = text.length + caninputlen;
        
        // 防止当text.length + caninputlen < 0时，使得rg.length为一个非法最大正数出错
        NSRange rg = {0,MAX(len,0)};
        if (rg.length > 0) {
            NSString *s = [text substringWithRange:rg];
            [textView setText:[textView.text stringByReplacingCharactersInRange:range withString:s]];
        }
        return NO;
    }
}


- (void)textViewDidChange:(UITextView *)textView {
    NSString  *nsTextContent = textView.text;
    NSInteger existTextNum = nsTextContent.length;
    
    if (existTextNum > MAX_LIMIT_NUMS) {
        // 截取到最大位置的字符
        NSString *s = [nsTextContent substringToIndex:MAX_LIMIT_NUMS];
        [textView setText:s];
    }
    self.limitNum.text = [NSString stringWithFormat:@"%ld/%d",MIN(MAX_LIMIT_NUMS, existTextNum),MAX_LIMIT_NUMS];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
