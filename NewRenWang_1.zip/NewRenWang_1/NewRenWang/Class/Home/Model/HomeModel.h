//
//  HomeModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AdModel,GoldModel,VideoModel,UserModel;

@interface HomeModel : NSObject

@property (nonatomic,strong)NSArray *banner;
@property (nonatomic,strong)NSArray *follow;
@property (nonatomic,strong)NSArray *icons;
@property (nonatomic,strong)NSArray *nrRecommend;
@property (nonatomic,strong)NSArray *topic;

@property (nonatomic,strong)AdModel *ad;
@property (nonatomic,strong)VideoModel *video;

@end

/* banner图片*/
@interface BannerModel : NSObject
@property (nonatomic,copy)NSString *redirectUrl;
@property (nonatomic,copy)NSString *thumb_href;
@property (nonatomic,copy)NSString *title;
@end

/* 最受关注*/
@interface FollowModel : NSObject
@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger fans;
@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *profile;
@property (nonatomic,copy)NSString *avatar;
@property (nonatomic,copy)NSString *speciality;
@property (nonatomic,assign)BOOL isfollw;
@end

/* icons四个按钮*/
@interface IconModel : NSObject
@property (nonatomic,copy)NSString *redirectUrl;
@property (nonatomic,copy)NSString *thumb_href;
@property (nonatomic,copy)NSString *title;
@end

/* 牛人推荐*/
@interface NrRecomModel : NSObject
@property (nonatomic,copy)NSString *avatar;
@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger fans;
@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *profile;
@property (nonatomic,copy)NSString *title;
@end

/* 深度解盘--前2个cell*/
@interface HTopicModel : NSObject
@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger down;
@property (nonatomic,assign)NSInteger up;
@property (nonatomic,assign)NSInteger type;
@property (nonatomic,assign)BOOL isdown;
@property (nonatomic,assign)BOOL isup;
@property (nonatomic,copy)NSString *content;
@property (nonatomic,copy)NSString *time;
@property (nonatomic,strong)UserModel *user;

@end

/* 深度解盘--前2个cell中作者的信息*/
@interface UserModel : NSObject
@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger fans;
@property (nonatomic,assign)BOOL isfollw;
@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *avatar;

@end

/* 广告*/
@interface AdModel : NSObject
@property (nonatomic,copy)NSString *redirectUrl;
@property (nonatomic,copy)NSString *summary;
@property (nonatomic,copy)NSString *thumb_href;
@property (nonatomic,copy)NSString *title;
@end

/* 深度解盘--*/
@interface VideoModel : NSObject
@property (nonatomic,strong)GoldModel *gold;
@property (nonatomic,strong)GoldModel *hot;
@end

/* 深度解盘--金色两点半*/
@interface GoldModel : NSObject
@property (nonatomic,assign)NSInteger ID;
@property (nonatomic,assign)NSInteger online_num;
@property (nonatomic,copy)NSString *redirectUrl;
@property (nonatomic,copy)NSString *summary;
@property (nonatomic,copy)NSString *thumb_href;
@property (nonatomic,copy)NSString *title;
@end






