//
//  HomeLiveModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/3.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface HomeLiveModel : BaseModel

/** ID*/
@property (nonatomic,assign)NSInteger ID;
/** name*/
@property (nonatomic,copy)NSString *name;
/** nid*/
@property (nonatomic,assign)NSInteger nid;
/** 在线人数*/
@property (nonatomic,assign)NSInteger online_num;
/** 跳转地址*/
@property (nonatomic, copy)NSString *redirectUrl;
/** 正文*/
@property (nonatomic,copy)NSString *summary;
/** 图片地址*/
@property (nonatomic, copy)NSString *thumb_href;
/** 标题*/
@property (nonatomic,copy)NSString *title;

@end
