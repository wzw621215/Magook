//
//  HomeModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/23.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"banner":@"BannerModel",
             @"follow":@"FollowModel",
             @"icons":@"IconModel",
             @"nrRecommend":@"NrRecomModel",
             @"topic":@"HTopicModel"
             };
}

@end

@implementation BannerModel

@end

@implementation FollowModel

@end

@implementation IconModel

@end

@implementation NrRecomModel

@end

@implementation HTopicModel


@end

@implementation UserModel

@end

@implementation AdModel

@end

@implementation VideoModel

@end

@implementation GoldModel

@end

//@implementation HotModel
//
//@end

