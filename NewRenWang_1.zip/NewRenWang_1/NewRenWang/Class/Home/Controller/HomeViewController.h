//
//  HomeViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewController.h"

@interface HomeViewController : BaseTableViewController

@end
