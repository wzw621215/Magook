//
//  HomeViewController.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeHeadView.h"
#import "HomeSectionHeadView.h"
#import "HomeTeacherCell.h"
#import "TopicCell.h"
#import "VideoCell.h"
#import "AdvCell.h"
#import "FavTeacherCell.h"
#import "LiveCell.h"
#import "HomeRequest.h"
#import "HomeModel.h"
#import "WebServesViewController.h"
#import "HomeLiveModel.h"
#import "NiuRenVC.h"
#import "NiuRenViewController.h"
#import "LoginViewController.h"
#import "SKAES.h"
#import "WKWebViewController.h"

#import "ZXVideo.h"

@interface HomeViewController ()<HomeBannerDelegate,HomeSectionHeadDelegate,PushNiuRenDelegate,FollowDelegate,PresentLoginDelegate,PushLiveDelegate,PushWKWebViewDelegate>

@property (nonatomic, weak) HomeHeadView *headerView;

@property (nonatomic, strong) HomeModel *homeModel;

@property (nonatomic, assign)BOOL isLive;     //是否有直播


@end

@implementation HomeViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self requestWebData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"首页";
    self.automaticallyAdjustsScrollViewInsets = NO;
    HomeHeadView *headView = [[HomeHeadView alloc] init];
    _headerView = headView;
    headView.delegate = self;
    headView.webViewDelegate = self;
    self.tableView.tableHeaderView = self.headerView;
    self.needCellSepLine = NO;
    
//    [self requestWebData];          //请求页面数据 除去直播
    [self requestLiveData];         //请求直播数据
}
#pragma mark -请求页面数据
- (void)requestWebData{
    HomeRequest *request = [HomeRequest request];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            HomeModel *homeModel = [[HomeModel alloc] mj_setKeyValues:response];
            
            _headerView.banner = homeModel.banner;
            _headerView.icons  = homeModel.icons;
            _homeModel = homeModel;
            [YDConfigurationHelper setBoolValueForConfigurationKey:kIsRequest withValue:YES];
        }
        [self.tableView reloadData];
    }];
}

#pragma mark - 请求直播数据
- (void)requestLiveData {
    BaseRequest *request = [BaseRequest requestWithUrl:kHomeLiveAPI];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            self.isLive = YES;
            NSArray *array = [NSArray arrayWithArray:response];
            for (NSDictionary *dic in array) {
                HomeLiveModel *model = [[HomeLiveModel alloc] mj_setKeyValues:dic];
                [self.dataArray addObject:model];
            }
            [self reloadData];
        }
        
    }];
}

- (CGFloat)cellheightAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 160;
    }else if (indexPath.section == 1){
        if (indexPath.row == 2 ||indexPath.row == 3) {
            return H(140, 667);        //视频
        }
        return 150;
    }else if (indexPath.section == 2){
        return 82;
    }else if (indexPath.section == 3){
        return  self.isLive?320:100;
    }else{
        return 100;
    }
}

- (NSInteger)numberOfSections{
    
    return self.isLive?5:4;
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section{
    if (section == 0 || section == 2) {
        return 1;
    }else if (section == 1){
        return 4;
    }else if (section == 3){
        return self.isLive?1:5;
    }else{
        return 5;
    }
}

- (CGFloat)sectionFooterHeightAtSection:(NSInteger)section{
    if (self.isLive) {
        if (section == 4) {
            return 0;
        }
        return 10;
    }else{
        if (section == 3) {
            return 0;
        }
        return 10;
    }
}

- (CGFloat)sectionHeaderHeightAtSection:(NSInteger)section {
    if (section == 2) {
        return 0;
    }
    return 40;
}

- (BaseTableViewCell *)cellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        HomeTeacherCell *cell = [HomeTeacherCell cellWithTableView:self.tableView];
        cell.delegate = self;
        cell.nrRecArr = self.homeModel.nrRecommend;
        return cell;
    }else if (indexPath.section == 1){
        if (indexPath.row == 0||indexPath.row == 1 ) {
            TopicCell *cell = [TopicCell nibCellWithTableView:self.tableView];
            cell.delegate = self;
            cell.loginDelegate = self;
            cell.NRDelegate = self;
            cell.model = self.homeModel.topic[indexPath.row];
            return cell;
        }else if (indexPath.row == 2){
            VideoCell *cell = [VideoCell nibCellWithTableView:self.tableView];
            cell.model = self.homeModel.video.gold;
            return cell;
        }else {
            VideoCell *cell = [VideoCell nibCellWithTableView:self.tableView];
            cell.model = self.homeModel.video.hot;
            return cell;
        }
    }else if (indexPath.section == 2){
        AdvCell *cell = [AdvCell nibCellWithTableView:self.tableView];
        cell.model = self.homeModel.ad;
        return cell;
    }else if (indexPath.section == 3){
        if (self.isLive) {
            LiveCell *cell = [LiveCell cellWithTableView:self.tableView];
            cell.liveArr = self.dataArray;
            cell.liveDelegate = self;
            return cell;
        }else{
            FavTeacherCell *cell = [FavTeacherCell nibCellWithTableView:self.tableView];
            cell.delegate = self;
            cell.loginDelegate = self;
            cell.model = [self.homeModel.follow objectAtIndexCheck:indexPath.row];
            return cell;
        }
    }else{
        FavTeacherCell *cell = [FavTeacherCell nibCellWithTableView:self.tableView];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
        cell.loginDelegate = self;
        cell.model = [self.homeModel.follow objectAtIndexCheck:indexPath.row];
        return cell;
    }
}

#pragma mark - 加载section的头部视图
- (UIView *)headerAtSection:(NSInteger)section{
    HomeSectionHeadView *sectionHeadView = [HomeSectionHeadView headerFooterViewWithTableView:self.tableView indexPath:section withIsLive:self.isLive];
    sectionHeadView.delegate = self;
    return sectionHeadView;
}

- (UIView *)footerAtSection:(NSInteger)section{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = kRGBColor(244,244,244);
    return view;
}

- (void)didSelectCellAtIndexPath:(NSIndexPath *)indexPath cell:(BaseTableViewCell *)cell{
    if (indexPath.section == 1) {
        if (indexPath.row == 2) {

            NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)self.homeModel.video.gold.ID,[UserInfoManage sharedManager].token];
            NSString *desSn = [SKAES  encryt:sn];
            NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)self.homeModel.video.gold.ID,desSn];
            // NSString *HurlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]; //设置字符编码
            WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
            [self.navigationController pushViewController:webViewController animated:YES];
        }else if (indexPath.row == 3){
            NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)self.homeModel.video.hot.ID,[UserInfoManage sharedManager].token];
            NSString *desSn = [SKAES  encryt:sn];
            NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)self.homeModel.video.hot.ID,desSn];
            WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
            [self.navigationController pushViewController:webViewController animated:YES];
        }
    }else if(indexPath.section == 2){
        UITabBarController *tabBar = (UITabBarController*)[[UIApplication.sharedApplication.delegate window] rootViewController];
        //修改tabBar选中的视图
        tabBar.selectedViewController = tabBar.viewControllers[1];
        //获取tabBar的子视图控制器
        BaseNavigationController *nav = tabBar.viewControllers[1];
        NiuRenViewController *vc = [nav.viewControllers firstObject];
        [vc selectVCIndex:2];
    }else if (indexPath.section == 3){
        if (self.isLive) {
            
        }else{
            FollowModel *model = [self.homeModel.follow objectAtIndexCheck:indexPath.row];
            [self pushNiuRenCenter:model.ID];
        }
    }else if (indexPath.section == 4){
        FollowModel *model = [self.homeModel.follow objectAtIndexCheck:indexPath.row];
        [self pushNiuRenCenter:model.ID];
    }
}


#pragma mark - PresentLoginDelegate  
- (void)presentLogin {
    //未登录  就先跳转到登录界面
    LoginViewController *login = [[LoginViewController alloc] init];
    BaseNavigationController *nav = [[BaseNavigationController alloc] initWithRootViewController:login];
    [self presentVc:nav];
}

#pragma mark - PushNiuRenDelegate
- (void)pushNiuRenCenter:(NSInteger)nrID {

//    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)nrID,[UserInfoManage sharedManager].token];
//    NSString *desSn = [SKAES  encryt:sn];
//    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/%ld.html?sn=%@",(long)nrID,desSn];
//    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
//    [self.navigationController pushViewController:webViewController animated:YES];

    
    NiuRenVC *niurenCenterVC = [[NiuRenVC alloc] init];
    niurenCenterVC.nrID = nrID;
    [self.navigationController pushViewController:niurenCenterVC animated:YES];    
 
}


#pragma makr -HomeSectionHeadDelegate
- (void)changeLiveVideo{
    [self.dataArray removeAllObjects];
    [self requestLiveData];
}

- (void)moreShenDuNews{
    UITabBarController *tabBar = (UITabBarController*)[[UIApplication.sharedApplication.delegate window] rootViewController];
    tabBar.selectedViewController = tabBar.viewControllers[1];
    BaseNavigationController *nav = tabBar.viewControllers[1];
    NiuRenViewController *vc = [nav.viewControllers firstObject];
    [vc selectVCIndex:1];
}

#pragma mark - HomeBannerDelegate
//icon前3个按钮
- (void)iconPushVC:(PushType)type {
    switch (type) {
        case ShenDuJiePan:
        {
            //获取根视图控制器
            UITabBarController *tabBar = (UITabBarController*)[[UIApplication.sharedApplication.delegate window] rootViewController];
            //修改tabBar选中的视图
            tabBar.selectedViewController = tabBar.viewControllers[1];
            //获取tabBar的子视图控制器
            BaseNavigationController *nav = tabBar.viewControllers[1];
            NiuRenViewController *vc = [nav.viewControllers firstObject];
            [vc selectVCIndex:1];
        }
            break;
        case NiuRenZaiXian:
            
            break;
        case CaoPanJingLing:
        {
            //获取根视图控制器
            UITabBarController *tabBar = (UITabBarController*)[[UIApplication.sharedApplication.delegate window] rootViewController];
            //修改tabBar选中的视图
            tabBar.selectedViewController = tabBar.viewControllers[1];
            //获取tabBar的子视图控制器
            BaseNavigationController *nav = tabBar.viewControllers[1];
            NiuRenViewController *vc = [nav.viewControllers firstObject];
            [vc selectVCIndex:3];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - PushWKWebViewDelegate
- (void)pushWKWebView:(NSString*)bannerURL {
    WKWebViewController *web = [[WKWebViewController alloc] init];
    [web loadWebURLSring:bannerURL];
    [self.navigationController pushViewController:web animated:YES];
}

#pragma mark - PushLiveDelegate 进入直播间
- (void)pushLiveWith:(NSInteger)liveID {
    NSString *sn = [NSString stringWithFormat:@"%ld,%@,yznr126956",(long)liveID,[UserInfoManage sharedManager].token];
    NSString *desSn = [SKAES  encryt:sn];
    NSString *urlStr = [NSString stringWithFormat:@"http://demo.sionka.com/niuren-h5/src/niuren/live/%ld.html?sn=%@",(long)liveID,desSn];
    WebServesViewController *webViewController = [[WebServesViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
    [self.navigationController pushViewController:webViewController animated:YES];
}

#pragma mark - FollowDelegate  关注或取消关注
- (void)followTeacher {
    [self requestWebData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
