//
//  DownRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface DownRequest : BaseRequest

- (instancetype)initWithType:(NSInteger)type targetid:(NSInteger)targetid;

@end
