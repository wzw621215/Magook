//
//  DeleFollowRequest.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseRequest.h"

@interface DeleFollowRequest : BaseRequest
- (instancetype)initWithTargetid:(NSInteger)targetid;
@end
