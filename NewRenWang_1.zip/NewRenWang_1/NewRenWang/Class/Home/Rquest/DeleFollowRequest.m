//
//  DeleFollowRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "DeleFollowRequest.h"
@interface DeleFollowRequest()

/** 关注牛人ID*/
@property (nonatomic, assign)NSInteger targetid;

@end

@implementation DeleFollowRequest

- (instancetype)initWithTargetid:(NSInteger)targetid{
    if (self == [super init]) {
        _targetid = targetid;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSDictionary *)params {
    return @{
             @"targetid":@(_targetid)
             };
}

- (NSString *)url{
    return kDeleFollowAPI;
}

@end
