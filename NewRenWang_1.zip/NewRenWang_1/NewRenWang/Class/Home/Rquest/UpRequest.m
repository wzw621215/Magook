//
//  UpRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "UpRequest.h"
@interface UpRequest()

/** 类别*/
@property(nonatomic, assign)NSInteger type;
/** 栏目ID*/
@property(nonatomic, assign)NSInteger categoryid;
/** 点赞目标*/
@property(nonatomic, assign)NSInteger targetid;

@end

@implementation UpRequest

- (instancetype)initWithType:(NSInteger)type targetid:(NSInteger)targetid{
    if (self == [super init]) {
        _type = type;
        _targetid = targetid;
    }
    return self;
}

- (BOOL)isPost {
    return YES;
}

- (NSDictionary *)params {
    return @{
             @"type":@(_type),
             @"targetid":@(_targetid)
             };
}

- (NSString *)url{
    return kUpAPI;
}

@end
