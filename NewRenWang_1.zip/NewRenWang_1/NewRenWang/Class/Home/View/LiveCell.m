//
//  LiveCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "LiveCell.h"
#import "LiveView.h"
#import "HomeLiveModel.h"


@interface LiveCell ()
@property (nonatomic,weak)UIView *line;
@property (nonatomic,weak)LiveView *view1;
@property (nonatomic,weak)LiveView *view2;
@property (nonatomic,weak)LiveView *view3;
@property (nonatomic,weak)LiveView *view4;
@end

@implementation LiveCell

- (void)setLiveArr:(NSMutableArray *)liveArr {
    _liveArr = liveArr;
    [liveArr enumerateObjectsUsingBlock:^(HomeLiveModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx == 0) {
            self.view1.model = obj;
        }else if (idx == 1){
            self.view2.model = obj;
        }else if (idx == 2){
            self.view3.model = obj;
        }else if (idx == 3){
            self.view4.model = obj;
        }
    }];
}

- (UIView *)line {
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(220,220,220);
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;
}

- (LiveView *)view1 {
    if (!_view1) {
        LiveView *view1 = [LiveView liveView];
        [view1 addActionWithTarget:self action:@selector(pushLive1)];
        [self.contentView addSubview:view1];
        _view1 = view1;
    }
    return _view1;
}

- (LiveView *)view2 {
    if (!_view2) {
        LiveView *view2 = [LiveView liveView];
        [view2 addActionWithTarget:self action:@selector(pushLive2)];
        [self.contentView addSubview:view2];
        _view2 = view2;
    }
    return _view2;
}

- (LiveView *)view3 {
    if (!_view3) {
        LiveView *view3 = [LiveView liveView];
        [view3 addActionWithTarget:self action:@selector(pushLive3)];
        [self.contentView addSubview:view3];
        _view3 = view3;
    }
    return _view3;
}

- (LiveView *)view4 {
    if (!_view4) {
        LiveView *view4 = [LiveView liveView];
        [view4 addActionWithTarget:self action:@selector(pushLive4)];
        [self.contentView addSubview:view4];
        _view4 = view4;
    }
    return _view4;
}

- (void)pushLive1{
    if (self.liveArr.count>0 && [self.liveDelegate respondsToSelector:@selector(pushLiveWith:)]) {
        HomeLiveModel *model = self.liveArr[0];
        [self.liveDelegate pushLiveWith:model.ID];
    }
}

- (void)pushLive2{
    if (self.liveArr.count>0 && [self.liveDelegate respondsToSelector:@selector(pushLiveWith:)]) {
        HomeLiveModel *model = self.liveArr[1];
        [self.liveDelegate pushLiveWith:model.ID];
    }
}

- (void)pushLive3{
    if (self.liveArr.count>0 && [self.liveDelegate respondsToSelector:@selector(pushLiveWith:)]) {
        HomeLiveModel *model = self.liveArr[2];
        [self.liveDelegate pushLiveWith:model.ID];
    }
}

- (void)pushLive4{
    if (self.liveArr.count>0 && [self.liveDelegate respondsToSelector:@selector(pushLiveWith:)]) {
        HomeLiveModel *model = self.liveArr[3];
        [self.liveDelegate pushLiveWith:model.ID];
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@0.5);
    }];
    
    [self.view1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.view2.mas_left).offset(-15);
        make.width.equalTo(@((self.contentView.width-35)/2));
        make.top.equalTo(self.contentView.mas_top).offset(10);
        make.bottom.equalTo(self.view3.mas_top).offset(-15);
        make.height.equalTo(@((self.contentView.height-35)/2));
    }];
    
    [self.view2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.centerY.mas_equalTo(self.view1.mas_centerY);
        make.width.height.equalTo(self.view1);
    }];
    
    [self.view3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.view4.mas_left).offset(-15);
        
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-10);
        make.width.height.equalTo(self.view1);
    }];
    
    [self.view4 mas_makeConstraints:^(MASConstraintMaker *make) {

        make.right.equalTo(self.contentView.mas_right).offset(-10);
        
        make.centerY.mas_equalTo(self.view3.mas_centerY);
        make.width.height.equalTo(self.view1);
    }];
}
@end
