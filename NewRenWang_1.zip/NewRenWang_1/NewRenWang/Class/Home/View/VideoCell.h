//
//  VideoCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "HomeModel.h"

@interface VideoCell : BaseTableViewCell

@property (nonatomic,strong)GoldModel *model;

@end
