//
//  TeacherView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TeacherView.h"

@interface TeacherView ()

@property (weak, nonatomic) IBOutlet UIImageView *teachImg;

@property (weak, nonatomic) IBOutlet UILabel *teachName;

@property (weak, nonatomic) IBOutlet UILabel *teachTitle;

@property (weak, nonatomic) IBOutlet UILabel *teachProfile;


@end

@implementation TeacherView

+(instancetype)teacherView {
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil].lastObject;
}

- (void)setModel:(NrRecomModel *)model {
    _model = model;
    [self.teachImg sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    self.teachName.text = model.name;
    self.teachTitle.text = model.title;
    self.teachProfile.text = model.profile;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.layer.masksToBounds = YES;
    self.layer.borderWidth = 0.5;
    self.layer.cornerRadius = 3;
    self.layer.borderColor = kRGBColor(220,220,220).CGColor;
    
    self.teachImg.layer.masksToBounds = YES;
    self.teachImg.layer.cornerRadius = 30;
    self.autoresizingMask = UIViewAutoresizingNone;
}

@end
