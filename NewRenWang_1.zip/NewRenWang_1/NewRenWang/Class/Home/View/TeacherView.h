//
//  TeacherView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

@interface TeacherView : UIView

@property (nonatomic, strong)NrRecomModel *model;

+ (instancetype)teacherView;

@end
