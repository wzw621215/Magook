//
//  TopicCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "TopicCell.h"
#import "UpRequest.h"
#import "DownRequest.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"


@interface TopicCell ()

@property (weak, nonatomic) IBOutlet UIImageView *teachImg;
@property (weak, nonatomic) IBOutlet YYLabel *content;
@property (weak, nonatomic) IBOutlet UIButton *attenBtn;  //关注按钮
@property (weak, nonatomic) IBOutlet UILabel *topicName;    //老师名字
@property (weak, nonatomic) IBOutlet UILabel *topicFans; //粉丝人数
@property (weak, nonatomic) IBOutlet UILabel *strong;
@property (weak, nonatomic) IBOutlet UILabel *weak;
@property (weak, nonatomic) IBOutlet UIButton *strongBtn;
@property (weak, nonatomic) IBOutlet UIButton *weakBtn;

@property (nonatomic, strong)UILabel *time;
@property (nonatomic, strong)NSMutableAttributedString *textImage;
@property (nonatomic, strong)UIImageView *stateImage;


@end

@implementation TopicCell

- (void)setModel:(HTopicModel *)model {
    if (model == nil) {
        return ;
    }
    _model = model;
    [self.teachImg sd_setImageWithURL:[NSURL URLWithString:model.user.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
 {
    self.textImage = [NSMutableAttributedString new];
    self.stateImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"time"]];
    self.time = [[UILabel alloc] initWithFrame:_stateImage.frame];
    _time.text = model.time;
    _time.textColor = kRGBColor(125, 125, 125);;
    _time.font = kFont(11);
    _time.textAlignment = NSTextAlignmentCenter;
    [_stateImage addSubview:_time];
    [_textImage appendAttributedString:[NSMutableAttributedString yy_attachmentStringWithContent:_stateImage contentMode:UIViewContentModeCenter attachmentSize:CGSizeMake(39, 15) alignToFont:[UIFont systemFontOfSize:12.0f] alignment:YYTextVerticalAlignmentCenter]];
    [_textImage yy_appendString:model.content];
    _textImage.yy_lineSpacing = 5;
    self.content.attributedText = _textImage;
    self.content.numberOfLines = 0;
    self.content.font = kFont(12);
    self.content.textColor = kRGBColor(0, 0, 0);
 }
    self.topicName.text = model.user.name;
    self.topicFans.text = [NSString stringWithFormat:@"%ld",(long)model.user.fans];
    
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if ([YDConfigurationHelper getBoolValueForConfigurationKey:kIsRequest]) {
            self.strong.text = [NSString stringWithFormat:@"%ld",(long)model.up];
            self.weak.text = [NSString stringWithFormat:@"%ld",(long)model.down];
            self.strongBtn.selected = model.isup;
            self.weakBtn.selected = model.isdown;
        }
        self.attenBtn.selected = model.user.isfollw;
    }else{
        //未登录
        self.strong.text = [NSString stringWithFormat:@"%ld",(long)model.up];
        self.weak.text = [NSString stringWithFormat:@"%ld",(long)model.down];
        self.strongBtn.selected = NO;
        self.weakBtn.selected = NO;
        self.attenBtn.selected = NO;
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self.teachImg addActionWithTarget:self action:@selector(pushNiuRen)];
}

#pragma mark - push到牛人中心
- (void)pushNiuRen{
    if ([self.NRDelegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        [self.NRDelegate pushNiuRenCenter:self.model.user.ID];
    }
}

#pragma mark - 关注按钮
- (IBAction)attentionTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if ([self.delegate respondsToSelector:@selector(followTeacher)]) {
            [self.delegate followTeacher];
        }
        if (self.attenBtn.selected) {
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.attenBtn.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.user.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    
                    self.attenBtn.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

#pragma mark - 给老师踩 只有用户没有进行赞或者踩才能点击
- (IBAction)downToTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        DownRequest *request = [[DownRequest alloc] initWithType:self.model.type targetid:self.model.ID];
        [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
            if (success) {
                [YDConfigurationHelper setBoolValueForConfigurationKey:kIsRequest withValue:NO];
                //点踩成功  或者取消点踩成功
                self.weakBtn.selected = !self.weakBtn.selected;
                self.weak.text = [NSString stringWithFormat:@"%@",response[@"down"]];
                self.strong.text = [NSString stringWithFormat:@"%@",response[@"up"]];
            }else{
                [CNNavigationBarHUD showError:message];
            }
        }];
    }else{
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

#pragma mark - 给老师点赞 只有用户没有进行赞或者踩才能点击
- (IBAction)upToTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
            UpRequest *request = [[UpRequest alloc] initWithType:self.model.type targetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    [YDConfigurationHelper setBoolValueForConfigurationKey:kIsRequest withValue:NO];
                    //点赞成功  或者取消点赞成功
                    self.strongBtn.selected = !self.strongBtn.selected;
                    self.strong.text = [NSString stringWithFormat:@"%@",response[@"up"]];
                    self.weak.text = [NSString stringWithFormat:@"%@",response[@"down"]];
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
                [self.loginDelegate presentLogin];
        }
    }
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
}


@end
