//
//  VideoCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "VideoCell.h"
#import "iPhoneModel.h"

@interface VideoCell ()

@property (weak, nonatomic) IBOutlet UILabel *videoTitle;

@property (weak, nonatomic) IBOutlet UIImageView *videoImg;

@property (weak, nonatomic) IBOutlet YYLabel *content;

@property (weak, nonatomic) IBOutlet UILabel *onlineNum;


@end

@implementation VideoCell

- (void)setModel:(GoldModel *)model {
    _model = model;
    
    if (model == nil) {
        return;
    }
    
    self.videoTitle.text = [self handleStringWithString:model.title];
    
    [self.videoImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"video_gold"]];
    self.onlineNum.text = [NSString stringWithFormat:@"在线人数:%ld",(long)model.online_num];
    
    NSString *string = [NSString stringWithFormat:@"%@",model.summary];
    NSMutableAttributedString *contentAtt = [[NSMutableAttributedString alloc] initWithString:string attributes:@{NSForegroundColorAttributeName:kRGBColor(125, 125, 125)}];
    contentAtt.yy_lineSpacing = 5;
    self.content.numberOfLines = 0;
    self.content.font = kFont(13);
    self.content.attributedText = contentAtt;
    
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    if ([[iPhoneModel iphoneType] isEqualToString:@"iPhone 5c"]||[[iPhoneModel iphoneType] isEqualToString:@"iPhone 5s"]) {
        self.videoTitle.font = kFont(13.0);
    }else{
        self.videoTitle.font = kFont(15.0);

    }
//    [self.videoTitle addActionWithTarget:self action:@selector(pushVideo)];
//    [self.videoImg addActionWithTarget:self action:@selector(pushVideo)];
//    [self.content addActionWithTarget:self action:@selector(pushVideo)];
}

-(NSString *)handleStringWithString:(NSString *)str{
    
    NSMutableString * muStr = [NSMutableString stringWithString:str];
    
    NSRange range = [muStr rangeOfString:@"《"];  //0 1
    NSRange range1 = [muStr rangeOfString:@"》"]; //6 1
    if (range.location != NSNotFound) {
        [muStr deleteCharactersInRange:NSMakeRange(range1.location, str.length-range1.location)];
        [muStr deleteCharactersInRange:NSMakeRange(range.location, range.length)];
        
    }
//    NSInteger location = range.location+range.length;
//    NSInteger length = range1.location-range.length;
//    return [muStr substringWithRange:NSMakeRange(location,length)];
    return muStr;
}

@end
