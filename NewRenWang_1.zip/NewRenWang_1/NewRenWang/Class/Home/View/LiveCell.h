//
//  LiveCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface LiveCell : BaseTableViewCell

@property (nonatomic,weak)id <PushLiveDelegate> liveDelegate;

@property (nonatomic, strong)NSMutableArray *liveArr;

@end
