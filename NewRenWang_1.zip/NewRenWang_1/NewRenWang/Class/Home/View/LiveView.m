//
//  LiveView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/16.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "LiveView.h"

@interface LiveView ()

@property (weak, nonatomic) IBOutlet UIImageView *liveImg;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *summary;
@property (weak, nonatomic) IBOutlet UILabel *num;
@property (weak, nonatomic) IBOutlet UILabel *name;

@end

@implementation LiveView

+ (instancetype)liveView{
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil].lastObject;
}

- (void)setModel:(HomeLiveModel *)model {
    _model = model;
    [self.liveImg sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"nr_live"]];
    self.title.text = model.title;
    self.summary.text = model.summary;
    self.num.text = [NSString stringWithFormat:@"%ld",(long)model.online_num];
    self.name.text = model.name;
}

@end
