//
//  HomeSectionHeadView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewHeaderFooterView.h"

@protocol HomeSectionHeadDelegate <NSObject>
/** 换一批直播*/
- (void)changeLiveVideo;

/** 深度解盘更多*/
- (void)moreShenDuNews;

@end


@interface HomeSectionHeadView : BaseTableViewHeaderFooterView

@property (nonatomic, weak)id<HomeSectionHeadDelegate>delegate;
/** 上面的横线*/
@property (nonatomic, weak)UIView *line;
/** 左侧红色短粗线*/
@property (nonatomic, weak)UIImageView *leftLine;

@property (nonatomic, weak)UILabel *title;

@property (nonatomic, weak)UIButton *rightBtn;

+ (instancetype)headerFooterViewWithTableView:(UITableView *)tableView indexPath:(NSInteger)section withIsLive:(BOOL)isLive;

@end
