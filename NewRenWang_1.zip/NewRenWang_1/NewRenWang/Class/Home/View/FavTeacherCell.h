//
//  FavTeacherCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "HomeModel.h"

@interface FavTeacherCell : BaseTableViewCell

@property (nonatomic,weak)id<FollowDelegate>delegate;

@property (nonatomic,weak)id<PresentLoginDelegate>loginDelegate;

@property (nonatomic, strong)FollowModel *model;


@end
