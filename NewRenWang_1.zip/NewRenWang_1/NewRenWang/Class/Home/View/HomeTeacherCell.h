//
//  HomeTeacherCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseTableViewCell.h"
#import "HomeModel.h"

@interface HomeTeacherCell : BaseTableViewCell

@property (nonatomic,weak)id<PushNiuRenDelegate>delegate;

@property(nonatomic, strong)NSArray <NrRecomModel *> *nrRecArr;

@end
