//
//  FavTeacherCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "FavTeacherCell.h"
#import "FollowRequest.h"
#import "DeleFollowRequest.h"

@interface FavTeacherCell ()
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *fans;
@property (weak, nonatomic) IBOutlet UILabel *profile;
@property (weak, nonatomic) IBOutlet UILabel *tally;
@property (weak, nonatomic) IBOutlet UIButton *followBtn;

@end

@implementation FavTeacherCell

- (void)setModel:(FollowModel *)model {
    _model = model;
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"me_icon"]];
    
    self.name.text = model.name;
    self.fans.text = [NSString stringWithFormat:@"%ld人关注",(long)model.fans];
    
    NSString *string = [NSString stringWithFormat:@"%@",model.profile];
    NSMutableAttributedString *profileAtt = [[NSMutableAttributedString alloc] initWithString:string attributes:@{NSForegroundColorAttributeName:kRGBColor(125, 125, 125)}];
    profileAtt.yy_lineSpacing = 5;
    self.profile.numberOfLines = 0;
    self.profile.font = kFont(13);
    self.profile.attributedText = profileAtt;
    self.profile.text = model.profile;
    self.tally.text = model.speciality;
    
    if ([UserInfoManage sharedManager].isLogin) {
       self.followBtn.selected = model.isfollw;
    }else{
       self.followBtn.selected = NO;
    }
}
- (IBAction)followTeacher:(id)sender {
    if ([UserInfoManage sharedManager].isLogin) {
        //已登录
        if ([self.delegate respondsToSelector:@selector(followTeacher)]) {
            [self.delegate followTeacher];
        }
        if (self.followBtn.selected) {
            
            DeleFollowRequest *request = [[DeleFollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = NO;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }else{
            FollowRequest *request = [[FollowRequest alloc] initWithTargetid:self.model.ID];
            [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
                if (success) {
                    self.followBtn.selected = YES;
                }else{
                    [CNNavigationBarHUD showError:message];
                }
            }];
        }
    }else{
        //未登录
        if ([self.loginDelegate respondsToSelector:@selector(presentLogin)]) {
            [self.loginDelegate presentLogin];
        }
    }
}

@end
