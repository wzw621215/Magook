//
//  HomeHeadView.h
//  NewRenWang
//
//  Created by JopYin on 2017/2/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

typedef NS_ENUM(NSInteger ,PushType) {
    ShenDuJiePan = 0,
    NiuRenZaiXian,
    CaoPanJingLing
};

@protocol HomeBannerDelegate <NSObject>
/**点击icon中前3个按钮跳转到对应控制器界面*/
- (void)iconPushVC:(PushType)type;

@end

@interface HomeHeadView : UIView

@property (nonatomic,weak)id<HomeBannerDelegate> delegate;

@property (nonatomic,weak)id<PushWKWebViewDelegate> webViewDelegate;

@property (nonatomic,strong) NSArray<BannerModel *> *banner;   //banner

@property (nonatomic,strong) NSArray<IconModel *>*icons;

@end
