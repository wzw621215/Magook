//
//  HomeSectionHeadView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HomeSectionHeadView.h"

@interface HomeSectionHeadView ()

@end

@implementation HomeSectionHeadView

+ (instancetype)headerFooterViewWithTableView:(UITableView *)tableView indexPath:(NSInteger)section withIsLive:(BOOL)isLive{
    
    if (section == 0) {
        HomeSectionHeadView *header = [HomeSectionHeadView headerFooterViewWithTableView:tableView];
        header.title.text = @"牛人推荐";
        header.rightBtn.hidden = YES;
        return header;
    }else if (section == 1){
        HomeSectionHeadView *header = [HomeSectionHeadView headerFooterViewWithTableView:tableView];
        header.title.text = @"深度解盘";
        [header.rightBtn setImage:[UIImage imageNamed:@"rightArrow"] forState:0];
        [header.rightBtn setTitle:@" 更多" forState:0];
        header.rightBtn.tag = 1;
        header.rightBtn.hidden = NO;
        return header;
    }else if (section == 3){
        if (isLive) {
            HomeSectionHeadView *header = [HomeSectionHeadView headerFooterViewWithTableView:tableView];
            header.title.text = @"正在直播";
            [header.rightBtn setImage:[UIImage imageNamed:@"huanYhuan"] forState:0];
            [header.rightBtn setTitle:@"换一批" forState:UIControlStateNormal];
            header.rightBtn.tag = 2;
            header.rightBtn.hidden = NO;
            return header;
        }else{
            HomeSectionHeadView *header = [HomeSectionHeadView headerFooterViewWithTableView:tableView];
            header.title.text = @"最受关注";
            header.rightBtn.hidden = YES;
            return header;
        }
    }else{
         HomeSectionHeadView *header = [HomeSectionHeadView headerFooterViewWithTableView:tableView];
        header.title.text = @"最受关注";
        header.rightBtn.hidden = YES;
        return header;
    }
}


- (UIView *)line {
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(220,220,220);
        [self addSubview:line];
        _line = line;
    }
    return _line;
}

- (UIImageView *)leftLine {
    if (!_leftLine) {
        UIImageView *leftLine = [[UIImageView alloc] init];
        leftLine.image = [UIImage imageWithColor:kRGBColor(209,31,14)];
        [self.contentView addSubview:leftLine];
        _leftLine = leftLine;
    }
    return _leftLine;
}

- (UILabel *)title {
    if (!_title) {
        UILabel * title = [[UILabel alloc] init];
        title.textColor = [UIColor blackColor];
        [self addSubview:title];
        _title = title;
    }
    return _title;
}

- (UIButton *)rightBtn {
    if (!_rightBtn) {
        UIButton *rightBtn  = [[UIButton alloc] init];
        rightBtn.titleLabel.font = [UIFont systemFontOfSize:12.0f];
        [rightBtn setTitleColor:kRGBColor(125,125,125) forState:0];
        rightBtn.titleEdgeInsets = UIEdgeInsetsMake(0,-30,0,0);
        rightBtn.imageEdgeInsets = UIEdgeInsetsMake(0,35,0,0);
        [rightBtn addTarget:self action:@selector(sectionHeadBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:rightBtn];
        _rightBtn = rightBtn;
    }
    return _rightBtn;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.contentView.backgroundColor = kWhiteColor;
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.mas_left);
        make.right.equalTo(self.mas_right);
        make.height.equalTo(@0.5);
    }];
    
    [self.leftLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).offset(10);
        make.width.equalTo(@5);
        make.height.equalTo(@20);
        
    }];
    
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.equalTo(self.leftLine).offset(10);
        make.width.equalTo(@150);
        make.height.equalTo(@30);
    }];
    
    [self.rightBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.right.equalTo(self.mas_right).offset(-10);
        make.width.equalTo(@50);
        make.height.equalTo(@25);
    }];
}

- (void)sectionHeadBtn:(UIButton *)btn {
    if (btn.tag == 1) {
        if ([self.delegate respondsToSelector:@selector(moreShenDuNews)]) {
            [self.delegate moreShenDuNews];
        }
    }else{
        if ([self.delegate respondsToSelector:@selector(changeLiveVideo)]) {
            [self.delegate changeLiveVideo];
        }
    }
}


@end
