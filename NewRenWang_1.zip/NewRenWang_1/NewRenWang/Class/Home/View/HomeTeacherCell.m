//
//  HomeTeacherCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/14.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HomeTeacherCell.h"
#import "TeacherView.h"
#import "HomeModel.h"

@interface HomeTeacherCell()

@property (nonatomic,weak)UIScrollView *scrollView;

@property (nonatomic,weak)UIView *line;

@property (nonatomic,weak)TeacherView *view1;

@property (nonatomic,weak)TeacherView *view2;

@property (nonatomic,weak)TeacherView *view3;

@property (nonatomic,weak)TeacherView *view4;

@end

@implementation HomeTeacherCell

- (void)setNrRecArr:(NSArray <NrRecomModel *>*)nrRecArr{
    _nrRecArr = nrRecArr;
    [nrRecArr enumerateObjectsUsingBlock:^(NrRecomModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx == 0) {
            self.view1.model = obj;
        }else if (idx == 1){
            self.view2.model = obj;
        }else if (idx == 2){
            self.view3.model = obj;
        }else if (idx == 3){
            self.view4.model = obj;
        }
    }];
    
}

- (UIView *)line {
    if (!_line) {
        UIView *line = [[UIView alloc] init];
        line.backgroundColor = kRGBColor(220,220,220);
        [self.contentView addSubview:line];
        _line = line;
    }
    return _line;
}

- (TeacherView *)view1 {
    if (!_view1) {
        TeacherView *view1 = [TeacherView teacherView];
        [view1 addActionWithTarget:self action:@selector(pushTeacher1)];
        [self.scrollView addSubview:view1];
        _view1 = view1;
    }
    return _view1;
}

- (TeacherView *)view2 {
    if (!_view2) {
        TeacherView *view2 = [TeacherView teacherView];
        [view2 addActionWithTarget:self action:@selector(pushTeacher2)];
        [self.scrollView addSubview:view2];
        _view2 = view2;
    }
    return _view2;
}

- (TeacherView *)view3 {
    if (!_view3) {
        TeacherView *view3 = [TeacherView teacherView];
        [view3 addActionWithTarget:self action:@selector(pushTeacher3)];
        [self.scrollView addSubview:view3];
        _view3 = view3;
    }
    return _view3;
}

- (TeacherView *)view4 {
    if (!_view4) {
        TeacherView *view4 = [TeacherView teacherView];
        [view4 addActionWithTarget:self action:@selector(pushTeacher4)];
        [self.scrollView addSubview:view4];
        _view4 = view4;
    }
    return _view4;
}


- (UIScrollView *)scrollView{
    if (!_scrollView) {
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 10, ScreenWIDTH-20, 140)];
        scrollView.backgroundColor = [UIColor whiteColor];
        scrollView.showsHorizontalScrollIndicator = NO;
        [self.contentView addSubview:scrollView];
        _scrollView = scrollView;
    }
    return _scrollView;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.left.equalTo(self.contentView.mas_left).offset(10);
        make.right.equalTo(self.contentView.mas_right).offset(-10);
        make.height.equalTo(@0.5);
    }];
    
    CGFloat viewWidth = (self.scrollView.width-30)/3;
    self.view1.frame = CGRectMake(0, 0, viewWidth, self.scrollView.height);
    self.view2.frame = CGRectMake(viewWidth+15, 0, viewWidth, self.scrollView.height);
    self.view3.frame = CGRectMake(2*(viewWidth+15), 0, viewWidth, self.scrollView.height);
    self.view4.frame = CGRectMake(3*(viewWidth+15), 0, viewWidth, self.scrollView.height);
    self.scrollView.contentSize = CGSizeMake(4*viewWidth+45, self.scrollView.height);
}

- (void)pushTeacher1{
    if (self.nrRecArr.count>0 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecomModel *model = self.nrRecArr[0];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher2{
    if (self.nrRecArr.count>1 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecomModel *model = self.nrRecArr[1];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher3{
    if (self.nrRecArr.count>2 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecomModel *model = self.nrRecArr[2];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}
- (void)pushTeacher4{
    if (self.nrRecArr.count>3 && [self.delegate respondsToSelector:@selector(pushNiuRenCenter:)]) {
        NrRecomModel *model = self.nrRecArr[3];
        [self.delegate pushNiuRenCenter:model.ID];
    }
}

@end
