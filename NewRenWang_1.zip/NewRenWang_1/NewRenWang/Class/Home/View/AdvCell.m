//
//  AdvCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/15.
//  Copyright © 2017年 . All rights reserved.
//

#import "AdvCell.h"

@interface AdvCell ()

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end


@implementation AdvCell

- (void)setModel:(AdModel *)model {
    _model = model;
    self.title.text = model.title;
    self.content.text = model.summary;
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.thumb_href] placeholderImage:[UIImage imageNamed:@"home_ad"]];
}


@end
