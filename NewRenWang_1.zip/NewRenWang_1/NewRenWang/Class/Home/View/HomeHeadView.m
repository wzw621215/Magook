//
//  HomeHeadView.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "HomeHeadView.h"
#import "SDCycleScrollView.h"
#import "JXButton.h"
#import "UIButton+WebCache.h"

@interface HomeHeadView ()<SDCycleScrollViewDelegate>

@property (nonatomic, assign) CGFloat bannerHeight;

@property (nonatomic, weak) UIImage *bannerImage;

@property (nonatomic, weak) SDCycleScrollView *bannerView;

@property (nonatomic, weak) JXButton *firstBtn;

@property (nonatomic, weak) JXButton *secondBtn;

@property (nonatomic, weak) JXButton *threeBtn;

@property (nonatomic, weak) JXButton *fourBtn;

@property (nonatomic, weak) UIView *btnView;

@property (nonatomic,strong)NSMutableArray *bannerTitle;
@property (nonatomic,strong)NSMutableArray *bannerImg;
@property (nonatomic,strong)NSMutableArray *bannerURL;

@property (nonatomic,strong)NSMutableArray *iconTitle;
@property (nonatomic,strong)NSMutableArray *iconImg;
@property (nonatomic,strong)NSMutableArray *iconURL;

@end

@implementation HomeHeadView

- (void)setBanner:(NSArray *)banner{
    _banner = banner;
    [self.bannerTitle removeAllObjects];
    [self.bannerImg removeAllObjects];
    [self.bannerURL removeAllObjects];
    for (BannerModel *model in banner) {
//        [self.bannerTitle addObject:model.title];
        [self.bannerImg addObject:model.thumb_href];
        [self.bannerURL addObject:model.redirectUrl];
    }
//    self.bannerView.titlesGroup = self.bannerTitle;
    self.bannerView.imageURLStringsGroup = self.bannerImg;
}

- (void)setIcons:(NSArray *)icons{
    _icons = icons;
    for (IconModel *model in icons) {
        [self.iconTitle addObject:model.title];
        [self.iconImg addObject:model.thumb_href];
        [self.iconURL addObject:model.redirectUrl];
    }
    if (icons.count > 0) {
        [self.fourBtn setTitle:self.iconTitle.lastObject forState:0];
        [self.fourBtn sd_setImageWithURL:[NSURL URLWithString:self.iconImg.lastObject] forState:0 placeholderImage:[UIImage imageNamed:@"lqnc"]];
    }
}

- (instancetype)init {
    
    self = [super init];
    if (self) {
        [self createUI];
    }
    return self;
}

- (void)createUI{
    self.frame = CGRectMake(0, 0, ScreenWIDTH, 80);
    self.backgroundColor = kRGBColor(244, 244, 244);
    _bannerImage = [UIImage imageNamed:@"DefaultImage_banner"];
    CGFloat paramFloat = _bannerImage.size.width/_bannerImage.size.height;
    CGFloat imageWidth = self.width;
    _bannerHeight = imageWidth/paramFloat;
    
    SDCycleScrollView *bannerView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, self.width, _bannerHeight) delegate:self placeholderImage:_bannerImage];
    bannerView.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    bannerView.currentPageDotColor = [UIColor whiteColor]; // 自定义分页控件小圆标颜色
    _bannerView = bannerView;
    [self addSubview:bannerView];
    
    bannerView.clickItemOperationBlock = ^(NSInteger index) {
        CNLog(@">>>>>  %ld", (long)index);
    };
    
    
    //banner下面四个按钮的背景view
    UIView *btnView = [[UIView alloc] initWithFrame:CGRectMake(0, _bannerHeight, ScreenWIDTH, 90)];
    btnView.backgroundColor = [UIColor whiteColor];
    [self addSubview:btnView];
    _btnView = btnView;
    
    JXButton *firstBtn = [[JXButton alloc] init];
    firstBtn.tag = 0;
    [firstBtn setTitleColor:[UIColor blackColor] forState:0];
    [firstBtn addTarget:self action:@selector(iconAction:) forControlEvents:UIControlEventTouchUpInside];
    [firstBtn setImage:[UIImage imageNamed:@"sdjp"] forState:UIControlStateNormal];
    [firstBtn setTitle:@"深度解盘" forState:UIControlStateNormal];
    _firstBtn = firstBtn;
    [btnView addSubview:firstBtn];
    
    JXButton *secondBtn = [[JXButton alloc] init];
    secondBtn.tag = 1;
    [secondBtn setTitleColor:[UIColor blackColor] forState:0];
    [secondBtn addTarget:self action:@selector(iconAction:) forControlEvents:UIControlEventTouchUpInside];
    [secondBtn setImage:[UIImage imageNamed:@"nrzx"] forState:UIControlStateNormal];
    [secondBtn setTitle:@"牛人在线" forState:UIControlStateNormal];
    _secondBtn = secondBtn;
    [btnView addSubview:secondBtn];
    
    JXButton *threeBtn = [[JXButton alloc] init];
    threeBtn.tag = 2;
    [threeBtn setTitleColor:[UIColor blackColor] forState:0];
    [threeBtn addTarget:self action:@selector(iconAction:) forControlEvents:UIControlEventTouchUpInside];
    [threeBtn setImage:[UIImage imageNamed:@"cpjl"] forState:UIControlStateNormal];
    [threeBtn setTitle:@"操盘精灵" forState:UIControlStateNormal];
    _threeBtn = threeBtn;
    [btnView addSubview:threeBtn];
    
    
    JXButton *fourBtn = [[JXButton alloc] init];
    fourBtn.tag = 3;
    [fourBtn setTitleColor:[UIColor blackColor] forState:0];
    [fourBtn addTarget:self action:@selector(iconAction:) forControlEvents:UIControlEventTouchUpInside];
    [fourBtn setImage:[UIImage imageNamed:@"lqnc"] forState:UIControlStateNormal];
    [fourBtn setTitle:@"领取内参" forState:UIControlStateNormal];
    _fourBtn = fourBtn;
    [btnView addSubview:fourBtn];
    
    self.height = _bannerHeight+100;
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.firstBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.btnView.mas_left).offset(15);
        make.centerY.equalTo(self.btnView.mas_centerY);
        make.right.equalTo(self.secondBtn.mas_left).offset(-25);
        make.height.equalTo(@80);
        make.width.mas_equalTo(self.secondBtn);
    }];
    [self.secondBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.firstBtn.mas_right).offset(25);
        make.right.equalTo(self.threeBtn.mas_left).offset(-25);
        make.centerY.equalTo(self.btnView.mas_centerY);
        make.height.equalTo(@80);
        make.width.mas_equalTo(self.threeBtn);
    }];
    [self.threeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.secondBtn.mas_right).offset(25);
        make.right.equalTo(self.fourBtn.mas_left).offset(-25);
        make.centerY.equalTo(self.btnView.mas_centerY);
        make.height.equalTo(@80);
        make.width.mas_equalTo(self.fourBtn);
    }];
    [self.fourBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.threeBtn.mas_right).offset(25);
        make.right.equalTo(self.btnView.mas_right).offset(-15);
        make.centerY.equalTo(self.btnView.mas_centerY);
        make.height.equalTo(@80);
        make.width.mas_equalTo(self.firstBtn);
    }];
}

- (void)iconAction:(JXButton *)button{
    switch (button.tag) {
        case 0:
        {
            if ([self.delegate respondsToSelector:@selector(iconPushVC:)]) {
                [self.delegate iconPushVC:ShenDuJiePan];
            }
        }
            break;
        case 1:
        {
            if ([self.delegate respondsToSelector:@selector(iconPushVC:)]) {
                [self.delegate iconPushVC:NiuRenZaiXian];
            }
        }
            break;
        case 2:
        {
            if ([self.delegate respondsToSelector:@selector(iconPushVC:)]) {
                [self.delegate iconPushVC:CaoPanJingLing];
            }
        }
            break;
        case 3:
        {
            if ([self.webViewDelegate respondsToSelector:@selector(pushWKWebView:)]) {
                [self.webViewDelegate pushWKWebView:self.iconURL.lastObject];
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index{
    CNLog(@"---点击了第%ld张图片", (long)index);
    if ([self.webViewDelegate respondsToSelector:@selector(pushWKWebView:)]) {
        [self.webViewDelegate pushWKWebView:self.bannerURL[index]];
    }
}


- (NSMutableArray *)bannerTitle {
    if (!_bannerTitle) {
        _bannerTitle = [NSMutableArray array];
    }
    return _bannerTitle;
}

- (NSMutableArray *)bannerImg {
    if (!_bannerImg) {
        _bannerImg = [NSMutableArray array];
    }
    return _bannerImg;
}

- (NSMutableArray *)bannerURL {
    if (!_bannerURL) {
        _bannerURL = [NSMutableArray array];
    }
    return _bannerURL;
}

- (NSMutableArray *)iconTitle {
    if (!_iconTitle) {
        _iconTitle = [NSMutableArray array];
    }
    return _iconTitle;
}

- (NSMutableArray *)iconImg {
    if (!_iconImg) {
        _iconImg = [NSMutableArray array];
    }
    return _iconImg;
}

- (NSMutableArray *)iconURL {
    if (!_iconURL) {
        _iconURL = [NSMutableArray array];
    }
    return _iconURL;
}

@end
