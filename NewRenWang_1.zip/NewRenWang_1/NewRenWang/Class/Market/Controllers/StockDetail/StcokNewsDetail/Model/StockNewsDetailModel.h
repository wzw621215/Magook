//
//  StockNewsDetailModel.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseModel.h"

@interface StockNewsDetailModel : BaseModel

@property (nonatomic,assign)NSInteger newsId;
@property (nonatomic,copy)NSString * newsTitle;
@property (nonatomic,copy)NSString * edit;
@property (nonatomic,copy)NSString * time;
@property (nonatomic,copy)NSString * content;
@property (nonatomic,copy)NSString * source;
@property (nonatomic,assign)NSInteger pvnumber;

@end
