//
//  StockNewsDetailModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "StockNewsDetailModel.h"

@implementation StockNewsDetailModel

@end
