//
//  StockNewsDetailVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface StockNewsDetailVC : BaseViewController

@property (nonatomic, copy)NSString *stockCode;
@property (nonatomic, copy)NSString *stockName;

- (instancetype)initWithCategory:(NSInteger)categoryid withNewid:(NSInteger)newid;

@end
