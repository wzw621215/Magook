//
//  StockNewsDetailVC.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "StockNewsDetailVC.h"
#import "NewsDetailRequest.h"
#import "StockNewsDetailModel.h"

@interface StockNewsDetailVC ()
@property (weak, nonatomic) IBOutlet UILabel *newsTitle;
@property (weak, nonatomic) IBOutlet UILabel *edit;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UITextView *content;
@property (weak, nonatomic) IBOutlet UILabel *pvnumber;

/** 新闻栏目id*/
@property (nonatomic, assign)NSInteger categoryid;
/** 新闻id*/
@property (nonatomic, assign)NSInteger newid;

@property (nonatomic,strong)StockNewsDetailModel *model;

@end

@implementation StockNewsDetailVC

- (instancetype)initWithCategory:(NSInteger)categoryid withNewid:(NSInteger)newid {
    self = [super init];
    if (self) {
        _categoryid = categoryid;
        _newid = newid;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = [NSString stringWithFormat:@"%@ %@",self.stockName,self.stockCode];
    [self requestData];
    [self showLoadingAnimation];
}

- (void)requestData {
    NewsDetailRequest *request = [[NewsDetailRequest alloc] initWithCategoryid:self.categoryid newid:self.newid];
    [request sendRequestWithCompletion:^(id response, BOOL success, NSString *message) {
        if (success) {
            StockNewsDetailModel *model = [[StockNewsDetailModel alloc] mj_setKeyValues:response];
            _model = model;
            [self setupUI];
        }
        [self hideLoadingAnimation];
    }];
}

- (void)setupUI {
    self.newsTitle.text = self.model.newsTitle;
    self.edit.text = [NSString stringWithFormat:@"编辑:%@",self.model.edit];
    self.time.text = self.model.time;
    self.pvnumber.text =  [NSString stringWithFormat:@"%ld",(long)self.model.pvnumber];
    self.content.attributedText = [self getStringFromHTML5String:self.model.content];
}

- (NSAttributedString *)getStringFromHTML5String:(NSString *)htmlString {
    NSMutableAttributedString *htmlStr = [[NSMutableAttributedString alloc] initWithData:[htmlString dataUsingEncoding:NSUnicodeStringEncoding]
                                                                                 options:@{
                                                                                           NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType,
                                                                                           NSCharacterEncodingDocumentAttribute:
                                                                                               [NSNumber numberWithInt:NSUTF8StringEncoding],
                                                                                           }
                                                                      documentAttributes:nil error:nil];
    
    [htmlStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Arial" size:13.0] range:NSMakeRange(0, htmlStr.length)];
    [htmlStr addAttribute:NSForegroundColorAttributeName value:kRGBColor(125, 125, 125) range:NSMakeRange(0, htmlStr.length)];
    
    return htmlStr;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
