//
//  ExpNoDataCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/8.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "ExpNoDataCell.h"

@implementation ExpNoDataCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
