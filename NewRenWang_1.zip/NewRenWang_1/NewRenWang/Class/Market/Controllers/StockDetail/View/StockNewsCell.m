//
//  StockNewsCell.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "StockNewsCell.h"
#import "DertView.h"

@interface StockNewsCell ()

@property (weak, nonatomic) IBOutlet UILabel *time;

@property (weak, nonatomic) IBOutlet UILabel *newsTitle;

@end

@implementation StockNewsCell

- (void)setModel:(StockNewsModel *)model {
    _model = model;
    self.time.text = model.time;
    self.newsTitle.text = model.newsTitle;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    DertView *line = [[DertView alloc] init];
    line.frame = CGRectMake(10, self.contentView.height-0.5, self.contentView.width-20, 0.5);
    line.backgroundColor =[UIColor clearColor];
    [self addSubview:line];
}

@end
