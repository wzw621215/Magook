//
//  FSFiveViewController.h
//  YunZhangCaiJing
//
//  @Author: JopYin on 16/3/31.
//  Copyright © 2016年 JopYin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuoteModel.h"

@interface FSFiveViewController : UIViewController

- (void)updateUIWithData:(QuoteModel *)model;


@end
