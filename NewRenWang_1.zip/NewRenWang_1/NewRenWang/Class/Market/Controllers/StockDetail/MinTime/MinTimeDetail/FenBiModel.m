//
//  FenBiModel.m
//  NewRenWang
//
//  Created by JopYin on 2017/2/7.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "FenBiModel.h"

@implementation FenBiModel

@end
