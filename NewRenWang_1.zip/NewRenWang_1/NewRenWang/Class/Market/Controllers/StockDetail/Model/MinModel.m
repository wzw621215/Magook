//
//  MinModel.m
//  GuShang
//
//  Created by JopYin on 2016/11/29.
//  Copyright © 2016年 尹争荣. All rights reserved.
//  这个model用于接收处理分时接口的请求数据

#import "MinModel.h"

@implementation MinModel

@end
