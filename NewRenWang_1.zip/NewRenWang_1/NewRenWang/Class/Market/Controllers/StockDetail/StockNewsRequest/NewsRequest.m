//
//  NewsRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NewsRequest.h"
@interface NewsRequest()
/**  股票 */
@property (nonatomic, copy) NSString * stockCode;
/**  第几页，默认从1开始 */
@property (nonatomic, assign) NSInteger pageIndex;

@end

@implementation NewsRequest

- (instancetype)initWithStockCode:(NSString *)stockCode
                      pageIndex:(NSInteger)index {
    if (self == [super init]) {
        _stockCode = stockCode;
        _pageIndex = index;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"stockCode":_stockCode,
             @"pageSize":@"10",
             @"pageIndex":@(_pageIndex)
             };
}

- (NSString *) url {
    return kStockNewsAPI;
}
@end
