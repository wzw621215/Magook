//
//  NewsDetailRequest.m
//  NewRenWang
//
//  Created by JopYin on 2017/3/6.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "NewsDetailRequest.h"
@interface NewsDetailRequest()

@property (nonatomic, assign) NSInteger categoryid;

@property (nonatomic, assign) NSInteger newid;

@end


@implementation NewsDetailRequest

- (instancetype)initWithCategoryid:(NSInteger )categoryid
                        newid:(NSInteger)newid {
    if (self == [super init]) {
        _categoryid = categoryid;
        _newid = newid;
    }
    return self;
}

- (NSDictionary *)params {
    return @{
             @"categoryid":@(_categoryid),
             @"newid":@(_newid)
             };
}

- (NSString *) url {
    return kStockNewsDetailAPI;
}

@end
