//
//  StockDetailVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/1/20.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface StockDetailVC : BaseViewController

- (id)initWithStockCode:(NSString *)stockCode withStockName:(NSString *)stockName;

@end
