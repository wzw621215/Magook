//
//  StockCell.h
//  NewRenWang
//
//  Created by JopYin on 2017/1/11.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuoteModel.h"

@interface StockCell : UITableViewCell

@property (nonatomic,strong)QuoteModel *model;

@end
