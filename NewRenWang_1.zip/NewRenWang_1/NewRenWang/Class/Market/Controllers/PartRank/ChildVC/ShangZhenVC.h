//
//  ShangZhenVC.h
//  NewRenWang
//
//  Created by JopYin on 2017/1/17.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface ShangZhenVC : BaseViewController

@property (assign,nonatomic) NSInteger stockType;

@property (nonatomic, copy)NSString * orderType;

@end
