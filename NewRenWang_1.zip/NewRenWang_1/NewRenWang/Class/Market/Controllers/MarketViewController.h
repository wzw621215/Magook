//
//  MarketViewController.h
//  NewRenWang
//
//  Created by JopYin on 2017/1/10.
//  Copyright © 2017年 尹争荣. All rights reserved.
//

#import "BaseViewController.h"

@interface MarketViewController : BaseViewController

@end
