//
//  MainTabBarConroller.m
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MainTabBarConroller.h"
#import "MGShelfViewController.h"
#import "MGLibViewController.h"
#import "ShoppingCartViewController.h"
#import "UserSettingsViewController.h"
#import "MGNavigationConroller.h"
#import "ShoppingCartDataManager.h"
#import "MGIssueModel.h"
#import "ShoppingCartHandle.h"
#import "MGShelfHandle.h"
#import "ScanResultViewController.h"

@interface MainTabBarConroller ()
{
    NSMutableArray *_mainViewControllers;
}
@end

@implementation MainTabBarConroller

- (void)viewDidLoad {
    [super viewDidLoad];
    self.selectedIndex                              = 0;
    _mainViewControllers=[NSMutableArray new];
    OBSERVER(TranstoMGLibNotification, @selector(transToMGlib));
    OBSERVER(ShoppingCartDidChangeNotification,@selector(shoppingCartDidChange));
    OBSERVER(LoginSuccessNotification, @selector(LoginSuccess));
    OBSERVER(ScanFinishNotification, @selector(scanFinish:));
    OBSERVER(LogOutNotification, @selector(refeshRoleStatus));
    OBSERVER(FinishPayNotification, @selector(refeshRoleStatus));
    [self createViewControllers];
    self.view.backgroundColor                       = BKCOLOR;
}
-(void)refeshRoleStatus{

    [MGShelfHandle getPurchasedDataComplete:^(NSArray *array) {
        
    }];
}
#pragma mark -登录成功后从服务器获取一次购物车信息
-(void)LoginSuccess{
    //从服务器获取购物车信息;
    [self refeshRoleStatus];
    
    if([UserModel sharedUser].usertoken){
        //获取购物车
        NSLog(@"登录成功从服务器刷新购物车");
        [ShoppingCartHandle getShoppingCartDataFromServerSuccess:^(NSArray *dataArray) {
            NSLog(@"购物车需要刷新%ld条数据",dataArray.count);
            if(dataArray.count){
            POSTER(ShoppingCartDidChangeNotification, nil);
            }
        }];
    }
}
-(void)scanFinish:(NSNotification *)note{

    MGIssueModel *model =(MGIssueModel *)note.object;

    NSMutableArray *array =[NSMutableArray arrayWithArray:_mainViewControllers];

    ScanResultViewController *vc =[ScanResultViewController new];

    vc.tabBarItem.image                             = [UIImage imageNamed:@"hometab_singletype_icon"];
    vc.tabBarItem.selectedImage                     = [[UIImage imageNamed:@"hometab_singletype_icon_hover"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    //稍微调小图片
    vc.tabBarItem.imageInsets                       = UIEdgeInsetsMake(1, 1, 1, 1);
    //设置文字颜色
    NSMutableDictionary *textAttrs                  = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName]       = RGB(123, 123, 123, 1);
    NSMutableDictionary *selectTextAttrs            = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = COLOR;

    [vc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [vc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];

    vc.model                                        = model;
    vc.title                                        = model.magazinename;

    MGNavigationConroller *nav =[[MGNavigationConroller alloc]initWithRootViewController:vc];
    [array insertObject:nav atIndex:0];
    self.viewControllers                            = array;

}

#pragma mark - 购物车变化方法
-(void)shoppingCartDidChange{

    NSString *badgeValue =[NSString stringWithFormat:@"%ld",[[[ShoppingCartDataManager sharedManager] allData] count]];
    badgeValue=[badgeValue isEqualToString:@"0"]?nil:badgeValue;
    ShoppingCartViewController*vc                   = self.viewControllers[self.viewControllers.count-2];
    vc.tabBarItem.badgeValue                        = badgeValue;

}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)transToMGlib{

    self.selectedIndex                              = self.viewControllers.count-3;
}
-(void)createViewControllers{

    MGShelfViewController      *shelf  =[MGShelfViewController new];
    MGLibViewController        *lib    =[MGLibViewController new];

    ShoppingCartViewController *shop   =[ShoppingCartViewController new];
    UserSettingsViewController *user   =[UserSettingsViewController new];

    //购物车创建就更新购物车
    NSString *badgeValue =[NSString stringWithFormat:@"%ld",[[[ShoppingCartDataManager sharedManager] allData] count]];

    [[NSNotificationCenter defaultCenter]addObserver:shop selector:@selector(shoppingCartDidChange) name:ShoppingCartDidChangeNotification object:nil];

    badgeValue=[badgeValue isEqualToString:@"0"]?nil:badgeValue;


    shop.tabBarItem.badgeValue                      = badgeValue;

    [self addChildVc:shelf title:@"杂志架" image:@"杂志架" selectedImage:@"杂志架_checked"];
    [self addChildVc:lib   title:@"杂志库" image:@"杂志库" selectedImage:@"杂志库_checked"];
    [self addChildVc:shop  title:@"购物车" image:@"购物车" selectedImage:@"购物车_checked"];
    [self addChildVc:user  title:@"我的"   image:@"我的"   selectedImage:@"我的_checked"];

}
//封装添加
- (void)addChildVc:(UIViewController *)childVc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    // 设置子控制器的文字
    childVc.title                                   = title;
    // 设置子控制器的图片
    childVc.tabBarItem.image                        = [UIImage imageNamed:image];
    childVc.tabBarItem.selectedImage                = [[UIImage imageNamed:selectedImage]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

    // 设置文字的样式
    NSMutableDictionary *textAttrs                  = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName]       = RGB(123, 123, 123, 1);
    NSMutableDictionary *selectTextAttrs            = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = COLOR;
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];

    MGNavigationConroller *nav                      = [[MGNavigationConroller alloc] initWithRootViewController:childVc];

    [self addChildViewController:nav];
    [_mainViewControllers addObject:nav];
}


#pragma mark -横竖屏配置
-(BOOL)shouldAutorotate{
    NSInteger selectedIndex                         = self.selectedIndex>5?0:self.selectedIndex;

    MGNavigationConroller *nv                       = self.viewControllers[selectedIndex];

    return [nv.viewControllers.lastObject shouldAutorotate];
}
//支持的方向
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    NSInteger selectedIndex                         = self.selectedIndex>5?0:self.selectedIndex;

    MGNavigationConroller *nv                       = self.viewControllers[selectedIndex];

    return [nv.viewControllers.lastObject supportedInterfaceOrientations];
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return [self.viewControllers.lastObject preferredInterfaceOrientationForPresentation];
}

@end
