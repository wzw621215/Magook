//
//  UserModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "UserModel.h"
#import "ShoppingCartDataManager.h"
#import "DownloadDataManager.h"
#import "RecentReadingDataManager.h"
#import "ApnsManager.h"
#import "ShoppingCartHandle.h"
@implementation UserModel

static id user = nil;
+(void)removeUser{
//    [ZBHud showActivityWithMessage:@"正在登出"];
    [ShoppingCartHandle sendShoppingCartDataToServer];
    user=nil;
    //重新分组
    [ApnsManager divideUserIntoGroups:user];
    //清空购物车，已下载，最近阅读和已购买
    [[ShoppingCartDataManager sharedManager]removeData];
//    [[DownloadDataManager sharedManager]removeData];
    [[RecentReadingDataManager sharedManager]removeData];
    POSTER(ShoppingCartDidChangeNotification, nil);
    POSTER(LogOutNotification, nil);

}
+(instancetype)sharedUser{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
        if (!user) {
            user = [[self alloc]init];
        }
//    });

    return user;
}
+ (id)allocWithZone:(struct _NSZone *)zone
{
    //此处不能唯一，可能多个用户切换
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
        if (!user) {
            user = [super allocWithZone:zone];
        }

//    });
    return user;
}
+(instancetype)loginWithDic:(NSDictionary *)dic{

   return  [[self alloc]initWithDic:dic];

}
-(instancetype)initWithDic:(NSDictionary *)dic{
    
    if (self=[super init]) {
        _status = dic[@"status"];
        _usertoken=dic[@"usertoken"];

        [self setValuesForKeysWithDictionary:dic[@"data"]];
    }
    //分组
    [ApnsManager divideUserIntoGroups:user];
    
    return self;
}
-(NSString *)userHash{
    if (INREVIEW&&self.usertoken==nil) {
        return [AppController sharedController].userHashInReview;
    }

    return [self.username hashString];
}
-(NSNumber *)userid{

    if (INREVIEW&&self.usertoken==nil) {
        return [AppController sharedController].useridInReview;
    }
    if (_userid==nil) {
        _userid=@0;
    }

    return _userid;
}

-(NSNumber *)sex{
    if (_sex==nil) {
        _sex=@0;
    }
    return _sex;
}
-(NSString *)description{
    return [NSString stringWithFormat:@"%@----%@---%@",self.username,self.usertoken,self.userid,self.userHash];
}
@end
