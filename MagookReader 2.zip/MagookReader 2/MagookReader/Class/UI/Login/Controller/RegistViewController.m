//
//  RegistViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "RegistViewController.h"
#import "RegistInputView.h"
#import "NSAttributedString+ZBAttibutedSting.h"
#import "LoginHadle.h"
#import "CustomServiceViewController.h"
@interface RegistViewController ()
{
    UIView* _backView;
    RegistInputView *_inputView;
    UIScrollView *_sc;
}
@end

@implementation RegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(RegistSuccessNotification, @selector(back));

    [self createScrollView];
    [self configNav];
    [self createInputView];
    //服务协议lab
    [self createServiceLab];
    //注册按钮
    [self createRegistButton];
    //已有账号，去登录
    [self createLoginLab];


    // Do any additional setup after loading the view.
}
-(void)createScrollView{
    _sc=[[UIScrollView alloc]init];
//    _sc.frame=[UIScreen mainScreen].bounds;
//    _sc.contentSize=CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT);
    self.view=_sc;
    _sc.userInteractionEnabled=YES;
    UITapGestureRecognizer *tap =[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
    [_sc addGestureRecognizer:tap];
    [_sc setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]]];
    [self willRotateToInterfaceOrientation:self.interfaceOrientation duration:0];
}
-(void)tap{
    [_sc endEditing:YES];
}

-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {
        _sc.frame=CGRectMake(0, 0, MINSCREEN, MAXSCREEN-NAV_HEIGHT);
        _sc.contentSize=CGSizeMake(MINSCREEN, MAXSCREEN-NAV_HEIGHT);
    }else{
        _sc.frame=CGRectMake(0, 0, MAXSCREEN, MINSCREEN-NAV_HEIGHT);
        _sc.contentSize=CGSizeMake(MAXSCREEN, MAXSCREEN-NAV_HEIGHT);
    }
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)createLoginLab{

    WPHotspotLabel*lab=[[WPHotspotLabel alloc]initWithFrame:CGRectMake(_backView.x, CGRectGetMaxY(_backView.frame)+120, _backView.width, 20)];
    lab.textAlignment =NSTextAlignmentCenter;

    lab.attributedText = [NSAttributedString stringWithText:@"已有账号?去登录"
                                           attributedString:@"登录" fontSize:14.0f color:COLOR block:^{

        NSLog(@"点击登录");
        [self dismissViewControllerAnimated:YES completion:^{

        }];
    }];
    [self.view addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(_backView.mas_bottom).with.offset(100);
        make.height.mas_equalTo(20);
        make.width.equalTo(self.view);
    }];
    
}

-(void)createRegistButton{
    UIButton *button =[UIButton buttonWithType:UIButtonTypeCustom];
    button.frame =CGRectMake(_backView.x, CGRectGetMaxY(_backView.frame)+60, _backView.width, 44);

    [button setTitle:@"注册" forState:UIControlStateNormal];

    [button cutCornerRadius:5];

    [button setBackgroundColor:COLOR];

    [button addTarget:self action:@selector(regist) forControlEvents:UIControlEventTouchUpInside];

    
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_backView.mas_bottom).with.offset(40);
        make.size.mas_equalTo(CGSizeMake(280, 44));
        make.centerX.equalTo(self.view);
    }];

}
-(void)regist{

    [LoginHadle registWithUserName:_inputView.userNameTF.text verifyCode:_inputView.verifyCodeTF.text passWord:_inputView.passWordTF.text];
    [self.view endEditing:YES];
}
-(void)createServiceLab{

    WPHotspotLabel*lab=[[WPHotspotLabel alloc]initWithFrame:CGRectMake(_backView.x, CGRectGetMaxY(_backView.frame)+20, _backView.width, 20)];
    lab.textAlignment =NSTextAlignmentCenter;

    lab.attributedText = [NSAttributedString stringWithText:@"点击注册，表示同意《麦格用户服务协议》" attributedString:@"《麦格用户服务协议》" fontSize:14.0f color:COLOR block:^{


        CustomServiceViewController*vc= [[CustomServiceViewController alloc]init];

        [self.navigationController pushViewController:vc animated:YES];
    }];
    [_sc addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(_backView.mas_bottom).with.offset(Margin);
        make.height.mas_equalTo(20);
        make.width.equalTo(self.view);
    }];

}
-(void)createInputView{

    _backView =[[UIView alloc]initWithFrame:CGRectMake(20, 100, SCREEN_WIDTH-40, 200)];
    _backView.backgroundColor =RGB(255, 255, 255, 0.5);

    _backView.layer.cornerRadius =10;
    _backView.layer.masksToBounds=YES;
    _inputView = LOADNIBNAME(@"RegistInputView");
    _inputView.type=VerifyCodeTypeRegister;
    _inputView.frame =CGRectMake(10, 0, _backView.width-20, 200);
    [_backView addSubview:_inputView];
    

    [self.view addSubview:_backView];
    [_backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view).with.offset(Margin);
        make.size.mas_equalTo(CGSizeMake(280, 200));
    }];

}
-(void)configNav{
    
    self.title =@"注册";

    self.navigationController.navigationBar.barTintColor =COLOR;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    UIBarButtonItem *left = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"back" highImage:@"back_highlight"];
    self.navigationItem.leftBarButtonItem=left;

}
-(void)back{

    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

@end
