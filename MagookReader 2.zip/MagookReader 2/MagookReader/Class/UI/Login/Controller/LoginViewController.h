//
//  LoginViewController.h
//  MagookReader
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
