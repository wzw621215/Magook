//
//  LoginViewController.m
//  MagookReader
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LoginViewController.h"

#import "LoginView.h"
#import "LoginInputView.h"
#import "MainTabBarConroller.h"
#import "FogetPassWordViewController.h"
#import "RegistViewController.h"

@interface LoginViewController ()<UIScrollViewDelegate>
{
    UIView *_line;

    UIImageView *_logoImageV;
    
    LoginView *loginView;

}
@end

@implementation LoginViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.navigationController) {
        self.navigationController.navigationBarHidden=YES;
    }
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];

    if (self.navigationController) {
        self.navigationController.navigationBarHidden=NO;
    }
}
- (void)viewDidLoad {

    [super viewDidLoad];


    //添加消息观察者
    [self beComeObserver];
    //创建LOGO

    [self createLogo];

    [self createGuestLogin];

    //创建输入框
    loginView = [[LoginView alloc]init];
    

    [self.view addSubview:loginView];
    [loginView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.centerY.equalTo(self.view);

        make.size.mas_equalTo(CGSizeMake(LoginInputW, LoginInputH));
    }];

    [self willRotateToInterfaceOrientation:self.interfaceOrientation duration:0];

}
-(void)createGuestLogin{

    UIButton *guestLoginButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    guestLoginButton.frame=CGRectMake(SCREEN_WIDTH-100-20, SCREEN_HEIGHT-20-20, 100, 20);
    [guestLoginButton setTitle:@"游客登录" forState:UIControlStateNormal];
    [guestLoginButton setTitleColor:COLOR forState:UIControlStateNormal];
    guestLoginButton.titleLabel.font = [UIFont systemFontOfSize:18.0f];
    [guestLoginButton addTarget:self action:@selector(guestLogin) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:guestLoginButton];
    [guestLoginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).with.offset(-20);
        make.bottom.equalTo(self.view).with.offset(-20);
        make.size.mas_equalTo(CGSizeMake(100, 50));
    }];
}
-(void)guestLogin{
    NSLog(@"游客登录");
    
    [UserModel loginWithDic:@{@"userid":@0}];

    [self login];
}
#pragma 登录成功执行方法
-(void)login{
    NSLog(@"登录成功");

    if (self.navigationController) {
        
        [self.navigationController popViewControllerAnimated:YES];
    }else{
    MainTabBarConroller *main = [MainTabBarConroller new];

    UIWindow *window=[[UIApplication sharedApplication]keyWindow];

    window.rootViewController=main;
    }
}
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {

        _logoImageV.hidden=NO;
        
    }else{

        if (!iPad) {
        _logoImageV.hidden=YES;
        }
    }

}
#pragma mark -忘记密码
-(void)forgetPassWord{

    FogetPassWordViewController *vc =[FogetPassWordViewController new];

    if (self.navigationController) {
        [self.navigationController pushViewController:vc animated:YES];
    }else{
    UINavigationController *nv =[[UINavigationController alloc]initWithRootViewController:vc];

    [self presentViewController:nv animated:YES completion:^{

    }];
    }

}

#pragma mark - 注册新用户
-(void)registUser{



    RegistViewController *vc =[RegistViewController new];

    UINavigationController *nv =[[UINavigationController alloc]initWithRootViewController:vc];

    [self presentViewController:nv animated:YES completion:^{
        
    }];

}
#pragma mark -添加消息观察者
-(void)beComeObserver{

    OBSERVER(LoginSuccessNotification, @selector(login));
    OBSERVER(ForgetPassWordNotification, @selector(forgetPassWord));
    OBSERVER(RegistUserNotification, @selector(registUser));
    OBSERVER(UIKeyboardWillShowNotification, @selector(showKeyboard:));
    OBSERVER(UIKeyboardWillHideNotification, @selector(hiddenKeyboard:));

}
#pragma mark -移除观察者
-(void)dealloc{
    NSLog(@"销毁登录界面");
    REMOVEOBSERVER;
}
-(void)showKeyboard:(NSNotification *)notice
{
    NSDictionary* dic=notice.userInfo;
    //键盘的frame
    CGRect keyBoardRect= [dic[@"UIKeyboardFrameEndUserInfoKey"] CGRectValue];
    CGFloat keyBoardY = keyBoardRect.origin.y;
    
    CGFloat inputY=self.view.center.y+LoginInputH/2.0;

    if (keyBoardY<inputY) {
//        NSTimeInterval  duration=[dic[UIKeyboardAnimationDurationUserInfoKey]doubleValue];
//            UIWindow *window = [UIApplication sharedApplication].keyWindow;
//            window.y=keyBoardY-inputY-5;
            [loginView mas_updateConstraints:^(MASConstraintMaker *make) {

                make.centerY.equalTo(self.view).with.offset(keyBoardY-inputY);

            }];
        [_logoImageV mas_updateConstraints:^(MASConstraintMaker *make) {
           make.top.equalTo(self.view).with.offset(logoY+keyBoardY-inputY-5);
        }];
    }
}
-(void)hiddenKeyboard:(NSNotification *)notice
{
//    NSDictionary* dic=notice.userInfo;
//    UIWindow *window = [UIApplication sharedApplication].keyWindow;

//    if (window.y!=0) {

//        NSTimeInterval duration=[dic[UIKeyboardAnimationDurationUserInfoKey]doubleValue];
    
//        [UIView animateWithDuration:duration animations:^{
//            UIWindow *window = [UIApplication sharedApplication].keyWindow;
//            window.y=0;
            [loginView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(self.view);
            }];
    
            [_logoImageV mas_updateConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.view).with.offset(logoY);
            }];

//        }];
    
        
//    }

}

//点击空白收回键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
#pragma mark -创建LOGO

-(void)createLogo{

    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg"]];

    _logoImageV=[[UIImageView alloc]init];

//    _logoImageV.frame = CGRectMake(284*WRAT, 113*HRAT, 182*WRAT, 188*HRAT);

    _logoImageV.image = [UIImage imageNamed:@"麦格logo"];
    
    [self.view addSubview:_logoImageV];
    [_logoImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(logoY);
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(LogoW, LogoH));
    }];

}


@end
