//
//  RegistInputView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginHadle.h"
@interface RegistInputView : UIView
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *verifyCodeTF;
@property (weak, nonatomic) IBOutlet UITextField *passWordTF;
@property (nonatomic ,assign) VerifyCodeType type;
@end
