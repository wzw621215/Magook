//
//  LoginInputView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/6.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LoginInputView.h"


#import "KeyChainManager.h"
@interface LoginInputView()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *passWordTF;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *verifyButton;

@property (weak, nonatomic) IBOutlet UIButton *forgetButton;
@property (weak, nonatomic) IBOutlet UILabel *lab;
@property (weak, nonatomic) IBOutlet UIButton *registerButton;

@end
@implementation LoginInputView

-(void)awakeFromNib{
    UIImageView *user = [[UIImageView alloc]init];
    user.width=30;
    user.height=20;
    user.image = [UIImage imageNamed:@"name"];
    user.contentMode=UIViewContentModeScaleAspectFit;
    self.userNameTF.leftView=user;
    self.userNameTF.leftViewMode = UITextFieldViewModeAlways;

    UIImageView *passWord = [[UIImageView alloc]init];
    passWord.width=30;
    passWord.height=20;
    passWord.image = [UIImage imageNamed:@"password"];
    passWord.contentMode=UIViewContentModeScaleAspectFit;

    self.passWordTF.leftView=passWord;

    self.passWordTF.leftViewMode = UITextFieldViewModeAlways;


    [self.loginButton cutCornerRadius:5];

    [self.verifyButton cutCornerRadius:3];


    self.userNameTF.delegate =self;
    self.passWordTF.delegate =self;
    



}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    [self endEditing:YES];

    return YES;
}
//判断是验证码输入还是密码输入，对应不同的界面
-(void)drawRect:(CGRect)rect{

    if (self.isVerify == YES) {
        //快捷登录

        [self.forgetButton removeFromSuperview];
        [self.lab removeFromSuperview];
        [self.registerButton removeFromSuperview];

        self.userNameTF.keyboardType = UIKeyboardTypeNumberPad;
        self.passWordTF.keyboardType = UIKeyboardTypeNumberPad;

        self.forgetButton=nil;
        self.lab=nil;
        self.registerButton=nil;

    }else{
        //密码登录

        [self.verifyButton removeFromSuperview];

        [self.loginButton setTitle:@"登录" forState:UIControlStateNormal];

        self.passWordTF.placeholder = @"请输入密码";
        self.passWordTF.secureTextEntry=YES;

        self.verifyButton=nil;
    }

}

#pragma  mark -发送验证码按钮点击事件
- (IBAction)verifyButtonClick:(UIButton *)sender {

    [LoginHadle sendVerifyCodeToTelNumber:self.userNameTF.text verifyCodeType:VerifyCodeTypeLogin  target:sender];

}
#pragma  mark - 登录按钮点击事件
- (IBAction)loginButtonClick:(UIButton *)sender {

    [self endEditing:YES];


    if (self.isVerify) {
        //验证码登录

        if ([self.passWordTF.text isAllNumber]&&self.passWordTF.text.length == 6) {


            
            [LoginHadle loginWithUserName:self.userNameTF.text passWord:self.passWordTF.text isVerify:YES];
//            [LoginHadle loginWithUserName:self.userNameTF.text passWord:self.passWordTF.text isVerify:YES Success:^(BOOL isSuccess) {
//
//            }];


        }else{
            //错误，弹出警告

            [ZBHud showInfo:@"请输入正确的验证码"];
            
        }

    }else{
        //密码登录

        if ((self.userNameTF.text.length==0||self.userNameTF.text==nil)||(self.passWordTF.text.length==0||self.passWordTF.text==nil)) {
          //错误，弹出警告
            [ZBHud showErrorWithMessage:@"请输入正确的用户名和密码"];
        }else{
            //发送登录请求

//            [LoginHadle loginWithUserName:self.userNameTF.text passWord:self.passWordTF.text isVerify:NO Success:^(BOOL isSuccess) {
//                [KeyChainManager saveUserName:self.userNameTF.text passWord:self.passWordTF.text];
//            }];

//            
            BOOL success=[LoginHadle loginWithUserName:self.userNameTF.text passWord:self.passWordTF.text isVerify:NO];

            if (success) {
                [KeyChainManager saveUserName:self.userNameTF.text passWord:self.passWordTF.text];
            }
        }

    }


}

#pragma mark - 忘记密码
- (IBAction)forgetPassWord:(UIButton *)sender {
    [self endEditing:YES];

    POSTER(ForgetPassWordNotification, nil);
}
#pragma mark - 注册
- (IBAction)registerButtonClick:(UIButton *)sender {
    [self endEditing:YES];
    POSTER(RegistUserNotification, nil);

}
//收起键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];

}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end
