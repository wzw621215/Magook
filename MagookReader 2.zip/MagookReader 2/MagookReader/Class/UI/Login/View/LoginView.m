//
//  LoginView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LoginView.h"
#import "LoginInputView.h"
@interface LoginView()<UIScrollViewDelegate>
{
    UIView *_line;

    UIScrollView *_sC;

}
@end
@implementation LoginView
-(instancetype)initWithFrame:(CGRect)frame{


    if (self= [super initWithFrame:frame]) {
        [self createLoginView];
    }
    return self;
}
-(void)createLoginView{

    //背景图

    self.backgroundColor=RGB(255.0, 255.0, 255, 0.5);

    [self cutCornerRadius:15];


    //灰色的分割线
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 52, LoginInputW, 0.5)];
    lineView.backgroundColor = [UIColor lightGrayColor];

    [self addSubview:lineView];

    //两个按钮及绿色线条

    [self creatButtons];

    [self createInputView];


}
//封装创建按钮的方法
-(void)creatButtons{

    NSArray *titleArray =@[@"快捷登录",@"密码登录"];
    CGFloat btnWith = (LoginInputW-40)/2;

    CGFloat btnHeight = 50.0;
    for (int i=0; i<2; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];

        button.frame = CGRectMake(20+btnWith*i, 0, btnWith, btnHeight);

        button.tag = 101+i;

        [button setTitle:titleArray[i] forState:UIControlStateNormal];

        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

        [button setTitleColor:COLOR forState:UIControlStateSelected];

        button.titleLabel.font = [UIFont systemFontOfSize:18.0f];

        if (button.tag == 101) {

            button.selected = YES;
        }
        [button addTarget:self action:@selector(topButtonClick:) forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:button];
    }


    //绿色的线条
    _line = [[UIView alloc]init];
    _line.frame=CGRectMake(20, 50, btnWith, 4);
    _line.backgroundColor=COLOR;
    [self addSubview:_line];


}
-(void)topButtonClick:(UIButton *)btn{

    [self endEditing:YES];


    for (int i= 0; i <2; i++) {
        UIButton *button  = (UIButton *)[self viewWithTag:101+i];

        if (btn.tag == 101+i) {
            button.selected=YES;

            [UIView animateWithDuration:0.3 animations:^{
                _sC.contentOffset = CGPointMake(_sC.width*i, 0);
            }];

        }else{
            button.selected=NO;
        }
    }

    [UIView animateWithDuration:0.3 animations:^{

        _line.x = btn.x;
    }];

}

-(void)createInputView{

    _sC = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 50, LoginInputW, LoginInputH-50)];
    _sC.contentSize   = CGSizeMake(LoginInputW*2, LoginInputH-50);
    _sC.pagingEnabled = YES;
    _sC.showsHorizontalScrollIndicator = NO;
    _sC.delegate = self;

    [self addSubview:_sC];

    //验证码登录
    LoginInputView *verifyView = LOADNIBNAME(@"LoginInputView");
    verifyView.frame = CGRectMake(0, 0, _sC.width, _sC.height);
    verifyView.isVerify =YES;
    [_sC addSubview:verifyView];


    //密码登录
    
    LoginInputView *passWordView = LOADNIBNAME(@"LoginInputView");

    passWordView.isVerify = NO;

    passWordView.frame = CGRectMake(_sC.width, 0, _sC.width, _sC.height);

    [_sC addSubview:passWordView];



}
//点击空白收回键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    _line.x = 20+_sC.contentOffset.x/_sC.width*(_sC.width-40)/2;
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger index = _sC.contentOffset.x/_sC.width;
    
    for (int i =0; i<2; i++) {
        UIButton *button = (UIButton *)[self viewWithTag:101+i];
        if (index == i) {
            button.selected=YES;
        }else{
            button.selected=NO;
        }
        
    }
    
}


@end
