//
//  LoginHadle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "LoginHadle.h"
//#import "HashManager.h"
#import "UIButton+VerifyCode.h"
#import "KeyChainManager.h"
#import "SVProgressHUD.h"
#import "ApnsManager.h"
@implementation LoginHadle
#pragma  mark - 登出
+(void)logoutWithSuccess:(void (^)(BOOL))successBlock{
//    url=”{idsServer}/logout/logout”

    NSString *url       = [NSString stringWithFormat:@"%@logout/logout",IDSSERVER];
//    {
//        "userid":int,//用户id
//        "usertoken":string,
//        "userhash":string
//        "orgid":string,// 参考常用定义中的orgid,
//        "device":{ device }
//    }
    NSDictionary *param =@{
                         @"userid":[UserModel sharedUser].userid,
                         @"usertoken":INREVIEW?@"inReview":[UserModel sharedUser].usertoken,
//                         @"userhash":[HashManager hashWithName:[UserModel sharedUser].phonenum hashKey:ORGID],
                         @"userhash":[UserModel sharedUser].userHash,
                         @"orgid":ORGID,
                         @"device":DEVICE,
                         };


    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {


    NSString *string    = [NSString stringWithFormat:@"%@",[responseObject objectForKey:@"status"]];
        if ([string isEqualToString:@"1"]) {

            [ZBHud showSuccessWithMessage:@"登出成功"];
            NSLog(@"登出成功");

            [UserModel removeUser];

            successBlock(YES);
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {

        NSLog(@"退出失败----%@",error);
    }];


}
+(void)resetUserInfo{

//    url=”{idsServer}/register/userinfo”

    NSString *url =[NSString stringWithFormat:@"%@register/userinfo",IDSSERVER];

    UserModel *user =[UserModel sharedUser];
    NSDictionary *infoDic =@{
                          @"userid":user.userid,
                          @"userhash":user.userHash,
                          @"username":user.username,
                          @"phonenum":user.phonenum,
                          @"nickname":user.nick,
                          @"sex":user.sex,
                          @"email":user.email,
                          @"age":user.age,
                          };
    NSDictionary *param =@{
                           @"userinfo":infoDic,
                           @"device":DEVICE
                           };
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"%@",responseObject);
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {

    }];

}

//+(void)sendVerifyCodeToTelNumber:(NSString *)telNum target:(UIButton *)button{
+(void)sendVerifyCodeToTelNumber:(NSString *)telNum verifyCodeType:(VerifyCodeType)verifyCodeType target:(UIButton *)button{
    NSString *reason=nil;
    switch (verifyCodeType) {
        case VerifyCodeTypeLogin:
             reason=@"login";
            break;
        case VerifyCodeTypeRegister:
            reason=@"register";
            break;
        case VerifyCodeTypeReset:
            reason=@"reset";
            break;
        case VerifyCodeTypeBundle:
            reason=@"bundle";
            break;
            
        default:
            
            break;
    }
    

    if ([telNum isAllNumber]&&telNum.length==11) {
        //输入正确
        //倒计时
        [button autoCount:30];

        //发送验证码

            NSDictionary *param =@{
                                   @"phonenum":telNum,
                                   @"userhash":[telNum hashString],
                                   @"reason":reason,
                                   @"device":DEVICE
                                   };


        NSLog(@"%@",[param JSONString]);
        [LogManager logWithViewID:@2 action:@"sendsms_reg"];

        NSString *url    = [NSString stringWithFormat:@"%@register/verifycode",IDSSERVER];
        NSLog(@"%@",url);

        [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {

            
        NSString *string = [NSString stringWithFormat:@"%@",[responseObject objectForKey:@"status"]];
                NSLog(@"%@",[responseObject JSONString]);
                if (![string isEqualToString:@"1"]) {
                    //错误，弹出警告
                    [ZBHud showInfo:responseObject[@"message"]];
                }else{
                    //发送成功
                    [ZBHud showSuccessWithMessage:@"验证码发送成功"];
                }
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [ZBHud showInfo:@"请检查网络设置"];
            }];

    }else{
        //错误，弹出警告
        [ZBHud showInfo: @"请输入正确的手机号"];


    }

}


#pragma mark - 登录
//+(BOOL)loginWithUserName:(NSString *)userName passWord:(NSString *)passWord isVerify:(BOOL)isVerify Success:(void (^)(BOOL isSuccess))successBlock{
+(BOOL)loginWithUserName:(NSString *)userName passWord:(NSString *)passWord isVerify:(BOOL)isVerify{
    NSLog(@"%@---%@",userName,passWord);
    NSString *url =[NSString stringWithFormat:@"%@login/mobile",IDSSERVER];

    [ZBHud showActivityWithMessage:@"登录中"];

    NSDictionary *param =@{
                           @"username"  :userName,
                           @"userhash"  :[userName hashString],
                           @"password"  :isVerify?@"":passWord,
                           @"verifycode":isVerify?[[NSString stringWithFormat:@"Magook%@",passWord] md5String]:@"",
                           @"device"    :DEVICE
                           };

    NSLog(@"%@",url);
    NSLog(@"%@",[param JSONString]);

    NSData *postData=[param JSONData];

    NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    request.timeoutInterval=TimeOutInterval;
    [request setValue:@"POST" forKey:@"HTTPMethod"];
    [request setHTTPBody: postData];

    NSData *data=[NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
//    [ZBHud dismiss];
//    [SVProgressHUD dismiss];
    id responseObject=[data objectFromJSONData];
    
    NSLog(@"登录-----%@",[responseObject JSONString]);
    if (responseObject==nil) {
        [ZBHud showErrorWithMessage:@"连接服务器失败\n请重新登录"];
        [LogManager logWithViewID:@2 action:@"login_failure"];
        return NO;
    }
    NSString *string    = [NSString stringWithFormat:@"%@",[responseObject objectForKey:@"status"]];
        if (![string isEqualToString:@"1"]) {
            //错误，弹出警告
            [ZBHud showInfo:responseObject[@"message"]];
            [LogManager logWithViewID:@2 action:@"login_failure"];
            return NO;
        }else{
            [ZBHud showSuccessWithMessage:@"登录成功"];
            [UserModel loginWithDic:responseObject];
            [self getRoleData];
            NSLog(@"LoginSuccessNotification");
            POSTER(LoginSuccessNotification, nil);
            [LogManager logWithViewID:@2 action:@"login_success"];

            return YES;

        }

}
#pragma mark -重置密码
+(void)resetWithUserName:(NSString *)userName verifyCode:(NSString *)verifyCode newPassWord:(NSString *)newPassWord{


    [LogManager logWithViewID:@124 action:@"forgotpwd"];
    if ([userName isAllNumber]&&userName.length==11) {


        if (verifyCode==nil||verifyCode.length==0) {
            //用户名为空

            [ZBHud showInfo:@"请输入正确的验证码"];
        }else{
            //密码为空
            if (newPassWord==nil||newPassWord.length==0) {

                [ZBHud showErrorWithMessage:@"请输入正确的密码"];

            }else{
    NSString *url       = [NSString stringWithFormat:@"%@register/password",IDSSERVER];

                
            NSDictionary *param =@{
                                   @"reason":@"reset",//修改原因, 取值"reset","change"

                                   @"phonenum":userName,//手机号

                                   @"userhash":[userName hashString],//用户hash值

                                   @"oldpassword":@"",//原密码 , 如果reason="reset", 服务器忽略此项

                                   @"password":newPassWord,//新密码

                                   @"verifycode":[[NSString stringWithFormat:@"Magook%@",verifyCode] md5String],//散列后的验证码, 如果reason="change", 服务器忽略此项;算法: MD5({VerifyCodePrefix}+用户验证码),{VerifyCodePrefix}="Magook";

                                   @"device":DEVICE

                                   };

            [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
                 NSLog(@"重置密码------%@",[responseObject JSONString]);

                if ([responseObject[@"status"] isEqual:@1]) {

                    [ZBHud showSuccessWithMessage:@"密码修改成功！"];
                    [LogManager logWithViewID:@124 action:@"modifypwd"];
                    NSLog(@"=====重置密码成功===========");
                    POSTER(ResetPassWordSuccessNotification, nil);
//                    MGLog(@"修改密码成功");
                }else{
                    [ZBHud showErrorWithMessage:responseObject[@"message"]];
                }

            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {

                [ZBHud showErrorWithMessage:@"重置密码失败"];
            }];
        }
     }
    }else{
        //手机号输入错误

        [ZBHud showInfo:@"请输入正确的手机号"];

    }
}
#pragma  mark - 注册
+(void)registWithUserName:(NSString *)userName verifyCode:(NSString *)verifyCode passWord:(NSString *)passWord{

    NSLog(@"注册--%@---%@",userName,passWord);
    
    NSString *url =[NSString stringWithFormat:@"%@register/mobile",IDSSERVER];


    
    NSDictionary *param = @{
                            @"phonenum":userName,//手机号
                            @"userhash":[userName hashString],//用户hash值 inReview?[UserModel sharedUser].userHash:
//                            @"userid":inReview?[UserModel sharedUser].userid:@0,
                            @"password":passWord,//密码,当新注册时是必须的参数, 当绑定手机号时,该参数无意义,不传
                            @"verifycode":[[NSString stringWithFormat:@"Magook%@",verifyCode] md5String],//散列验证码,算法: MD5({VerifyCodePrefix}+用户验证码),{VerifyCodePrefix}="Magook";
                            @"device":DEVICE
                            };

    NSLog(@"注册（绑定）----------------%@",url);
    NSLog(@"注册（绑定）----------------%@",[param JSONString]);
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {

        NSLog(@"注册（绑定）----------------%@",[responseObject JSONString]);
        if ([responseObject[@"status"] isEqualToNumber:@1]) {
            NSLog(@"%@",[responseObject JSONString]);
            [ZBHud showSuccessWithMessage:@"注册成功!"];
            [LogManager logWithViewID:@2 action:@"regdone"];
            POSTER(RegistSuccessNotification, nil);
        }else{
            [ZBHud showInfo:@"注册失败"];
        }


    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"注册失败");
    }];
}
#pragma mark -服务条款
+(NSURLRequest *)customServiveRequest{

    NSString *url =[NSString stringWithFormat:@"%@html/useragreement/index.html",URLSERVER];


    return [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
}
+(void)getRoleData{
    NSLog(@"获取角色信息");
    UserModel *user =[UserModel sharedUser];
    
    NSString *url=[NSString stringWithFormat:@"%@user/role",IDSSERVER];
    if (user.usertoken==nil) {
        NSLog(@"用户未登录，不刷新数据");

        return;
    }
    
    NSDictionary *param =@{
                           @"userid":user.userid,
                           @"userhash":user.userHash,
                           @"usertoken":INREVIEW?@"":user.usertoken,
                           @"device":DEVICE
                           };
//    NSLog(@"获取角色信息----------%@",[param JSONString]);
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"-------------获取角色信息成功--------------%@",responseObject);
        if (responseObject==nil) {
            NSLog(@"获取角色信息失败");
            return ;
        }

        if ([responseObject[@"iswholelib"] isEqualToNumber:@1]) {
            
            NSLog(@"获取角色信息---全库VIP");

            user.iswholelib=@1;
            user.wholelibexpiredate=responseObject[@"wholelibexpiredate"];

        }else{
            NSLog(@"获取角色信息---非全库Vip");
            
            user.iswholelib=@0;
        }
//       [UserModel sharedUser].roleDataArray=responseObject[@"data"];
        
        [ApnsManager divideUserIntoGroups:user];
    }failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"---------获取角色信息失败--------");
        [ZBHud showErrorWithMessage:@"获取账号信息失败"];
    }];

}

@end
