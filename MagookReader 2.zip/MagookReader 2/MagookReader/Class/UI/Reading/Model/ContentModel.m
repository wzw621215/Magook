//
//  ContentModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ContentModel.h"

@implementation ContentModel
-(NSMutableArray *)detailArray{
    if (!_detailArray) {
        _detailArray=[NSMutableArray new];
    }
    return _detailArray;
}
@end
