//
//  ContentViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/21.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MGIssueModel;
@interface ContentViewController : UITableViewController
@property (nonatomic, strong) MGIssueModel *model;
@property (nonatomic, copy)void (^block)(NSInteger );
@end
