//
//  ReadingViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/16.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ReadingViewController.h"
#import "ReadingCollectionViewController.h"
#import "PageView.h"
#import "MGIssueModel.h"
#import "ContentViewController.h"
#import "BeforeViewController.h"
//#import "ShoppingCartViewController.h"
//#import "BasicShoppingCartViewController.h"
#import "ReadingShoppingCartViewController.h"
#import "ShoppingCartDataManager.h"
#import "ShareManager.h"
#import "UMSocial.h"
#import "MGProgressButton.h"
#import "UINavigationController+JZExtension.h"
#import "DownloadManager.h"
#import "DownloadDataManager.h"
#import "OMGToast.h"
#import "UIBarButtonItem+Badge.h"
#import "RecentReadingDataManager.h"
#import "ReadingHadle.h"
@interface ReadingViewController ()<UMSocialUIDelegate,UIActionSheetDelegate>
{
    UIToolbar *_toolBar;
}
@property (nonatomic ,assign) NSInteger currentPage;
@property (strong, nonatomic) ReadingCollectionViewController *collectionVC;
@property (weak, nonatomic) UIButton *shopCar;

@property (weak, nonatomic)MGProgressButton *downloadButon;
@property (nonatomic, assign) CGFloat localProgress;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) UserPermissionStyle permission;

@end

@implementation ReadingViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    self.navigationController.navigationBar.barTintColor=[UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:COLOR}];

    if ([[DownloadDataManager sharedManager]isExistsDataWithModel:self.model]) {
        NSLog(@"下载数据库存在该杂志");
        self.model.downloadedNumber=[[DownloadDataManager sharedManager]upDateModelWithModel:self.model];

    }else{
//        NSLog(@"该杂志没有在下载");
    }

    _toolBar.hidden=self.navigationController.navigationBarHidden;
    [self updateDownloadProgress];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];

    self.navigationController.navigationBar.barTintColor = COLOR;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
}
#pragma mark - 分享回调
-(void)didSelectSocialPlatform:(NSString *)platformName withSocialData:(UMSocialData *)socialData
{
    [LogManager logWithViewID:self.viewID action:@"read_share_channel" info:platformName];
    KEEP(ENABLEBONUS);
    NSInteger platformID;

    if ([platformName isEqualToString:UMShareToWechatTimeline]) {
        platformID=0;
    }else if([platformName isEqualToString:UMShareToQQ]||[platformName isEqualToString:UMShareToQzone]){
        platformID=2;
    }
    else if([platformName isEqualToString:UMShareToSina]){
        platformID=1;
    }
    else if([platformName isEqualToString:UMShareToWechatSession]){
        platformID=0;
    }
    NSLog(@"platformID=====%ld",platformID);
    //    url/?type=1&uid=xxx&platform=xx&urlid=guid(64)&magazineid=xx&articeid=xx
    NSString *url = [NSString stringWithFormat:@"%@?type=1&uid=%@&platform=%ld&urlid=%@&magazineid=%@articeid=%@",SHARESERVER,[UserModel sharedUser].userid,platformID,[[NSString stringWithFormat:@"%@",[NSDate date]] md5String],self.model.magazineid,self.model.issueid];
    NSLog(@"finishurl===%@",url);
    //完成分享任务

        [ShareManager finishShareTaskWithUrl:url];

}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self becomeObserver];
    self.currentPage                                     = 1;

    self.permission=[AppController checkPermissionWithMagazineID:self.model.magazineid];

    [self createCollectionView];

    [self configNav];

    [self createToolBar];
    //记录最近阅读
    RecentReadingDataManager *manager =[RecentReadingDataManager sharedManager];
    if (![manager isExistsDataWithModel:self.model]) {
        [manager insertDataWithModel:self.model];
    }

}
-(void)becomeObserver{

    OBSERVER(UpdateDownloadProgressNotification, @selector(updateDownloadProgress));
    OBSERVER(SingleTapHandleNotification, @selector(showBars));
    OBSERVER(ShoppingCartDidChangeNotification,@selector(shoppingCartDidChange));

}

-(void)shoppingCartDidChange{

    self.shopCar.selected=[[ShoppingCartDataManager sharedManager]isExistsDataWithModel:self.model];
    self.navigationItem.rightBarButtonItem.badgeValue=[NSString stringWithFormat:@"%ld",[[ShoppingCartDataManager sharedManager]allData].count];
}
-(void)dealloc{
    NSLog(@"销毁阅读界面");
    REMOVEOBSERVER;
}
-(void)showBars{

    self.navigationController.navigationBarHidden        = !self.navigationController.navigationBarHidden;
    _toolBar.hidden                                      = !_toolBar.hidden;
}
#pragma  mark -创建collectionView
-(void)createCollectionView{

    self.collectionVC                                    = [[ReadingCollectionViewController alloc]init];

    self.collectionVC.model                              = self.model;
    __weak typeof(self) weakSelf                         = self;
    self.collectionVC.addToShoppingCartBlock             = ^(){

    weakSelf.shopCar.selected                            = YES;
        if (![[ShoppingCartDataManager sharedManager]isExistsDataWithModel:weakSelf.model]) {
            [[ShoppingCartDataManager sharedManager]insertDataWithModel:weakSelf.model];
            POSTER(ShoppingCartDidChangeNotification, nil);
        }
        [weakSelf goToShoppingCart];
    };
    self.collectionVC.pageBlock=^(NSInteger page){
    weakSelf.currentPage                                 = page;
    };

    [self.view addSubview:self.collectionVC.view];
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsZero);
    }];

}

-(void)createToolBar{

    _toolBar =[[UIToolbar alloc]init];

    _toolBar.alpha=0.9;

    UIBarButtonItem *previous =[UIBarButtonItem itemWithTitle:@"往期" selectedTitle:nil target:self action:@selector(previous) image:@"往期" selectedImage:nil];


    UIBarButtonItem *content =[UIBarButtonItem itemWithTitle:@"目录" selectedTitle:nil target:self action:@selector(content) image:@"目录" selectedImage:nil];

    UIBarButtonItem *shoppingCart =[UIBarButtonItem itemWithTitle:@"加入购物车" selectedTitle:@"移出购物车" target:self action:@selector(shoppingCart:) image:@"加入购物车" selectedImage:@"购物车_checked"];

    //取到里面的button
    self.shopCar=(UIButton *)shoppingCart.customView;

    //根据数据库来判断是否选中
    self.shopCar.selected=[[ShoppingCartDataManager sharedManager]isExistsDataWithModel:self.model];

    UIBarButtonItem *share =[UIBarButtonItem itemWithTitle:@"分享" selectedTitle:nil target:self action:@selector(share) image:@"分享" selectedImage:nil];

    UIBarButtonItem *download =[UIBarButtonItem downloadItemWithTarget:self action:@selector(download:)];
    self.downloadButon                                   = download.customView;

    UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];


    _toolBar.items=@[space,previous,space,content,space,shoppingCart,space,share,space,download,space];

    [self.view addSubview:_toolBar];

    [_toolBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.height.mas_equalTo(TAB_HEIGHT);
    }];
    [LogManager logWithViewID:self.viewID action:@"read_open" info:[NSString stringWithFormat:@"%@;%@;%ld",self.model.magazineid,self.model.issueid,[AppController sharedController].netWorkStatus]];

}
-(void)previous{
    NSLog(@"往期");

    UIViewController *root                               = self.navigationController.viewControllers[0];

    //如果是扫描增加的页面，就pop到往期
    if ([root isKindOfClass:NSClassFromString(@"ScanResultViewController")]) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }else{
        //否则push到往期
    BeforeViewController *vc                             = [BeforeViewController new];
    vc.model                                             = self.model;
    vc.title=[NSString stringWithFormat:@"%@%@",self.model.magazinename,self.model.issuename];
    //往期回调
    vc.block=^(MGIssueModel *model){
    self.model                                           = model;
    self.collectionVC.model                              = self.model;
    self.collectionVC.page                               = -[self.model.start integerValue]+1;
    self.currentPage = 1;
    };
    [self.navigationController pushViewController:vc animated:YES];
    }
}
-(void)content{
    ContentViewController *vc =[ContentViewController new];
    vc.model                                             = self.model;
    vc.title=[NSString stringWithFormat:@"%@%@",self.model.magazinename,self.model.issuename];
    __weak typeof(self) weakSelf = self;
    vc.block=^(NSInteger page){
        UserPermissionStyle stye =[AppController checkPermissionWithMagazineID:self.model.magazineid];
        if (stye==UserPermissionStylePurchased) {
            weakSelf.collectionVC.page                               = page;
            weakSelf.currentPage = page+[weakSelf.model.start integerValue];
        }
        NSLog(@"currentPage=============>%ld",weakSelf.currentPage);
    };
    [LogManager logWithViewID:self.viewID action:@"read_menuclick" info:[NSString stringWithFormat:@"%@;%@;%ld",self.model.magazineid,self.model.issueid,self.currentPage+1]];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)shoppingCart:(UIButton *)button{

    NSLog(@"购物车");
    UserPermissionStyle permission=[AppController checkPermissionWithMagazineID:self.model.magazineid];
    if (permission==UserPermissionStylePurchased) {
        [OMGToast showWithText:@"您已获得该杂志阅读权限\n无需再次购买" bottomOffset:60 duration:3];
        return;
    }
    button.selected=!button.selected;
    if (button.selected) {
        if (![[ShoppingCartDataManager sharedManager]isExistsDataWithModel:self.model]) {
            [OMGToast showWithText:@"添加到购物车成功" bottomOffset:60 duration:1];
            [LogManager logWithViewID:self.viewID action:@"read_addfavor" info:[NSString stringWithFormat:@"%@;%@",self.model.magazineid,self.model.issueid]];
            [[ShoppingCartDataManager sharedManager]insertDataWithModel:self.model];
        }
    }else{
        [LogManager logWithViewID:self.viewID action:@"favor_del"];
        [[ShoppingCartDataManager sharedManager]deleteDataWithModel:self.model];
    }
    POSTER(ShoppingCartDidChangeNotification, nil);

}
#pragma  mark - 分享
-(void)share{
    NSLog(@"阅读页分享--currentPage-->%ld",self.currentPage);

    [ShareManager shareOnAllPlatformsWithModel:self.model currentPage:self.currentPage delegate:self];

}
#pragma mark - 下载
-(void)download:(MGProgressButton *)sender{

    __weak typeof(self) weakSelf=self;
    if (self.permission==UserPermissionStylePurchased) {
        NSLog(@"有下载权限");
        self.downloadButon.isDownloading=[[DownloadManager sharedManager]isDownloadingWithModel:self.model];

        if(self.model.sd_operation){
            //暂停
            [OMGToast showWithText:@"暂停下载" bottomOffset:60];
            [[DownloadManager sharedManager] pauseWithModel:self.model];
            [self updateDownloadProgress];
        }
        else{
            //正在下载
            if (self.model.downloadedNumber>0) {
                //继续下载
                [OMGToast showWithText:@"继续下载" bottomOffset:60];
                [LogManager logWithViewID:self.viewID action:@"read_download_resume" info:[NSString stringWithFormat:@"%@;%@;%ld",self.model.magazineid,self.model.issueid,[AppController sharedController].netWorkStatus]];
            }else{
                //开始下载
                [OMGToast showWithText:@"开始下载" bottomOffset:60];
                [LogManager logWithViewID:self.viewID action:@"read_download_start" info:[NSString stringWithFormat:@"%@;%@;%ld",weakSelf.model.magazineid,weakSelf.model.issueid,[AppController sharedController].netWorkStatus]];
            }
            
            [[DownloadManager sharedManager]downloadWithModel:self.model progress:^(CGFloat progress,MGIssueModel *model) {
                NSLog(@"%@---progress------->%f",model.magazinename,progress);
                if (progress==1) {
                    NSLog(@"%@%@下载完毕",model.magazinename,model.issuename);
                    [[DownloadManager sharedManager]cleanDataWithModel:model];
                    [ZBHud showSuccessWithMessage:[NSString stringWithFormat:@"%@\n下载完毕!",model.magazinename]];
                }
            }];
        }
    }else{
        NSLog(@"无下载权限");
        [OMGToast showWithText:@"本期刊需要付费后才可下载\n请先付费购买" bottomOffset:60 duration:3];
    }
}
-(void)updateDownloadProgress{
    CGFloat progress;
    if ([[DownloadDataManager sharedManager]isExistsDataWithModel:self.model]) {
        progress=(float)self.model.downloadedNumber/[self.model.count integerValue];
    }else{
    self.model.downloadedNumber                          = 0;
    progress                                             = 0;
    }
    self.downloadButon.isDownloading=[[DownloadManager sharedManager].dataDic objectForKey:[NSString stringWithFormat:@"%@",self.model.issueid]]==nil?NO:YES;
    self.downloadButon.progress                          = progress;
}

#pragma mark -设置导航栏
-(void)configNav{
    self.title                                           = [NSString stringWithFormat:@"%@%@",self.model.magazinename,self.model.issuename];
    self.navigationController.navigationBarBackgroundAlpha=0.9;
    UIBarButtonItem *back                                = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"back_阅读页" highImage:@"back_highlight"];
    self.navigationItem.leftBarButtonItem                = back;

    UIBarButtonItem *right                               = [UIBarButtonItem itemWithTarget:self action:@selector(goToShoppingCart) image:@"购物车_reading" highImage:@"购物车_reading_high"];

    self.navigationItem.rightBarButtonItem               = right;

    right.badgeValue=[NSString stringWithFormat:@"%ld",[[ShoppingCartDataManager sharedManager]allData].count];

}
-(void)goToShoppingCart{
    NSLog(@"进入购物车");
    ReadingShoppingCartViewController *vc =[ReadingShoppingCartViewController new];

    [self.navigationController pushViewController:vc animated:YES];

}
-(void)back{

    [_toolBar removeFromSuperview];
    _toolBar                                             = nil;
    
    [self.navigationController popViewControllerAnimated:YES];

}
-(BOOL)shouldAutorotate{

    return DOUBLEPAGE;
}

@end
