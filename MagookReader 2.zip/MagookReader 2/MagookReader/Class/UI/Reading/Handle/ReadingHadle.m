//
//  ReadingHadle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ReadingHadle.h"
#import "MGIssueModel.h"
#import "HashManager.h"
#import "ContentModel.h"
#import "DetailModel.h"
#import "HashManager.h"

@interface ReadingHadle()


@end
@implementation ReadingHadle
+(NSString *)getSmallUrlAtPage:(NSInteger )page WithModel:(MGIssueModel *)model{

//url=”{pageServer}/{path}/{magazineid}/{magazineid}-{issueid}/pic{n}_{key}.mg”

    NSString *pageStr = [NSString stringWithFormat:@"%ld",page];

    NSString *pageHash =[pageStr pageHashWithMagazineID:model.magazineid issueID:model.issueid];

    NSString *url =[NSString stringWithFormat:@"%@%@/%@/%@-%@/%@_small.mg",PAGESERVER,model.path,model.magazineid,model.magazineid,model.issueid,pageHash];


    return url;
}
+(NSString *)getBigUrlAtPage:(NSInteger )page WithModel:(MGIssueModel *)model{

    //url=”{pageServer}/{path}/{magazineid}/{magazineid}-{issueid}/pic{n}_{key}.mg”

    NSString *pageStr = [NSString stringWithFormat:@"%ld",page];

    NSString *pageHash =[pageStr pageHashWithMagazineID:model.magazineid issueID:model.issueid];

    NSString *url =[NSString stringWithFormat:@"%@%@/%@/%@-%@/%@_big.mg",PAGESERVER,model.path,model.magazineid,model.magazineid,model.issueid,pageHash];

   
    return url;
}
//获取目录数据源
+(void)getContentDataWithModel:(MGIssueModel *)model complete:(complete)complete{
        NSFileManager *manager= [NSFileManager defaultManager];
        NSString *filePath=[DOCUMENTSPATH stringByAppendingPathComponent:[NSString stringWithFormat:@"Download/%@_%@/content.plist",model.magazinename,model.issuename]];
        if ([manager fileExistsAtPath:filePath]) {
            NSLog(@"存在下载目录");

        NSDictionary *root=[NSDictionary dictionaryWithContentsOfFile:filePath];


        complete(root);

    }else{
        //网络加载目录
        NSLog(@"网络加载目录");
        NSString *url =[NSString stringWithFormat:@"%@magazine/magazine_%@/catalog/catalog_%@.txt",BUSSINESCACHESSERVER,model.magazineid,model.issueid];

        [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {

            if (data==nil) {
                [ZBHud showErrorWithMessage:@"连接服务器失败"];
                return ;
            }
            NSDictionary *root=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];

            complete(root);

        }];
    }

}
//目录数据处理
+(void)dataHandleWithDic:(NSDictionary *)root finished:(complete)finished{

    //数据处理
    NSMutableArray *dataArray=[NSMutableArray new];
    NSArray *array=root[@"data"];
    for (int i=0; i<[array count]; ) {

        ContentModel *model = [ContentModel new];
        if ([[array[i] objectForKey:@"level"] isEqualToNumber:@0]) {
            model.title=array[i][@"title"];

            i++;
        }
        while (i<[array count]) {

            DetailModel *m=[DetailModel new];
            if ([[array[i] objectForKey:@"level"] isEqualToNumber:@1]) {
                [m setValuesForKeysWithDictionary:array[i]];
                [model.detailArray addObject:m];

                //对每组数据内部进行排序
                [model.detailArray sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                    DetailModel *m1=obj1;
                    DetailModel *m2=obj2;
                    NSNumber *page1=m1.page;
                    NSNumber *page2=m2.page;
                    return [page1 compare:page2];

                }];
                
                i++;
                
            }else{
                
                break;
            }
        }
        
        [dataArray addObject:model];


    }
    [dataArray sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        ContentModel *model1=obj1;
        ContentModel *modle2=obj2;
        DetailModel *m1=model1.detailArray[0];
        DetailModel *m2=modle2.detailArray[0];
        NSNumber *page1=m1.page;
        NSNumber *page2=m2.page;
        return [page1 compare:page2];
            }];
    finished(dataArray);

}
+(void)caculatePageWithPage:(NSInteger)page model:(MGIssueModel *)model inRootDic:(NSDictionary *)root finish:(finish)finish{

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        
    NSInteger startPage = 1;
    NSInteger endPage = [model.count integerValue];

        NSArray *array=root[@"data"];
        NSMutableArray *sort =[NSMutableArray arrayWithArray:[array filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"SELF.level !=0"]]];
        [sort sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
            return [obj1[@"page"] compare:obj2[@"page"]];
        }];
        
        NSArray *pageArray = [sort valueForKey:@"page"];

        if (page<=[model.start integerValue]) {
            startPage=endPage=page;
        }else{
            for (NSNumber *num in pageArray) {
                if (page-[model.start integerValue]<[num integerValue]) {
                    endPage=[num integerValue]-1+[model.start integerValue];
                    break;
                }
                else{
                    startPage=[num integerValue]+[model.start integerValue];
                }
            }
        }

        NSPredicate *contentPagePre = [NSPredicate predicateWithFormat:@"SELF.page ==%ld",startPage-[model.start integerValue]];
        NSArray *filteredArray =[sort filteredArrayUsingPredicate:contentPagePre];
        NSLog(@"分享页===%ld====起始页---->%ld===终止页--->%ld---->标题--->%@",page,startPage,endPage,[[filteredArray valueForKey:@"title"] JSONString]);
        
        NSMutableString *string=[NSMutableString new];
        
        [string appendString:[HashManager hashNameMagazineId:model.magazineid issueId:model.issueid pageIndex:[NSString stringWithFormat:@"%ld",startPage]]];
        if (endPage>startPage) {
            for (int i=startPage+1; i<=endPage; i++) {
                [string appendString:[NSString stringWithFormat:@",%@",[HashManager hashNameMagazineId:model.magazineid issueId:model.issueid pageIndex:[NSString stringWithFormat:@"%ld",i] ]]];
            }
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            
            finish(string,[filteredArray valueForKey:@"title"]);
        });
    });

}
+(void)getPageHashWithModel:(MGIssueModel *)model currentPage:(NSInteger)page finish:(finish)finish{
 
    [self getContentDataWithModel:model complete:^(id obj) {
        NSDictionary *root=obj;
        [self caculatePageWithPage:page model:model inRootDic:root finish:^(NSString *pageHashN,NSArray *titleArray) {
            finish(pageHashN,titleArray);
        }];
    }];
}
@end
