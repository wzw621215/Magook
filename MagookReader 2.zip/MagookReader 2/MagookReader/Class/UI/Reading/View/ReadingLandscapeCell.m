//
//  ReadingLandscapeCell.m
//  MagookReader
//
//  Created by zhoubin on 15/11/8.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ReadingLandscapeCell.h"
#import "ZBActivity.h"
#import "MGIssueModel.h"
#import "ReadingHadle.h"
#import "UIButton+WebCache.h"
#import "UIImage+WebP.h"

#import "UIImageView+Extension.h"
#import "DXAlertView.h"
@interface ReadingLandscapeCell()

@property (weak, nonatomic) IBOutlet UIImageView *leftImageV;
@property (weak, nonatomic) IBOutlet UIImageView *rightImageV;
@property (nonatomic ,weak) MGIssueModel *model;
@end
@implementation ReadingLandscapeCell
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self=[super initWithCoder:aDecoder]) {
        self.backgroundColor=[UIColor clearColor];

        UISwipeGestureRecognizer *left =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(leftSwipe)];
        left.direction=UISwipeGestureRecognizerDirectionLeft;
        [self addGestureRecognizer:left];
        UISwipeGestureRecognizer *right =[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(rightSwipe)];
        right.direction=UISwipeGestureRecognizerDirectionRight;
        [self addGestureRecognizer:right];

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap)];
        [self addGestureRecognizer:tap];
        
        self.userInteractionEnabled=YES;
    }
    return self;
}

-(void)tap{
    NSLog(@"点击");
    POSTER(SingleTapHandleNotification, nil);
}
-(void)rightSwipe{
    NSLog(@"从左往右划");
}
-(void)leftSwipe{
    NSLog(@"从右向左划");
    NSLog(@"self.model===%@",self.model);
//    UserPermissionStyle style = [AppController checkPermissionWithMagazineID:self.model.magazineid];
//    if (style==UserPermissionStyleDoNotPurchased) {
//        DXAlertView *alert = [[DXAlertView alloc] initWithTitle:@"温馨提示" contentText:@"购买30元包年套餐即可享受\n多设备云阅读\n精彩往期杂志随意看\n下载到本地随意看" leftButtonTitle:@"取消" rightButtonTitle:@"加入购物车"];
//        
//        [alert show];
//        
//        alert.leftBlock = ^() {
//            NSLog(@"取消");
//        };
//        alert.rightBlock = ^() {
//            NSLog(@"确定");
//            //回调
//            if (self.addToShoppingCartBlock) {
//                self.addToShoppingCartBlock();
//            }
//        };
//        alert.dismissBlock = ^() {
//            NSLog(@"关闭");
//        };
//    }
}
-(void)configCellWithModel:(MGIssueModel *)model index:(NSInteger)index{
    self.model=model;
//    if ([model.start integerValue]<=0) {
//        model.start=@1;
//    }
    [self configImageV:self.leftImageV WithCurrentPage:2*index model:model];
    [self configImageV:self.rightImageV WithCurrentPage:2*index+1 model:model];
}
-(void)configImageV:(UIImageView *)imgV WithCurrentPage:(NSInteger)page model:(MGIssueModel *)model{
    
    if (page<model.downloadedNumber) {
        //读取缓存
        NSLog(@"读取缓存图片");
        NSString *filePath=[DOCUMENTSPATH stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@_%@/%@.png",DownloadDirectoryName,model.magazinename,model.issuename,[NSNumber numberWithInteger:page+1]]];
        
        [imgV setImage:[UIImage imageNamed:@"封面"]];
        [imgV setImage:[UIImage imageWithContentsOfFile:filePath]];
        
    }else{
        //网络加载
        NSLog(@"网络加载图片");
        NSString *smUrl=[ReadingHadle getSmallUrlAtPage:page+1 WithModel:model];
        
        NSString *bigUrl=[ReadingHadle getBigUrlAtPage:page +1 WithModel:model];
        
        [ZBActivity showActivityInView:self.contentView];
        
        
        [imgV loadImageWithSmallImage:smUrl bigImage:bigUrl progress:^(NSInteger receivedSize, NSInteger expectedSize) {//大图片进度
            
        } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            
            [ZBActivity dismiss];
            
        }];
        
    }
}
//-(void)imageWithFile:(NSString *)filePath complete:(void (^)(UIImage *image))complete{
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//        
////        UIImage *image=[UIImage sd_imageWithWebPData:[NSData dataWithContentsOfMappedFile:filePath]];
//        UIImage *image=[UIImage sd_imageWithWebPData:[NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:nil]];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            //通知主线程刷新回调
//            if (image) {
//                complete(image);
//            }
//        });
//        
//    });
//    
//}


@end
