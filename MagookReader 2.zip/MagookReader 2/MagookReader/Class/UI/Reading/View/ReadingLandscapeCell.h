//
//  ReadingLandscapeCell.h
//  MagookReader
//
//  Created by zhoubin on 15/11/8.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface ReadingLandscapeCell : UICollectionViewCell
@property (nonatomic, copy)  void (^addToShoppingCartBlock)();
-(void)configCellWithModel:(MGIssueModel *)model index:(NSInteger)index;
@end
