//
//  ReadingCollectionViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicCollectionViewController.h"
@class MGIssueModel;
@interface ReadingCollectionViewController : BasicCollectionViewController
@property (nonatomic, strong) MGIssueModel *model;
//当前显示的页码
@property (nonatomic, assign) NSInteger page;
@property (nonatomic, copy)  void (^addToShoppingCartBlock)();
@property (nonatomic ,copy) void (^pageBlock)(NSInteger page);
@end
