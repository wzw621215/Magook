//
//  LeftViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicCollectionViewController.h"
//#import "BasicViewController.h"
@interface LeftViewController : BasicCollectionViewController
@property (nonatomic, strong) NSMutableArray *dataArray;
@end
