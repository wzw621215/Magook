//
//  BasicBeforeViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
@class MGIssueModel;
@interface BasicBeforeViewController : BasicViewController
@property (nonatomic ,strong) MGIssueModel *model;

@end
