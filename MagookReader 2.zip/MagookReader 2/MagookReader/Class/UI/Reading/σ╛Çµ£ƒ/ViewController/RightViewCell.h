//
//  RightViewCell.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lab;

@end
