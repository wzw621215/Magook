////
////  BeforeViewController.m
////  MagookReader
////
////  Created by tailhuang on 15/9/20.
////  Copyright (c) 2015年 Zhoubin. All rights reserved.
////
//
#import "BeforeViewController.h"
#import "BasicBeforeViewController.h"

@interface BeforeViewController ()

@property (nonatomic, strong) BasicBeforeViewController  *basicVC;
@end
//
@implementation BeforeViewController
//
- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(GoToReadingFromBeforeNotification, @selector(goToReading:));

    self.view.backgroundColor =[UIColor whiteColor];
    
    self.basicVC = [BasicBeforeViewController new];

    self.basicVC.view.frame=CGRectMake(0, NAV_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-NAV_HEIGHT);

    self.basicVC.model=self.model;

    [self.view addSubview:self.basicVC.view];
    [self.basicVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsZero);
    }];

}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)goToReading:(NSNotification *)note{

    self.block(note.object);
    NSLog(@"从往期回到阅读");

    [self.navigationController popViewControllerAnimated:YES];
//    [self.navigationController popToViewController:self.navigationController.viewControllers[1] animated:YES];
    
    
}
-(BOOL)shouldAutorotate{
    NSInteger indexSelf = [self.navigationController.viewControllers indexOfObject:self];
    
    return [self.navigationController.viewControllers[indexSelf-1] shouldAutorotate];
}
@end
