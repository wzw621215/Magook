//
//  BeforeHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BeforeHandle : NSObject
+(void)getYearListWithMgID:(NSNumber *)ID completeBlock:(void (^)(id responseObject))success;
+(void)getDetailListWithMgID:(NSNumber *)ID atYear:(NSNumber *)year completeBlock:(void (^)(id responseObject))success;
@end
