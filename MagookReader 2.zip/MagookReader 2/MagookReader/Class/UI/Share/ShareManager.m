//
//  ShareManager.m
//  MagookReader
//
//  Created by tailhuang on 15/9/30.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ShareManager.h"
#import "BonusModel.h"
#import "MGLibHandle.h"
#import "MGIssueModel.h"
#import "SDWebImageManager.h"
#import "ReadingHadle.h"
#import "BonusHadle.h"
#import "NewBonus.h"
#import "BonusHiddenView.h"
#import "SIAlertView.h"
//由于测试服务器的shareserver错误 把分享服务器临时改成固定地址
#define SHARETEMP @"http://weikan.magook.com/"
//{shareserver}/BonusShare/index.html?type={type}&uid={uid}&platform={platform}&urlid={urlid}
#define SHAREURL(platform_src) [NSString stringWithFormat:@"%@BonusShare/index.html?type=0&uid=%@&platform=%@&urlid=%@",SHARETEMP,[UserModel sharedUser].userid,platform_src,[[NSString stringWithFormat:@"%@",[NSDate date]] hashString]]

@interface ShareManager()<UMSocialUIDelegate>


@end
@implementation ShareManager

+(void)shareOnAllPlatformsWithModel:(MGIssueModel *)model currentPage:(NSInteger)page delegate:(id<UMSocialUIDelegate>)delegate {

    NSLog(@"分享%@第%d页",model.magazinename,page);

//"{shareserver}?share={magazineid},{issueid},{pageN},{userid},{deviceid},{pagehashN}"
    //pageN--path
    [LogManager logWithViewID:@11 action:@"read_share_title" info:[NSString stringWithFormat:@"%@;%@",model.magazineid,model.issueid]];
    //pagehashN需要分享页数的HASH
    [ReadingHadle getPageHashWithModel:model currentPage:page finish:^(NSString *pageHashN,NSArray *titleArray) {

        NSString *url = [NSString stringWithFormat:@"%@?share=%@,%@,%@,%@,%@,%@",SHARESERVER,model.magazineid,model.issueid,model.path,[UserModel sharedUser].userid,DEVICEID,pageHashN];


        if (titleArray.count==0||titleArray==nil) {

            [self shareWithModel:model title:@"麦格期刊" url:url delegate:delegate];
        }else if(titleArray.count==1){

            [self shareWithModel:model title:titleArray[0] url:url delegate:delegate];
        }else{
            SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:@"请选择要分享的文章" andMessage:nil];
            
            for (NSString *title in titleArray) {
                [alertView addButtonWithTitle:title type:SIAlertViewButtonTypeDefault handler:^(SIAlertView *alertView) {
                    [self shareWithModel:model title:title url:url delegate:delegate];
                }];
            }
            [alertView addButtonWithTitle:@"取消" type:SIAlertViewButtonTypeCancel handler:^(SIAlertView *alertView) {
                
            }];
            [alertView show];
        }
                }];

}
+(void)shareWithModel:(MGIssueModel *)model title:(NSString *)title url:(NSString *)url delegate :(id<UMSocialUIDelegate>)delegate{
    NSString *shareText=[NSString stringWithFormat:@"%@%@",model.magazinename,model.issuename];
    
    //qq
    UMSocialQQData *qq=[UMSocialQQData new];
    
    [qq setTitle:title];
    [qq setUrl:url];
    qq.shareText=shareText;
    [UMSocialData defaultData].extConfig.qqData=qq;
    
    //Qzone
    UMSocialQzoneData *qzone=[UMSocialQzoneData new];
    [qzone setTitle:title];
    qzone.shareText=shareText;
    [qzone setUrl:url];

    [UMSocialData defaultData].extConfig.qzoneData=qzone;
    
    //微信
    UMSocialWechatSessionData *wx=[UMSocialWechatSessionData new];
    [wx setUrl:url];
    wx.shareText=shareText;
    [wx setTitle:title];
    [UMSocialData defaultData].extConfig.wechatSessionData=wx;
    
    //朋友圈
    UMSocialWechatTimelineData *tl=[UMSocialWechatTimelineData new];
    tl.shareText=shareText;
    [tl setUrl:url];
    [tl setTitle:[NSString stringWithFormat:@"%@\n%@",title,shareText]];
    [UMSocialData defaultData].extConfig.wechatTimelineData=tl;
    //新浪
    
    UMSocialSinaData *sina =[UMSocialSinaData new];
    
    sina.shareImage=[UIImage imageNamed:@"麦格"];
    
    [UMSocialSnsService presentSnsIconSheetView:(UIViewController *)delegate
                                         appKey:@"554878fe67e58e5428003981"
                                      shareText:[NSString stringWithFormat:@"%@-%@%@%@",title,model.magazinename,model.issuename,url]
                                     shareImage:[UIImage imageNamed:@"麦格"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToWechatSession,UMShareToWechatTimeline,UMShareToSina,UMShareToQzone,UMShareToQQ,nil]
                                       delegate:delegate];
}
#pragma mark -微信
+(void)shareOnWXInVc:(UIViewController *)vc{
    NSString *url =SHAREURL(@0);
    NSLog(@"分享微信---%@",SHAREURL(@0));
   [BonusHiddenView disMiss];
    [UMSocialData defaultData].extConfig.wechatTimelineData.title=@"领红包!千种杂志免费看(麦格期刊)";
    [UMSocialData defaultData].extConfig.wechatTimelineData.shareText=@"千种杂志免费看(麦格期刊)";
    [UMSocialData defaultData].extConfig.wechatTimelineData.url = url;

    [[UMSocialDataService defaultDataService] postSNSWithTypes:@[UMShareToWechatTimeline] content:@"千种杂志免费看(麦格期刊)" image:[UIImage imageNamed:@"bonus_share"] location:nil urlResource:nil presentedController:vc completion:^(UMSocialResponseEntity *response) {

        if (response.responseCode == UMSResponseCodeSuccess) {
            NSLog(@"分享成功--微信");

            [self finishShareTaskWithUrl:url];
        }
    }];

}
#pragma mark -新浪
+(void)shareOnSinaInVc:(UIViewController *)vc{
    NSLog(@"分享新浪----%@",SHAREURL(@1));

    [BonusHiddenView disMiss];

    NSString *url =SHAREURL(@1);
    //直接分享

    [[UMSocialControllerService defaultControllerService] setShareText:[NSString stringWithFormat:@"领红包!千种杂志免费看(麦格期刊)%@",url] shareImage:[UIImage imageNamed:@"bonus_share"] socialUIDelegate:(id)vc];
    //设置分享内容和回调对象
    [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina].snsClickHandler(vc,[UMSocialControllerService defaultControllerService],YES);
}
#pragma mark - Qzone
+(void)shareOnQzoneInVc:(UIViewController *)vc{
    NSLog(@"分享QZone--%@",SHAREURL(@2));
    [BonusHiddenView disMiss];
    NSString *url=SHAREURL(@2);
    [UMSocialData defaultData].extConfig.qzoneData.title = @"领红包!";
    [UMSocialData defaultData].extConfig.qzoneData.shareText=@"千种杂志免费看(麦格期刊)";
    [UMSocialData defaultData].extConfig.qzoneData.url = url;

    [[UMSocialDataService defaultDataService]  postSNSWithTypes:@[UMShareToQzone] content:@"千种杂志免费看(麦格期刊)" image:[UIImage imageNamed:@"bonus_share"] location:nil urlResource:nil presentedController:vc completion:^(UMSocialResponseEntity *response){
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            NSLog(@"分享成功--Qzone");
            [self finishShareTaskWithUrl:url];
        }
    }];
    
}
#pragma mark -通讯录
+(void)shareOnTelInVc:(UIViewController *)vc{
    NSString *url=SHAREURL(@3);
    NSLog(@"分享通讯录----%@",url);

    [BonusHiddenView disMiss];
    [[UMSocialDataService defaultDataService]  postSNSWithTypes:@[UMShareToSms] content:url image:[UIImage imageNamed:@"bonus_share"] location:nil urlResource:nil presentedController:vc completion:^(UMSocialResponseEntity *response){
        if (response.responseCode == UMSResponseCodeSuccess) {
            NSLog(@"分享成功--通讯录");
            [self finishShareTaskWithUrl:url];
        }
    }];

}

+(void)checkBonusCompleteBlock:(void (^)(BOOL weiXin,BOOL sina ,BOOL qzone,BOOL tel))block{
//    url=”{purchaseserver}/bonus/getbonusbyuid”
    NSLog(@"检查是否有对应的红包");

    [BonusHadle getBonusDataWithStatusfilter:@"" compete:^(id obj) {
        if (obj) {
            BOOL WXBonus = NO;
            BOOL SinaBonus = NO;
            BOOL QzoneBonus =NO;
            BOOL TelBonus =NO;
            
            for (NSDictionary *dic in obj[@"data"]) {
                //排除NULL
                if ([dic[@"bonustype"] isEqualToString:@"MUTEX"]) {
                    switch ([dic[@"platform_src"] integerValue]) {
                        case 0:
                            //微信
                            WXBonus=YES;
                            NSLog(@"有微信红包");
                            break;
                        case 1:
                            //新浪
                            SinaBonus=YES;
                            NSLog(@"有新浪红包");
                            break;
                        case 2:
                            //qzone
                            QzoneBonus=YES;
                            NSLog(@"有QQ空间红包");
                            break;
                        case 3:
                            //通讯录
                            TelBonus=YES;
                            NSLog(@"有通讯录红包");
                            break;
                        default:
                            NSLog(@"无平台红包");
                            break;
                    }
                    
                }
                    block(WXBonus,SinaBonus,QzoneBonus,TelBonus);
            }
        }else{
            block(NO,NO,NO,NO);
            NSLog(@"获取红包列表失败");
        }
    }];
}
#pragma mark - 完成分享任务
+(void)finishShareTaskWithUrl:(NSString *)shareUrl{

    NSLog(@"发送完成分享任务请求");
    NSString *url =[NSString stringWithFormat:@"%@bonus/sharetask",PURCHASSERVER];
    NSDictionary *param=@{
                          @"shareurl":shareUrl,
                          @"device":DEVICE
                          };
    NSLog(@"%@",url);
    NSLog(@"%@",[param JSONString]);
    [NSOperation POST:url parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"finishShareTaskWithUrl========%@",responseObject);
        //此处数据类型可能为string 和number
        
        BOOL statusNormal=NO;
        if ([responseObject[@"status"] isKindOfClass:[NSNumber class]]) {
            statusNormal=[responseObject[@"status"] isEqualToNumber:@1]?YES:NO;
        }else if([responseObject[@"status"] isKindOfClass:[NSString class]]){
            statusNormal=[responseObject[@"status"] isEqualToString:@"1"]?YES:NO;
        }
        if (statusNormal) {
            NSNumber *hasbonus = responseObject[@"data"][@"hasbonus"];
            if ([hasbonus integerValue]) {

                NSLog(@"成功完成分享任务，获得新红包----%@",url);
                [self hasNewBonusWithBonusNumber:hasbonus];
                POSTER(HasNewBonusNotification, hasbonus);
                
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
+(void)hasNewBonusWithBonusNumber:(NSNumber *)bonusNumber{
    //弹出窗口
    [NewBonus showWithNumber:bonusNumber];
}
@end
