//
//  ShareManager.h
//  MagookReader
//
//  Created by tailhuang on 15/9/30.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UMSocial.h"
@class MGIssueModel;
@interface ShareManager : NSObject
+(void)shareOnAllPlatformsWithModel:(MGIssueModel *)model currentPage:(NSInteger)page delegate:(id <UMSocialUIDelegate>)delegate;
+(void)shareOnWXInVc:(UIViewController *)vc;
+(void)shareOnSinaInVc:(UIViewController *)vc;
+(void)shareOnQzoneInVc:(UIViewController *)vc;
+(void)shareOnTelInVc:(UIViewController *)vc;
+(void)checkBonusCompleteBlock:(void (^)(BOOL weiXin,BOOL sina ,BOOL qzone,BOOL tel))block;
//完成分享任务
+(void)finishShareTaskWithUrl:(NSString *)shareUrl;
@end
