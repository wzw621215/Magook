//
//  AboutViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"

@interface AboutViewController : BasicViewController

@end
