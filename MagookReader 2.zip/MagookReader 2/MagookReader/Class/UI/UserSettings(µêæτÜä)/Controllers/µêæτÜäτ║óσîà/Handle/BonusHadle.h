//
//  BonusHadle.h
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
typedef void (^complete)(id obj);
typedef void (^history)(id obj,NSString *date);
@interface BonusHadle : NSObject
/**
 *  获取红包列表
 *
 *  @param statusfilter @“”获取全部红包 @0 获取新红包
 *  @param complete     完成
 */
+(void)getBonusDataWithStatusfilter:(id )statusfilter compete:(complete)complete;
//从订单借口中获取，由于上方法中无法获取红包对应的magazineid
+(void)getBonusHistoryDataFinish:(history)history;
@end
