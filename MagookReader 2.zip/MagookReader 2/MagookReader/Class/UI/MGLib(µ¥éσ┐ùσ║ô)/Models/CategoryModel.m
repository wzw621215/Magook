//
//  CategoryModel.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "CategoryModel.h"

@implementation CategoryModel
+(instancetype)modelWithDic:(NSDictionary *)dic{
    CategoryModel *model = [[self alloc]init];

    [model setValuesForKeysWithDictionary:dic];

    return model;
}
@end
