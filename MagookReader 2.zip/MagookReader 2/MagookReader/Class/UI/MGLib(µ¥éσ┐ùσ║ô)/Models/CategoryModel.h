//
//  CategoryModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"

@interface CategoryModel : BasicModel
@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSNumber *category;
+(instancetype)modelWithDic:(NSDictionary *)dic;
@end
