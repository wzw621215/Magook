//
//  MGLibHandle.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGLibHandle.h"
#import "CategoryModel.h"
#import "SVProgressHUD.h"

@implementation MGLibHandle
+(void)getRightButtonTitlesCompletionHandler:(void (^)(id obj)) handler{
    //url=”{businesscacheServer}/bookan/bookan_{orgid}/class/class_{orgid}.txt”
    //缓存
    NSString *path = [CACHEPATH stringByAppendingPathComponent:MGLIBCATEGORYPLIST];
    if([[NSFileManager defaultManager]fileExistsAtPath:path]){
        NSDictionary *objDic=[NSDictionary dictionaryWithContentsOfFile:path];
//        NSLog(@"objDic====%@",objDic);
        NSLog(@"从缓存读取category");
        handler(objDic);
        return;
    }
    //网络请求
    NSLog(@"网络加载category");
    NSString *url = [NSString stringWithFormat:@"%@bookan/bookan_magook/class/class_magook.txt",BUSSINESCACHESSERVER];
   [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
    
    if (data) {
        NSArray *array=[data objectFromJSONData];
        [array writeToFile:path atomically:YES];
        handler(array);
    }else{
        NSLog(@"获取杂志库右侧列表数据失败");
    }

}];


}
//主页列表
+(void)getMGListDataWithCategory:(NSNumber *)category page:(NSNumber *)page completionHandler:(void (^)(id))handler{


    [SVProgressHUD showWithStatus:@"加载中" maskType:SVProgressHUDMaskTypeClear];

    NSString *url=[NSString stringWithFormat:@"%@bookan/bookan_magook/classlist/classlist_magook_%@_%@.txt",BUSSINESCACHESSERVER,category,page];

    NSLog(@"杂志库--------%@",url);

    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]] queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (data) {
            handler([data objectFromJSONData]);
        }else{
            [ZBHud showErrorWithMessage:@"连接服务器失败"];
            handler(nil);
        }
        [SVProgressHUD dismiss];
    }];

}

//url=”{pageServer}/{path}/{magazineid}/{magazineid}-{issueid}/cover_small.mg”
+(void)getMGListCoverWithPath:(NSString *)path magezineID:(NSNumber *)magezineID issueid:(NSNumber *)issueid completionHandler:(void (^)( NSString *))handler{

    NSString *url =[NSString stringWithFormat:@"%@%@/%@/%@-%@/cover_small.mg",PAGESERVER,path,magezineID,magezineID,issueid];

    handler(url);



}
@end
