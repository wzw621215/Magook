//
//  MGLibCell.m
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGLibCell.h"
#import "MGLibHandle.h"
#import "MGIssueModel.h"
#import "UIButton+WebCache.h"
#import "ShoppingCartDataManager.h"
#import "OMGToast.h"
@interface MGLibCell()

@property (weak, nonatomic) IBOutlet UIButton *purchaseCarButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UIButton *cover;

@end
@implementation MGLibCell

- (void)awakeFromNib {
    if (iPad) {
        self.titleLab.font=FONTIPAD;
        self.purchaseCarButton.titleLabel.font=FONTIPAD;
    }
}
- (IBAction)coverClick:(UIButton *)sender {
    if (self.block) {
        self.block(self.model);
    }
}

-(void)setModel:(MGIssueModel *)model{
    _model                                   = model;
    self.titleLab.text                       = model.magazinename;

    [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
//        BOOL isExsist=[[SDWebImageManager sharedManager]diskImageExistsForURL:[NSURL URLWithString:url]];
//        UIImage *image =[[SDImageCache sharedImageCache]imageFromDiskCacheForKey:[[SDWebImageManager sharedManager] cacheKeyForURL:[NSURL URLWithString:url]]];
//        NSLog(@"%@",url);
//        NSString *path =[[SDImageCache sharedImageCache] defaultCachePathForKey:url];
//        NSLog(@"%@",path);
//        NSFileManager  *manager = [NSFileManager defaultManager];
//        BOOL pathExsit=[manager fileExistsAtPath:path];
//        NSLog(@"%@",pathExsit?@"文件存在":@"文件不存在");
//        NSLog(@"%@----%@---%@",model.magazinename,isExsist?@"存在缓存":@"不存在缓存",image);
        [self.cover sd_setBackgroundImageWithURL:[NSURL URLWithString:url] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"封面"]];
    }];

    _model.isSelected=[[ShoppingCartDataManager sharedManager]isExistsDataWithModel:self.model];

    if (_model.isSelected) {
        self.purchaseCarButton.backgroundColor=[UIColor orangeColor];
    self.purchaseCarButton.selected          = YES;
    }else{
        self.purchaseCarButton.backgroundColor=[UIColor clearColor];
    self.purchaseCarButton.selected          = NO;
    }
}
- (IBAction)purchaseCarButtonClick:(UIButton *)sender {

    UserPermissionStyle permission=[AppController checkPermissionWithMagazineID:self.model.magazineid];
    if (permission==UserPermissionStylePurchased) {
        //已购买的杂志点击添加到购物车
        [OMGToast showWithText:@"您已获得该杂志阅读权限\n无需再次购买" bottomOffset:60 duration:3];
        return;
    }

    //未购买的杂志点击添加到购物车
        self.model.isSelected=!self.model.isSelected;

        if (self.model.isSelected) {
            self.purchaseCarButton.backgroundColor=[UIColor orangeColor];
            self.purchaseCarButton.selected          = YES;
            [[ShoppingCartDataManager sharedManager]insertDataWithModel:self.model];
            [LogManager logWithViewID:@6 action:@"read_addfavor" info:[NSString stringWithFormat:@"%@;%@",self.model.magazineid,self.model.issueid]];
            [OMGToast showWithText:@"添加到购物车成功" bottomOffset:60 duration:1];
        }else{
            [LogManager logWithViewID:@6 action:@"favor_del"];
            self.purchaseCarButton.backgroundColor=[UIColor clearColor];
            self.purchaseCarButton.selected          = NO;
            [[ShoppingCartDataManager sharedManager]deleteDataWithModel:self.model];
        }
        //发送购物车数据发生变化通知
    POSTER(ShoppingCartDidChangeNotification, nil);

}
-(void)drawRect:(CGRect)rect{
    self.purchaseCarButton.layer.borderWidth = 2;
    self.purchaseCarButton.layer.borderColor=[[UIColor orangeColor]CGColor];
    [self.purchaseCarButton cutCornerRadius:5];

}
@end
