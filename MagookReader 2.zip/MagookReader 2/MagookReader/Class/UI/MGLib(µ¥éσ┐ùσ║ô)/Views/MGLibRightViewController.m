//
//  MGLibRightViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/3.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "MGLibRightViewController.h"
#import "RightViewCell.h"
#import "CategoryModel.h"
@interface MGLibRightViewController ()

//{
//    NSInteger _selectedIndex;
//}

@end

@implementation MGLibRightViewController
- (void)viewDidLoad {
    [super viewDidLoad];

}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *ID=@"yearCell";
    RightViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell= LOADNIBNAME(@"RightViewCell");
    }
    
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    cell.backgroundColor=BKCOLOR;
    
    cell.lab.textColor=[UIColor blackColor];
    if (indexPath.row==self.selectedIndex) {
        cell.lab.textColor=COLOR;
        cell.backgroundColor=[UIColor whiteColor];
    }
    if (self.dataArray.count) {
    CategoryModel *model=self.dataArray[indexPath.row];
    cell.lab.text=model.name;
    }
    if (iPad) {
        cell.lab.font=FONTIPAD;
    }
    return cell;
}



@end
