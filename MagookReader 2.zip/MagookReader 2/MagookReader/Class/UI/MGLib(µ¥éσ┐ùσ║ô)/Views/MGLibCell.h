//
//  MGLibCell.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface MGLibCell : UICollectionViewCell
@property (nonatomic, strong)MGIssueModel *model;
@property (nonatomic, copy) void(^block)(MGIssueModel*);
@end
