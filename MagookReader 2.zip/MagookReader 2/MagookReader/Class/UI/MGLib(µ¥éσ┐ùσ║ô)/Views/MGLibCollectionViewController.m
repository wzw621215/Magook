//
//  MGLibCollectionViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/13.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGLibCollectionViewController.h"


@interface MGLibCollectionViewController ()

@end

@implementation MGLibCollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

@end
