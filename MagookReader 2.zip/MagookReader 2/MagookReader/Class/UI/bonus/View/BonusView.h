//
//  BonusView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BonusView : UIView
@property(nonatomic, copy) void (^block)(void);
@property (nonatomic, weak) UIViewController *parentController;
//-(void)showWithNumber:(NSNumber *)number;
@end
