//
//  ExchangeCell.m
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ExchangeCell.h"
#import "UIImageView+WebCache.h"
#import "MGIssueModel.h"
#import "MGLibHandle.h"
@interface ExchangeCell()

@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@end
@implementation ExchangeCell
-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self=[super initWithCoder:aDecoder]) {
        OBSERVER(LimitedStepNotification, @selector(Limited:));
    }
    return self;
}
-(void)Limited:(NSNotification *)noti{
    NSLog(@"Limited=========%@",noti.object);
    self.stepper.incrementButton.enabled=[noti.object integerValue];
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)awakeFromNib{
    [self.stepper setButtonFont:[UIFont systemFontOfSize:20]];
    [self.stepper setBorderColor:[UIColor blackColor]];
    [self.stepper setButtonTextColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.stepper setLabelFont:[UIFont systemFontOfSize:16]];
    [self.stepper setLabelTextColor:[UIColor blackColor]];

    __block CGFloat lastCount=0;
    self.stepper.valueChangedCallback = ^(PKYStepper *stepper, float count) {
        stepper.countLabel.text = [NSString stringWithFormat:@"%@", @(count)];
        
        if (lastCount!=count) {
            [[NSNotificationCenter defaultCenter]postNotificationName:StepValueDidChageNotification object:self.model userInfo:@{@"count":@((NSInteger)count)}];
            if (count>0) {
                [stepper setBorderColor:[UIColor redColor]];
            }else{
                [stepper setBorderColor:[UIColor blackColor]];
            }
        }
        self.model.stepValue=count;
        
        lastCount=count;
    };
    [self.stepper setup];
}
-(void)setModel:(MGIssueModel *)model{
    _model=model;
    self.titleLab.text=model.magazinename;
    //确保复用不出问题
    self.stepper.value=model.stepValue;
    if (self.stepper.value>0) {
        [self.stepper setBorderColor:[UIColor redColor]];
    }else{
        [self.stepper setBorderColor:[UIColor blackColor]];
    }
    [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
        
        [self.cover sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"封面"]];
        
        
    }];
    
   
}

@end
