//
//  BounusButton.m
//  Pic
//
//  Created by tailhuang on 15/9/28.
//  Copyright © 2015年 magook.com. All rights reserved.
//

#import "BounusButton.h"

#define BackGroundColor RGB(238,87,87,1)
#define BrownColor RGB(153,3,3,1)
#define YellowColor RGB(255,204,3,1)

@interface BounusButton ()
@property (weak, nonatomic) IBOutlet UILabel *headLab;
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *faLab;
@property (weak, nonatomic) IBOutlet UIImageView *titleImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;

@end
@implementation BounusButton

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.backgroundColor=BackGroundColor;


    self.headImageView.layer.borderColor=[BackGroundColor  CGColor];
    self.headImageView.layer.borderWidth=1.5;
    [self.faLab cutCornerRadius:20];


//    self.isFa=YES;
//    self.type=BounusTypeWeChat;

    [self cutCornerRadius:10];


}
-(void)setIsFa:(BOOL)isFa{

    _isFa=isFa;
    [self.headImageView setImage:[[UIImage imageNamed:isFa?@"radius_redpackt_yellow.9":@"radius_redpackt_red.9"] stretchableImageWithLeftCapWidth:70 topCapHeight:30]];

    self.headLab.text =isFa?@"免费发，还能领":@"领红包，免费看";
    self.headLab.textColor=isFa?BrownColor:YellowColor;


    self.faLab.text=isFa?@"发":@"领";
    self.faLab.backgroundColor=isFa?BrownColor:YellowColor;
    self.faLab.textColor=isFa?YellowColor:BrownColor;
}

-(void)setType:(BounusType)type{
    _type=type;
    switch (type) {
        case BounusTypeWeChat:
            self.titleLab.text=@"朋友圈，分享即领";
            self.titleImageView.image=[UIImage imageNamed:@"朋友圈"];
            break;
        case BounusTypeSina:
            self.titleLab.text=@"新浪微博，分享即领";
            self.titleImageView.image=[UIImage imageNamed:@"weibo"];
            break;
        case BounusTypeQzone:
            self.titleLab.text=@"QQ空间，免费发红包";
            self.titleImageView.image=[UIImage imageNamed:@"QQ空间"];
            break;
        case BounusTypeTel:
            self.titleLab.text=@"通讯录，分享即领";
            self.titleImageView.image=[UIImage imageNamed:@"通讯录"];
            break;

        default:
            break;
    }

}
-(instancetype)initWithCoder:(NSCoder *)aDecoder{

    if (self= [super initWithCoder:aDecoder]) {


    }
    return self;
}
-(void)drawRect:(CGRect)rect{

}
@end
