//
//  BounusButton.h
//  Pic
//
//  Created by tailhuang on 15/9/28.
//  Copyright © 2015年 magook.com. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef NS_ENUM(NSInteger, BounusType){
    BounusTypeWeChat,
    BounusTypeSina,
    BounusTypeQzone,
    BounusTypeTel

};
@interface BounusButton : UIButton
@property (nonatomic, assign) BOOL isFa;
@property (nonatomic, assign) BounusType type;
@end
