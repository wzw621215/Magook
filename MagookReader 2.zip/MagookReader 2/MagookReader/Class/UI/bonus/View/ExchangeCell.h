//
//  ExchangeCell.h
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKYStepper.h"
@class MGIssueModel;
@interface ExchangeCell : UICollectionViewCell
@property (nonatomic, strong)MGIssueModel *model;
@property (weak, nonatomic) IBOutlet PKYStepper *stepper;
@property (weak, nonatomic) IBOutlet UIImageView *cover;
//@property (nonatomic ,copy) void (^stepBlock)(NSInteger step,MGIssueModel *model);
@end
