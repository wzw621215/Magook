//
//  BonusHiddenView.m
//  MagookReader
//
//  Created by zhoubin on 15/10/28.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusHiddenView.h"
#import "BonusView.h"
#import "LoginViewController.h"
@interface BonusHiddenView ()
@property (nonatomic, weak) UIViewController *parentController;
@property (nonatomic ,weak) BonusView *bonusView;
@end
@implementation BonusHiddenView
static BonusHiddenView *hidden=nil;
-(instancetype)initWithFrame:(CGRect)frame{
    if (!hidden) {
        if (self=[super initWithFrame:frame]) {
            
            UILabel *titleLab=[[UILabel alloc]init];
            titleLab.text=@"领红包免费看杂志\n3000种任选";
            titleLab.textAlignment = NSTextAlignmentCenter;
            titleLab.numberOfLines = 0;
            titleLab.textColor=[UIColor whiteColor];
            [self addSubview:titleLab];
            [titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerX.equalTo(self);
                make.top.mas_equalTo(20);
                make.height.mas_equalTo(60);
                make.width.equalTo(self);
            }];

            UIButton *cancelButton=[UIButton buttonWithType:UIButtonTypeCustom];

//            cancelButton.frame     = CGRectMake(frame.size.width-50, 20, 50, 50);
            [cancelButton setImage:[UIImage imageNamed:@"btn_cancel_normal"] forState:UIControlStateNormal];
            [cancelButton addTarget:self action:@selector(cancelButtonClick) forControlEvents:UIControlEventTouchUpInside];

            [self addSubview:cancelButton];
            [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self).with.offset(-Margin);
                make.top.equalTo(self).with.offset(Margin);
                make.size.mas_equalTo(CGSizeMake(50, 50));
            }];


            BonusView *bonusView   = [[BonusView alloc]init];

            [self addSubview:bonusView];
            [bonusView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT+20, Margin, TAB_HEIGHT, Margin));
            }];
            self.bonusView         = bonusView;


            self.backgroundColor   = RGB(0, 0, 0, 0.5);
        }
    }
    
    return self;
}
-(void)setParentController:(UIViewController *)parentController{
    _parentController               = parentController;
    self.bonusView.parentController = parentController;
}
+(void)showWithParentController:(UIViewController *)parentController{
    UIWindow *window                = [UIApplication sharedApplication].keyWindow;
    if (!hidden) {
        hidden=[[self alloc] initWithFrame:[UIScreen mainScreen].bounds];
    hidden.parentController         = parentController;
    }
    [window addSubview:hidden];
    [hidden mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsZero);
    }];
}
-(void)cancelButtonClick{
    [hidden removeFromSuperview];
    hidden                          = nil;
}
+(void)disMiss{

    if (hidden) {
        [NSThread sleepForTimeInterval:1.0];
        [hidden removeFromSuperview];
    hidden                          = nil;
    }

}
-(void)dealloc{
    NSLog(@"销毁BonusHiddenView");
}
@end
