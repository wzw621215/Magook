//
//  NewBonus.m
//  hongbao
//
//  Created by zhoubin on 15/10/27.
//  Copyright © 2015年 zhoubin. All rights reserved.
//

#import "NewBonus.h"
#define BrownColor RGB(153,3,3,1)
@interface NewBonus()
@property (nonatomic ,weak) UIImageView *backImageV;
@property (nonatomic ,weak) UILabel *centerLab;
@property (nonatomic ,weak) UIButton *cancelButton;
@end
@implementation NewBonus
static NewBonus *bonus=nil;
-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        
        UIImageView *backImageV=[[UIImageView alloc]init];
//        CGRect imgFrame=CGRectMake(20, 100, frame.size.width-40,frame.size.height-200);
//        backImageV.frame=imgFrame;
        backImageV.image=[UIImage imageNamed:@"红包2_bg"];
        [backImageV cutCornerRadius:10];
        [self addSubview:backImageV];
        [backImageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(50, 20, 50, 20));
        }];
        
        self.backImageV=backImageV;
        
        
        UILabel *topLab=[[UILabel alloc]init];
//        WithFrame:CGRectMake(0,0, imgFrame.size.width, 100)
        topLab.numberOfLines=0;
        topLab.textAlignment=NSTextAlignmentCenter;
        topLab.textColor=[UIColor orangeColor];
        topLab.text=@"恭喜\n你和好友各获得红包一个";
        [backImageV addSubview:topLab];
        self.topLab=topLab;
        [topLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(backImageV);
            make.right.equalTo(backImageV);
            make.top.equalTo(backImageV);
            make.height.mas_equalTo(100);
        }];
        
        CGFloat centerLabW=80;
        UILabel *centerLab=[[UILabel alloc]init];
//        WithFrame:CGRectMake(0, 0, centerLabW, centerLabW)
        centerLab.numberOfLines=0;
        centerLab.layer.cornerRadius=centerLabW/2;
        centerLab.layer.masksToBounds=YES;
        centerLab.textAlignment=NSTextAlignmentCenter;
        centerLab.backgroundColor=[UIColor yellowColor];
        centerLab.textColor=[UIColor brownColor];
        centerLab.text=@"我的\n红包";
        [backImageV addSubview:centerLab];
        self.centerLab=centerLab;
        //328*470
        //中心点：x：163.5 y：190
//        CGFloat centerX=self.backImageV.frame.size.width*163.5/328;
//        CGFloat centerY=self.backImageV.frame.size.height*190/470;
        [centerLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 80));
            make.centerX.equalTo(backImageV);
            make.centerY.equalTo(backImageV).with.multipliedBy(190*2/470.0);
        }];
        
        
        UILabel *bottomLab1=[[UILabel alloc]init];
//        WithFrame:CGRectMake(0, 0, imgFrame.size.width, 50)
        bottomLab1.numberOfLines=0;
        bottomLab1.textAlignment=NSTextAlignmentCenter;
        bottomLab1.textColor=BrownColor;
        bottomLab1.text=@"分享红包获赠免费阅读时长";
        [backImageV addSubview:bottomLab1];
        self.bottomLab1=bottomLab1;
        [bottomLab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(200, 50));
            make.centerX.equalTo(backImageV);
            make.centerY.equalTo(backImageV).with.multipliedBy((190+(470-190)/3.0)*2/470);
        }];
        
        UILabel *bottomLab2=[[UILabel alloc]init];
//        WithFrame:CGRectMake(0, 0, imgFrame.size.width, 50)
        bottomLab2.numberOfLines=0;
        bottomLab2.textAlignment=NSTextAlignmentCenter;
        bottomLab2.textColor=[UIColor whiteColor];
        bottomLab2.text=@"多少好友抢到红包\n你再获得多少红包";
        [backImageV addSubview:bottomLab2];
        self.bottomLab2=bottomLab2;

        [bottomLab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(200, 50));
            make.centerX.equalTo(backImageV);
            make.centerY.equalTo(backImageV).with.multipliedBy((190+(470-190)*2/3.0)*2/470);
        }];
        
        UIButton *cancelButton=[UIButton buttonWithType:UIButtonTypeCustom];
//        cancelButton.frame=CGRectMake(backImageV.frame.size.width-50, 0, 50, 50);
        [cancelButton setImage:[UIImage imageNamed:@"btn_cancel_normal"] forState:UIControlStateNormal];
        [cancelButton addTarget:self action:@selector(remove) forControlEvents:UIControlEventTouchUpInside];
        
        [backImageV addSubview:cancelButton];
        backImageV.userInteractionEnabled=YES;
        self.cancelButton=cancelButton;
        [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(50, 50));
            make.top.equalTo(backImageV);
            make.right.equalTo(backImageV);
        }];

        self.backgroundColor=RGB(0, 0, 0, 0.5);
        
        
    }
    return self;
}
-(void)remove{

    [self removeFromSuperview];

}
+(void)showWithNumber:(NSNumber *)bonusNumber{
        UIWindow *window =[UIApplication sharedApplication].keyWindow;
        bonus =[[self alloc]init];
        bonus.topLab.text=[NSString stringWithFormat:@"恭喜！您获得了%@个红包",bonusNumber];
        [window addSubview:bonus];
        [bonus mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsZero);
        }];
        [bonus performSelector:@selector(remove) withObject:nil afterDelay:3];
}

@end
