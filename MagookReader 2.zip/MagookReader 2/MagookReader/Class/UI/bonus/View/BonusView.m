//
//  BonusView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusView.h"
#import "BounusButton.h"
#import "ShareManager.h"
#import "BonusModel.h"
#import "NewBonus.h"
@interface BonusView()

@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, weak)BounusButton *wechatButton;
@property (nonatomic, weak)BounusButton *sinaButton;
@property (nonatomic, weak)BounusButton *QzoneButton;
@property (nonatomic, weak)BounusButton *telButton;

@end
@implementation BonusView

-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        OBSERVER(HasNewBonusNotification, @selector(hasNewBonus:));
       
        //微信
        BounusButton *wechatButton=LOADNIBNAME(@"BounusButton");

        wechatButton.type  = BounusTypeWeChat;

        [self addSubview:wechatButton];

        self.wechatButton=wechatButton;

        //新浪
        BounusButton *sinaButton=LOADNIBNAME(@"BounusButton");
        sinaButton.type    = BounusTypeSina;
        [self addSubview:sinaButton];
        self.sinaButton=sinaButton;
        //QQ空间
        BounusButton *QzoneButton=LOADNIBNAME(@"BounusButton");
        QzoneButton.type   = BounusTypeQzone;

        [self addSubview:QzoneButton];
        self.QzoneButton=QzoneButton;

        //通讯录
        BounusButton *telButton=LOADNIBNAME(@"BounusButton");
        telButton.type     = BounusTypeTel;
        [self addSubview:telButton];
        self.telButton=telButton;


        self.wechatButton.isFa = NO;
        self.sinaButton.isFa   = NO;
        self.QzoneButton.isFa  = NO;
        self.telButton.isFa    = NO;

        [self.wechatButton addTarget:self action:@selector(wechatButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self.sinaButton addTarget:self action:@selector(sinaButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self.QzoneButton addTarget:self action:@selector(QzoneButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [self.telButton addTarget:self action:@selector(telButtonClick) forControlEvents:UIControlEventTouchUpInside];

        [self checkStatus];

    }
    return self;
}
-(void)hasNewBonus:(NSNotification *)noti{
//    NSNumber *bonus=noti.object;
//    //弹出窗口
//    UIWindow *window =[UIApplication sharedApplication].keyWindow;
//    NewBonus *view =[[NewBonus alloc]init];
//    view.topLab.text=[NSString stringWithFormat:@"恭喜！您获得了%@个红包",bonus];
//    [window addSubview:view];
//    [view mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(UIEdgeInsetsZero);
//    }];
//    [view performSelector:@selector(remove) withObject:nil afterDelay:3];
    //更新按钮状态
    [self checkStatus];
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)checkStatus{

    if ([UserModel sharedUser].usertoken) {
        [ShareManager checkBonusCompleteBlock:^(BOOL weiXin, BOOL sina, BOOL qzone, BOOL tel) {

            self.wechatButton.isFa = weiXin;
            self.sinaButton.isFa   = sina;
            self.QzoneButton.isFa  = qzone;
            self.telButton.isFa    = tel;
            
        }];
    }
}

-(void)wechatButtonClick{

    if ([self checkLogin]) {
        [ShareManager shareOnWXInVc:self.parentController];
    }

}
-(void)sinaButtonClick{
    if ([self checkLogin]) {

    [ShareManager shareOnSinaInVc:self.parentController];
    }

}
-(void)QzoneButtonClick{
   if ([self checkLogin]) {
    [ShareManager shareOnQzoneInVc:self.parentController];
   }
}
-(void)telButtonClick{
    if ([self checkLogin]) {
    [ShareManager shareOnTelInVc:self.parentController];

    }
}
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[NSMutableArray array];
    }
    return _dataArray;
}

-(BOOL)checkLogin{

    NSLog(@"检查是否登录:%@",[UserModel sharedUser].usertoken?@"已登录":@"未登录");

    if ([UserModel sharedUser].usertoken) {

        return YES;

    }else{
        //回调block，让控制器跳转登录
        [LogManager logWithViewID:@39 action:@"read_login"];
        if(self.block){
            self.block();
        }
        return NO;
    }

}
-(void)layoutSubviews{
    [super layoutSubviews];
    CGFloat min             = MIN(self.width, self.height);
    CGFloat max             = MAX(self.width, self.height);
    CGFloat bonusPW         = (min-3*Margin)/2.0;
    CGFloat bonusPH         = (max-3*Margin)/2.0;
    CGFloat bonusLW         = (max-5*Margin)/4.0;
    CGFloat bonusLH         = (iPad?min*GoldenSection:min)-2*Margin;
    if (PORTRAIT) {

    self.wechatButton.frame = CGRectMake(Margin, Margin, bonusPW, bonusPH);
    self.sinaButton.frame   = CGRectMake(bonusPW+2*Margin, Margin, bonusPW, bonusPH);
    self.QzoneButton.frame  = CGRectMake(Margin, bonusPH+2*Margin, bonusPW, bonusPH);
    self.telButton.frame    = CGRectMake(bonusPW+2*Margin, bonusPH+2*Margin, bonusPW, bonusPH);
    }else{

    self.wechatButton.frame = CGRectMake(Margin, Margin, bonusLW, bonusLH);
    self.sinaButton.frame   = CGRectMake(bonusLW+2*Margin, Margin, bonusLW, bonusLH);
    self.QzoneButton.frame  = CGRectMake(2*bonusLW+3*Margin, Margin, bonusLW, bonusLH);
    self.telButton.frame    = CGRectMake(3*bonusLW+4*Margin, Margin, bonusLW, bonusLH);
    }

    
}
@end
