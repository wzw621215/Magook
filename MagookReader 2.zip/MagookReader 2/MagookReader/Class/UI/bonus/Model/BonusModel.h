//
//  BonusModel.h
//  MagookReader
//
//  Created by tailhuang on 15/9/30.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"

@interface BonusModel : BasicModel
@property (nonatomic, strong) NSNumber *ID;
@property (nonatomic, copy) NSString *bonustype;
@property (nonatomic, copy) NSString *bonusname;
@property (nonatomic, strong) NSNumber *uid_src;
@property (nonatomic, strong) NSNumber *platform_src;
@property (nonatomic, strong) NSNumber *uid_bind;
@property (nonatomic, copy) NSString *mobile_bind;
@property (nonatomic, strong) NSNumber *bonusstatus;
@property (nonatomic, strong) NSNumber *buypackageid;
@property (nonatomic, copy) NSString *enableddate;
@property (nonatomic, copy) NSString *usedate;
@property (nonatomic, copy) NSString *expiresdate;
@property (nonatomic, copy) NSString *createdate;
@property (nonatomic, copy) NSString *remark;
@end
