//
//  ShoppingCartExChangeViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/11/6.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicCollectionViewController.h"
@interface ShoppingCartExChangeViewController : BasicCollectionViewController
//@property (nonatomic ,assign) NSInteger bonusNumber;
@property (nonatomic ,copy) void (^plusBlock)();
@end
