//
//  BonusExchageCollectionView.m
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusExchageCollectionView.h"
#import "ExchangeCell.h"
#import "LibDataModel.h"
#import "MGIssueModel.h"

@interface BonusExchageCollectionView ()
@property (nonatomic ,strong) NSMutableDictionary *dataDic;
@property (nonatomic ,assign) NSInteger total;
@end

@implementation BonusExchageCollectionView

static NSString * const reuseIdentifier = @"ExchangeCell";

-(NSMutableDictionary *)dataDic{
    if (!_dataDic) {
        _dataDic=[NSMutableDictionary new];
    }
    return _dataDic;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(LimitedStepNotification, @selector(limitedDidChange:));

    UINib *cellNib = [UINib nibWithNibName:@"ExchangeCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];

}

-(void)limitedDidChange:(NSNotification *)noti{
    self.isLimited=[noti.object  integerValue];
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    ExchangeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    //防崩溃保护
    if (self.model.dataArray.count) {
        cell.model=self.model.dataArray[indexPath.row];

    }
    int total=0;
    
    for (NSDictionary *d in [self.dataDic allValues]) {
        NSNumber *quantity=d[@"quantity"];
        total += [quantity integerValue];
    }
    cell.stepper.incrementButton.enabled=self.isLimited&&total<self.bonusNumber;

    
    return cell;
}


@end
