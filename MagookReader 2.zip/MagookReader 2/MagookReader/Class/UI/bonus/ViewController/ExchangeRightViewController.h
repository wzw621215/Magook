//
//  ExchangeRightViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/10/24.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "BasicMGLibRightViewController.h"
@interface ExchangeRightViewController : BasicMGLibRightViewController
//@property (nonatomic, strong) NSMutableArray *dataArray;
//@property (nonatomic, copy) void (^block)(NSInteger selectedIndex);
@end
