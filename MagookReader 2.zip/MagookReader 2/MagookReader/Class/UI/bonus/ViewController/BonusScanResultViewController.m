//
//  BonusScanResultViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/7.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusScanResultViewController.h"
#import "ExchangeCell.h"
//#import "MGIssueModel.h"
//#import "ShoppingCartDataManager.h"

@implementation BonusScanResultViewController

static NSString * const reuseIdentifier = @"ExchangeCell";



- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(LimitedStepNotification, @selector(limitedDidChange:));
    UINib *cellNib = [UINib nibWithNibName:@"ExchangeCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];
}

-(void)limitedDidChange:(NSNotification *)noti{
    self.isLimited=[noti.object integerValue];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ExchangeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    cell.stepper.incrementButton.enabled=self.isLimited;

    if (self.dataArray.count) {
        cell.model=self.dataArray[indexPath.row];
    }
    return cell;
}
@end
