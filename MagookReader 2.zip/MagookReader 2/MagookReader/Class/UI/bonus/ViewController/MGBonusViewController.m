//
//  MGBonusViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGBonusViewController.h"
#import "NSAttributedString+ZBAttibutedSting.h"
#import "BonusView.h"
#import "LoginViewController.h"
#import "UIBarButtonItem+Badge.h"
#import "MyBonusViewController.h"
#import "BonusHadle.h"
#import "BonusModel.h"
#import "ShareManager.h"
#import "NewBonus.h"
#define BrownColor RGB(153,3,3,1)
#define SHAREURL(platform_src) [NSString stringWithFormat:@"%@BonusShare/index.html?type=0&uid=%@&platform=%@&urlid=%@",SHARESERVER,[UserModel sharedUser].userid,platform_src,[[NSString stringWithFormat:@"%@",[NSDate date]] hashString]]
@interface MGBonusViewController ()
@property (nonatomic ,assign) NSInteger bonusNumber;

@end

@implementation MGBonusViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //分享完毕有新红包之后更新右上角的红包数量
    OBSERVER(HasNewBonusNotification, @selector(loadData));

    [self createBonusView];

    [self createTitleLab];

    [self createNavItem];
    [self createTipsLab];
    
    
//    NSLog(@"%@",NSHomeDirectory());
    
    //首次进入红包界面，显示大红包
    BOOL isFirst=![[[NSUserDefaults standardUserDefaults]objectForKey:@"BonusFirstVisit"] integerValue];
    if (isFirst) {
        NSLog(@"首次进入红包界面");
        UIWindow *window =[UIApplication sharedApplication].keyWindow;
        NewBonus *view =[[NewBonus alloc]initWithFrame:[UIScreen mainScreen].bounds];
        view.topLab.text=[NSString stringWithFormat:@"新增红包功能"];
        [window addSubview:view];
        [view performSelector:@selector(remove) withObject:nil afterDelay:3];
        //记录
        [[NSUserDefaults standardUserDefaults]setObject:@1 forKey:@"BonusFirstVisit"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }else{
        NSLog(@"非首次进入红包界面");
    }
    if([UserModel sharedUser].usertoken){
        //已登录加载数据
        [self loadData];
    }
    
}
-(void)dealloc{
    REMOVEOBSERVER;
}
#pragma mark - 更新右上角的我的红包数量
-(void)loadData{

    self.bonusNumber=0;
    
    [BonusHadle getBonusDataWithStatusfilter:@"" compete:^(id obj) {
//        NSLog(@"所有红包====%@",obj);
        for (NSDictionary *dic in obj[@"data"]) {
           
            if ([dic[@"bonusstatus"] isEqualToString:@"1"]) {
                self.bonusNumber++;

            }
        }
        self.navigationItem.rightBarButtonItem.badgeValue=[NSString stringWithFormat:@"%ld",self.bonusNumber];
    }];
}
-(void)createNavItem{
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    btn.size=CGSizeMake(60, 30);
    btn.titleLabel.font=[UIFont systemFontOfSize:15];
    [btn addTarget:self action:@selector(myBonus) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"我的红包" forState:UIControlStateNormal];
    
    UIBarButtonItem *right =[[UIBarButtonItem alloc]initWithCustomView:btn];
    self.navigationItem.rightBarButtonItem=right;

//    right.badgeValue=[NSString stringWithFormat:@"%ld",self.bonusNumber];
}
-(void)myBonus{
    if ([UserModel sharedUser].usertoken) {
        //已登录，跳转我的红包
        MyBonusViewController *vc=[MyBonusViewController new];
        
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        //未登录,跳转登录
        LoginViewController *vc =[LoginViewController new];
        
        [self.navigationController pushViewController:vc animated:YES];
        
    }
    
}
-(void)createBonusView{

    BonusView *view = [[BonusView alloc]init];

    view.parentController=self;
    __weak  typeof(self) weakSelf = self;

    view.block=^{

        LoginViewController *vc =[LoginViewController new];

        [weakSelf.navigationController pushViewController:vc animated:YES];
        
    };
    [view setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT, 0, 80, 0));
    }];

}

#pragma mark -新浪的分享成功在这里
-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response{
    NSLog(@"分享成功--新浪");
    [ShareManager finishShareTaskWithUrl:SHAREURL(@1)];
}

-(void)createTitleLab{

    WPHotspotLabel*lab=[[WPHotspotLabel alloc]init];
    lab.textAlignment =NSTextAlignmentCenter;

    lab.textColor=[UIColor redColor];

    __weak  typeof(self) weakSelf = self;
    lab.attributedText = [NSAttributedString stringWithText:@"红包内容:任选一种免费看一周"
                                           attributedString:@"红包内容:" fontSize:14.0f color:BrownColor block:^{

                                               [weakSelf dismissViewControllerAnimated:YES completion:^{
                                                   
                                               }];
                                           }];

    [self.view addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-60);
        make.height.mas_equalTo(20);
    }];
    
}
-(void)createTipsLab{

    UIView *backView = [[UIView alloc]init];
    backView.backgroundColor=RGB(230, 230, 230, 1);

    WPHotspotLabel*lab1=[[WPHotspotLabel alloc]initWithFrame:CGRectMake(10, 5, SCREEN_WIDTH-40, 20)];
    lab1.textAlignment =NSTextAlignmentLeft;

    lab1.textColor=[UIColor grayColor];

    __weak  typeof(self) weakSelf = self;
    lab1.attributedText = [NSAttributedString stringWithText:@"领:首次分享，您立即领红包"
                                           attributedString:@"领:" fontSize:14.0f color:[UIColor blackColor] block:^{

                                               [weakSelf dismissViewControllerAnimated:YES completion:^{

                                               }];
                                           }];
    
    [backView addSubview:lab1];


    WPHotspotLabel*lab2=[[WPHotspotLabel alloc]initWithFrame:CGRectMake(10, 25, SCREEN_WIDTH-40, 32)];
    lab2.textAlignment =NSTextAlignmentLeft;

    lab2.textColor=[UIColor grayColor];
    lab2.numberOfLines=0;
    lab2.lineBreakMode=NSLineBreakByWordWrapping;
    lab2.attributedText = [NSAttributedString stringWithText:@"发:免费发，多少好友抢到红包，您再领多少红包"
                                            attributedString:@"发:" fontSize:13.0f color:[UIColor blackColor] block:^{


                                                [weakSelf dismissViewControllerAnimated:YES completion:^{

                                                }];
                                            }];
    
    [backView addSubview:lab2];


    [self.view addSubview:backView];
    [backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view).with.offset(-Margin);
        make.height.mas_equalTo(50);
    }];

}

@end
