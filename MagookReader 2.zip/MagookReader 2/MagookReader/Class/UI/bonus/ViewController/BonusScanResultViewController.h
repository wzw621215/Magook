//
//  BonusScanResultViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/11/7.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "ScanViewController.h"

@interface BonusScanResultViewController : ScanViewController

//@property (nonatomic ,assign) BOOL isLimited;
@end
