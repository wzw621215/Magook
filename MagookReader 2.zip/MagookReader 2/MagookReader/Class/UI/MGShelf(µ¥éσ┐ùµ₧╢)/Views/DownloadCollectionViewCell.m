//
//  DownloadCollectionViewCell.m
//  edit
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 magook.com. All rights reserved.
//

#import "DownloadCollectionViewCell.h"
#import "MGIssueModel.h"
#import "UIImage+WebP.h"
#import "DownloadDataManager.h"
#import "MGLibHandle.h"
#import "UIButton+WebCache.h"

@interface DownloadCollectionViewCell()

@property (weak, nonatomic) IBOutlet UIButton *coverButton;
@property (weak, nonatomic) IBOutlet UILabel *nameLab;
@property (weak, nonatomic) IBOutlet UILabel *issueLab;
@property (weak, nonatomic) IBOutlet UILabel *progressLab;
@end
@implementation DownloadCollectionViewCell

- (IBAction)coverButtonClick:(UIButton *)sender {

    if (self.editing) {
        //处于编辑状态下点击
        self.chooseButton.selected=!self.chooseButton.selected;
    
        if (self.deleteBlock) {
            self.deleteBlock(self.chooseButton.selected,self.model);
        }
    }else{
        //非编辑状态下点击
        NSLog(@"发送通知跳转");
        //发送通知跳转
        POSTER(GoToReadingFromMGShelfNotification, self.model);
    }
}

-(void)awakeFromNib{
    //添加观察者来观察进度
    OBSERVER(UpdateDownloadProgressNotification, @selector(updateDownloadProgress));

    self.progressLab.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.5];
    if (iPad) {
        self.nameLab.font=FONTIPAD;
        self.issueLab.font=FONTIPAD;
        self.progressLab.font=FONTIPAD;
    }
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)updateDownloadProgress{
    
    self.model.downloadedNumber=[[DownloadDataManager sharedManager]upDateModelWithModel:self.model];

    [self updateProgress];

}
- (IBAction)chooseButtonClick:(UIButton *)sender {
    self.chooseButton.selected=!self.chooseButton.selected;

    if (self.deleteBlock) {
        self.deleteBlock(self.chooseButton.selected,self.model);
    }

}
-(void)setEditing:(BOOL)editing{

    _editing=editing;

//    CATransform3D transform;
//    transform = CATransform3DMakeRotation(-0.08, 0, 0, 1.0);
//    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform"];

//    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
//    animation.fromValue=@(-0.08);
//    animation.toValue=@0.08;
////    animation.toValue = [NSValue valueWithCATransform3D:transform];
//    animation.autoreverses = YES;
//    animation.duration = 0.1;
//    animation.repeatCount = 10000;
//    animation.delegate = self;


    self.chooseButton.hidden=!_editing;
//    if (editing) {
//        self.chooseButton.hidden=NO;
//         [[self layer] addAnimation:animation forKey:@"wiggleAnimation"];
//    }else{
//        self.chooseButton.hidden=YES;
//        [[self layer] removeAllAnimations];
//    }
}

-(void)setModel:(MGIssueModel *)model{

    _model=model;


//    if (model.downloadedNumber>0) {

//        NSString *documents=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
//        NSString *filePath=[documents stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@_%@/1.png",DownloadDirectoryName,model.magazinename,model.issuename]];
//        
////        UIImage *image =[UIImage imageWithWebP:filePath];
//        UIImage *image =[UIImage imageWithContentsOfFile:filePath];
    
        [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
            [self.coverButton sd_setImageWithURL:[NSURL URLWithString:url] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"封面"]];
        }];

//        [self.coverButton setImage:image forState:UIControlStateNormal];
        self.nameLab.text=model.magazinename;
        self.issueLab.text=model.issuename;

    NSInteger downloadNumber = [[DownloadDataManager sharedManager]upDateModelWithModel:model];
        if (downloadNumber==[model.count integerValue]) {
            self.progressLab.hidden=YES;
        }else{
            self.progressLab.hidden=NO;
            [self updateProgress];
        }

//    }

}
-(void)updateProgress{
    CGFloat progress=(float)self.model.downloadedNumber/[self.model.count integerValue];

    self.progressLab.text=[NSString stringWithFormat:@"已下载%.1f%%",progress*100];

    if (progress==1) {
        self.progressLab.hidden=YES;
    }
}
@end
