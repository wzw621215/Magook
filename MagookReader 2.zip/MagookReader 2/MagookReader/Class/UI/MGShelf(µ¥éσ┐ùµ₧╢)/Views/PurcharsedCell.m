//
//  PurcharsedCell.m
//  MagookReader
//
//  Created by tailhuang on 15/10/13.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "PurcharsedCell.h"
#import "MGIssueModel.h"
#import "UIImage+WebP.h"
#import "MGLibHandle.h"
#import "UIButton+WebCache.h"
#import "DXAlertView.h"
#import "ShoppingCartDataManager.h"
@interface PurcharsedCell()
@property (weak, nonatomic) IBOutlet UIButton *coverButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UIImageView *imgV;
@property (weak, nonatomic) IBOutlet UIImageView *magazineNewImageView;
@property (nonatomic ,assign) UserPermissionStyle style;

@end
@implementation PurcharsedCell
-(void)awakeFromNib{
    if (iPad) {
        self.titleLab.font=FONTIPAD;
    }
}
- (IBAction)purchasedCellClick:(id)sender {

//    UserPermissionStyle style=[AppController checkPermissionWithMagazineID:self.model.magazineid];
        if (self.style==UserPermissionStyleOutOfDate) {
            ShoppingCartDataManager *manager =[ShoppingCartDataManager sharedManager];
        BOOL isExist                    = [manager isExistsDataWithModel:self.model];
        if (!isExist) {
            [manager insertDataWithModel:self.model];
            POSTER(ShoppingCartDidChangeNotification, nil);

        }
        DXAlertView *alert              = [[DXAlertView alloc] initWithTitle:@"温馨提示" contentText:@"该杂志阅读权限已到期\n已为您添加到购物车" leftButtonTitle:@"暂不" rightButtonTitle:@"去结算"];
        [alert show];
        alert.leftBlock                 = ^() {
            NSLog(@"暂不");
        };
        alert.rightBlock                = ^() {
            NSLog(@"去结算");
          //跳转到购物车
            POSTER(GoToShoppingCartFromShelfNotification, nil);
        };
        alert.dismissBlock              = ^() {
            NSLog(@"关闭");
        };

    }else{

        POSTER(GoToReadingFromMGShelfNotification, self.model);
    }
}

-(void)setModel:(MGIssueModel *)model{

    _model                          = model;
    if (model.isNewMagazine) {

        self.magazineNewImageView.image=[UIImage imageNamed:@"更新"];
    }else{
    self.magazineNewImageView.image = nil;

    }
    __weak typeof(self) weakSelf = self;
    [self checkPermissionWithModel:model complete:^(UserPermissionStyle style) {
        weakSelf.style=style;
        if (style==UserPermissionStyleOutOfDate) {
            weakSelf.imgV.image=[UIImage imageNamed:@"到期1"];
        }else{
        weakSelf.imgV.image                 = nil;

        }
    }];


    if (model.downloadedNumber>0) {

        NSString *documents=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
        NSString *filePath=[documents stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@_%@/1.png",DownloadDirectoryName,model.magazinename,model.issuename]];

    UIImage *image                  = [UIImage imageWithContentsOfFile:filePath];

        [self.coverButton setImage:image forState:UIControlStateNormal];

    }else{
        [MGLibHandle getMGListCoverWithPath:model.path magezineID:model.magazineid issueid:model.issueid completionHandler:^(NSString *url) {
            [self.coverButton sd_setImageWithURL:[NSURL URLWithString:url] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"封面"]];
        }];

    }

    self.titleLab.text              = model.magazinename;



}
-(void)checkPermissionWithModel:(MGIssueModel *)model complete:(void (^)(UserPermissionStyle style))complete{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        UserPermissionStyle style=[AppController checkPermissionWithMagazineID:model.magazineid];

        dispatch_async(dispatch_get_main_queue(), ^{
            complete(style);
        });

    });
}
@end
