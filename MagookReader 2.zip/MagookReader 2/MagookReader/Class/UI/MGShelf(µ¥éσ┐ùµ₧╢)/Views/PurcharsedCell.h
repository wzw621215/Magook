//
//  PurcharsedCell.h
//  MagookReader
//
//  Created by tailhuang on 15/10/13.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface PurcharsedCell : UICollectionViewCell
@property (nonatomic, strong) MGIssueModel *model;

@end
