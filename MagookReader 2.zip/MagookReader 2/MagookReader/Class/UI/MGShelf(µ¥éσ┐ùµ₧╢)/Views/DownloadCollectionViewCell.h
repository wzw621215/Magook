//
//  DownloadCollectionViewCell.h
//  edit
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 magook.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface DownloadCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *chooseButton;
@property (nonatomic, assign) BOOL editing;
@property (nonatomic, copy) void (^deleteBlock)(BOOL isChosen,MGIssueModel *model);
@property (nonatomic, strong) MGIssueModel *model;
@end
