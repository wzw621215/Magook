//
//  ZBSlideView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZBSlideView : UIView
@property (nonatomic, strong) NSArray *viewControllers;

@property (nonatomic, strong) UIColor *themeColor;

@end
