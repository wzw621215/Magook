//
//  UserPermissionModel.m
//  MagookReader
//
//  Created by tailhuang on 15/10/12.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "PurchasedModel.h"

@implementation PurchasedModel

@end
