//
//  MGShelfHandle.h
//  MagookReader
//
//  Created by tailhuang on 15/10/13.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
typedef void(^Success)(MGIssueModel *model);
typedef void(^Complete)(NSArray *array);
@interface MGShelfHandle : NSObject
+(void)getPurchasedDataComplete:(Complete)complete;
+(void)getMagazinedataWithMagazineid:(NSNumber *)magazineid success:(Success)success;
+(void)getMagazinedataWithArray:(NSArray *)magazineidArray Complete:(Complete)complete;
@end
