//
//  MGShelfViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGShelfViewController.h"
#import "MGNavigationConroller.h"
#import "PurchasedViewController.h"
#import "RecentReadingViewController.h"
#import "DownloadViewController.h"
#import "ZBSlideView.h"
#import "BonusHadle.h"
#import "NewBonus.h"
#import "ReadingViewController.h"
#import "DownloadDataManager.h"
#import "MGIssueModel.h"
@interface MGShelfViewController ()
{
    UIBarButtonItem *downloadItem;
}
@property (nonatomic, strong) PurchasedViewController *purchased;
@property (nonatomic, strong) DownloadViewController  *download;
@property (nonatomic, strong) RecentReadingViewController *recent;
@property (nonatomic ,weak) ZBSlideView *slideView;
@end

@implementation MGShelfViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

    [self.recent viewWillAppear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(ZBSlideViewDidScrollNotification, @selector(ZBSlideViewDidScroll:));

    OBSERVER(GoToReadingFromMGShelfNotification, @selector(GoToReadingFromMGShelf:));

    OBSERVER(GoToShoppingCartFromShelfNotification, @selector(goToShoppingCartFromShelf));

    self.view.backgroundColor           = [UIColor whiteColor];

    [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeSearch inVc:self];

    [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeScan inVc:self];

    [self createViewConrollers];
    
    if ([UserModel sharedUser].usertoken&&ENABLEBONUS) {
        
        [self checkNewBonus];
    }

}
#pragma mark - 检测是否有新红包
-(void)checkNewBonus{
    [BonusHadle getBonusDataWithStatusfilter:@0 compete:^(id obj) {
        NSLog(@"在shelf检测新红包完成");
        NSArray *newBonusArray =[NSArray arrayWithArray:obj[@"data"]];
        NSLog(@"新红包====%@",newBonusArray);
        //有新红包
        if (newBonusArray.count) {
            NSLog(@"有新红包");
            [NewBonus showWithNumber:@(newBonusArray.count)];
        }
    }];

}
//跳转购物车
-(void)goToShoppingCartFromShelf{
    self.tabBarController.selectedIndex = self.tabBarController.viewControllers.count-2;
}
//跳转阅读
-(void)GoToReadingFromMGShelf:(NSNotification *)not{
    MGIssueModel *model                 = not.object;
    NSInteger downloadNumber =[[DownloadDataManager sharedManager]upDateModelWithModel:model];
    if (([AppController sharedController].netWorkStatus)||(downloadNumber>0)) {
        
        ReadingViewController *vc =[ReadingViewController new];
        vc.model                            = model;
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        [ZBHud showErrorWithMessage:@"网络连接失败!"];
    }
    
}

-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)ZBSlideViewDidScroll:(NSNotification *)not{

    static CGFloat lastX                = 0;
    CGFloat x=[not.object floatValue];

    //如果未换页，则不改变
    if (x==lastX) {
        return;
    }
    if (x==0) {
//        NSLog(@"已购买");
        [(MGNavigationConroller*)self.navigationController clearItems];

        [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeSearch inVc:self];

        [(MGNavigationConroller*)self.navigationController addItemWithType:MGRightItemTypeScan inVc:self];
        //如果在编辑状态，则停止
        [self.download endEdit];
    lastX                               = x;

    }else if(x==1){
//        NSLog(@"最近阅读");
        UIBarButtonItem *recentItem =[UIBarButtonItem itemWithTarget:self action:@selector(recentDelete) image:@"杂志架_删除" highImage:@"杂志架_删除_checked"];

        self.navigationItem.rightBarButtonItems=@[recentItem];
        //如果在编辑状态，则停止
        [self.download endEdit];
    lastX                               = x;
    }else if(x==2){
//        NSLog(@"已下载");
        downloadItem=[UIBarButtonItem itemWithTarget:self action:@selector(downloadDelete) image:@"杂志架_删除" highImage:@"杂志架_删除_checked"];
        self.navigationItem.rightBarButtonItems=@[downloadItem];
    lastX                               = x;
    }
//    lastX=x;
}
-(void)recentDelete{
    NSLog(@"最近阅读删除");
    [self.recent cleanRecent];
}
-(void)downloadDelete{
//    NSLog(@"下载删除");
    if([[DownloadDataManager sharedManager]allData].count >0){
    UIBarButtonItem *cancelItem =[UIBarButtonItem itemWithTarget:self action:@selector(downloadDeleteCancel) image:@"btn_cancel_normal" highImage:@"btn_cancel_pressed"];
    UIBarButtonItem *cofirmItem =[UIBarButtonItem itemWithTarget:self action:@selector(downloadCofirmCofirm) image:@"btn_confirm_normal" highImage:@"btn_confirm_pressed"];
    [self.download beginEdit];
    self.navigationItem.rightBarButtonItems=@[cofirmItem,cancelItem];
    }

}

-(void)downloadDeleteCancel{
//    NSLog(@"取消删除");
    [self.download cancelDelete];
    self.navigationItem.rightBarButtonItems=@[downloadItem];
}
-(void)downloadCofirmCofirm{
//    NSLog(@"确定删除");
    [self.download cofirmDelete];
    self.navigationItem.rightBarButtonItems=@[downloadItem];
}
#pragma mark -创建视图控制器
-(void)createViewConrollers{

    self.purchased                      = [PurchasedViewController new];

    self.recent                         = [RecentReadingViewController new];

    self.download                       = [DownloadViewController   new];

    self.purchased.title   =@"已购买";
    self.recent.title      =@"最近阅读";
    self.download.title    =@"已下载";


    ZBSlideView *slideView=[[ZBSlideView alloc]init];//WithFrame:CGRectMake(0, NAV_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-NAV_HEIGHT-TAB_HEIGHT)
    slideView.themeColor                = COLOR;

//    self.view.frame                     = CGRectMake(0, NAV_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-NAV_HEIGHT-TAB_HEIGHT);


    slideView.viewControllers=@[self.purchased,self.recent,self.download];

    [self.view addSubview:slideView];

    self.slideView                      = slideView;


    UIEdgeInsets padding                = UIEdgeInsetsMake(NAV_HEIGHT, 0, TAB_HEIGHT, 0);
    [slideView mas_makeConstraints:^(MASConstraintMaker *make) {
       make.edges.equalTo(self.view).with.insets(padding);
    }];

}

@end
