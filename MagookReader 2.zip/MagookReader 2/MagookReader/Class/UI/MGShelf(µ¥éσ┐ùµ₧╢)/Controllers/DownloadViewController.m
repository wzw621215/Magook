//
//  CollectionViewController.m
//  edit
//
//  Created by tailhuang on 15/10/11.
//  Copyright © 2015年 magook.com. All rights reserved.
//

#import "DownloadViewController.h"
#import "DownloadCollectionViewCell.h"
#import "MGIssueModel.h"
#import "DownloadDataManager.h"
#import "DownloadManager.h"
#import "DefaultPageView.h"

#define  CELL_WIDTH  ([UIScreen mainScreen].bounds.size.width-50)/4
#define  CELL_HEIGHT (CELL_WIDTH/0.618)-20+10+20+10+10
@interface DownloadViewController ()
{
    NSMutableArray *array;
    NSMutableIndexSet *indexSet;
}
@property (nonatomic, assign)BOOL isEdit;
@property (nonatomic, strong)DefaultPageView *defaultPage;

@end

@implementation DownloadViewController

static NSString * const reuseIdentifier = @"DownloadCell";
#pragma mark -懒加载defaultePage
-(DefaultPageView *)defaultPage{
    if (!_defaultPage) {
        _defaultPage= LOADNIBNAME(@"DefaultPageView");
        _defaultPage.frame=self.view.bounds;
        _defaultPage.defaultImageView.image=[UIImage imageNamed:@"杂志架_空"];
        _defaultPage.defaultLab.text=@"没有下载的杂志";
    }
    return _defaultPage;
}

- (void)viewDidLoad {
    [super viewDidLoad];

//读取本地数据
    [self loadDataFromLocal];

    OBSERVER(NewDownloadMissionIsBuildNotification, @selector(newDownloadMissionIsBuild:));
    OBSERVER(LogOutNotification, @selector(userDidLogout));
    indexSet=[NSMutableIndexSet new];
    UINib *cellNib = [UINib nibWithNibName:@"DownloadCollectionViewCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:@"DownloadCell"];
    self.collectionView.backgroundColor=BKCOLOR;
}

#pragma mark -重新登录-从本地读数据
-(void)loadDataFromLocal{
    NSLog(@"从本地读取下载数据");
    self.dataArray=[NSMutableArray arrayWithArray:[[DownloadDataManager sharedManager]allData]];
    if (self.dataArray.count) {
        if (_defaultPage) {
            [self.defaultPage removeFromSuperview];
            self.defaultPage=nil;
        }
        [self.collectionView reloadData];
    }else{
        [self.view addSubview:self.defaultPage];
    }
}
#pragma mark -新增任务
-(void)newDownloadMissionIsBuild:(NSNotification *)note{
    NSLog(@"收到新任务，刷新");
    [self.dataArray addObject:note.object];
    NSIndexPath *indexPath=[NSIndexPath indexPathForItem:self.dataArray.count-1 inSection:0];
    [self.collectionView insertItemsAtIndexPaths:@[indexPath]];
    if (_defaultPage) {
        [self.defaultPage removeFromSuperview];
        _defaultPage=nil;
    }
}
-(void)dealloc{
    REMOVEOBSERVER;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray=[NSMutableArray new];
    }
    return _dataArray;
}
#pragma mark -四个方法
-(void)beginEdit{
    self.isEdit=YES;
}
-(void)endEdit{
    self.isEdit=NO;
}
//取消删除
-(void)cancelDelete{
    self.isEdit=NO;
    [indexSet removeAllIndexes];
}

-(void)cofirmDelete{
    self.isEdit = NO;
    NSString *documents=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];

    NSFileManager *fileManager=[NSFileManager defaultManager];

    DownloadDataManager *downloadDataManager=[DownloadDataManager sharedManager];

    NSArray *temp=[self.dataArray objectsAtIndexes:indexSet];

    for (MGIssueModel *model in temp) {
    NSString *filePath=[documents stringByAppendingPathComponent:[NSString stringWithFormat:@"Download/%@_%@",model.magazinename,model.issuename]];
        [[DownloadManager sharedManager]pauseWithModel:model];
        [downloadDataManager deleteDataWithModel:model];
        [fileManager removeItemAtPath:filePath error:nil];
        [[DownloadManager sharedManager]cleanDataWithModel:model];
    }
    [self.dataArray removeObjectsAtIndexes:indexSet];
    [indexSet removeAllIndexes];
    [self.collectionView reloadData];

}
-(void)userDidLogout{
    for (MGIssueModel *model in self.dataArray) {
        [[DownloadManager sharedManager]pauseWithModel:model];
    }
}
-(void)setIsEdit:(BOOL)isEdit{
    _isEdit=isEdit;
    [self.collectionView reloadData];
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    DownloadCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    cell.deleteBlock=^(BOOL isChosen,MGIssueModel *model){
        if (isChosen) {
            [indexSet addIndex:[self.dataArray indexOfObject:model]];
        }else{
            [indexSet removeIndex:[self.dataArray indexOfObject:model]];
        }
    };
    cell.editing=self.isEdit;
    cell.chooseButton.selected=[indexSet containsIndex:indexPath.row];
    cell.model=self.dataArray[indexPath.row];
    
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat LabH =40;
    CGFloat PurchaseCellPW = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat PurchaseCellPH = PurchaseCellPW/GoldenSection+LabH;
    CGFloat PurchaseCellLW = (MAXSCREEN-(ItemL+1)*Margin)/ItemL;
    CGFloat PurchaseCellLH = PurchaseCellLW/GoldenSection+LabH;
    CGSize size;

    if (PORTRAIT){
        size=CGSizeMake(PurchaseCellPW, PurchaseCellPH);
    }else{
        size=CGSizeMake(PurchaseCellLW, PurchaseCellLH);
    }
    
    return size;
}


@end
