//
//  PurchasedViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

//#import "BasicViewController.h"
#import "BasicCollectionViewController.h"
@interface PurchasedViewController : BasicCollectionViewController

@end
