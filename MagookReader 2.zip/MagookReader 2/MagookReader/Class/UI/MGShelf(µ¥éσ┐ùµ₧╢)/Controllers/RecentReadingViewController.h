//
//  RecentReadingViewController.h
//  MagookReader
//
//  Created by tailhuang on 15/9/11.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
#import "BasicCollectionViewController.h"
@interface RecentReadingViewController : BasicCollectionViewController
//清空最近阅读
-(void)cleanRecent;
@end
