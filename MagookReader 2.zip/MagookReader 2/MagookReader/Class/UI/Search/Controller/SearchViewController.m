//
//  SearchViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchCollectionViewController.h"
#import "SearchHandle.h"
#import "ReadingViewController.h"
#import "BonusSearchViewController.h"
#import "MGIssueModel.h"
#import "PayHandle.h"
@interface SearchViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    UITableView *_historyTB;

    NSMutableArray *_historyDataArray;

    UITextField *_searchTF;
}
@property (nonatomic, strong) SearchCollectionViewController *collectionVC;
@property (nonatomic ,strong) BonusSearchViewController *bonusVC;
@property (nonatomic ,weak) UIButton *exchangeButton;
@property (nonatomic ,assign) NSNumber* total;
@property (nonatomic ,strong) NSMutableArray *bonusExchangeArray;
@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(StepValueDidChageNotification, @selector(stepValueDidChange:));
    _historyDataArray = [NSMutableArray array];
    [self loadHistoryData];
    [self createNav];
    [self createHistoryTableView];
}
#pragma mark -监听stepper数据
-(void)stepValueDidChange:(NSNotification *)not{
    
    NSInteger count =[not.userInfo[@"count"] integerValue];
    MGIssueModel *model=not.object;
    
    if (count>0) {
        NSDictionary *d=@{
                          @"magazineid":model.magazineid,
                          @"buypackageid":BUYPACKAGEBONUS,
                          @"quantity":[NSNumber numberWithInteger:count]
                          };
        [self.dataDic setValue:d forKey:[NSString stringWithFormat:@"%@",model.magazineid]];
    }else{
        if ([[self.dataDic allKeys] containsObject:[NSString stringWithFormat:@"%@",model.magazineid]]) {
            [self.dataDic removeObjectForKey:[NSString stringWithFormat:@"%@",model.magazineid]];
        }
        
    }
    //
    int total=0;
    NSLog(@"searchdic==========%@",[self.dataDic allValues]);
    for (NSDictionary *d in [self.dataDic allValues]) {
        NSNumber *quantity=d[@"quantity"];
        total += [quantity integerValue];
    }

    self.bonusExchangeArray=[NSMutableArray arrayWithArray:[self.dataDic allValues]];
    
    
    self.total=@(total);
    if (total) {
        self.exchangeButton.enabled=YES;
        [self.exchangeButton setTitle:[NSString stringWithFormat:@"确认兑换（%@）",self.total] forState:UIControlStateNormal];
        self.exchangeButton.backgroundColor=[UIColor redColor];
    }else{
        self.exchangeButton.enabled=NO;
        
        self.exchangeButton.backgroundColor=RGB(200, 200, 200, 1);
    }
    
    //达到限制条件，禁用增加按钮
    //小于限制条件，解除禁用
    
    
    POSTER(LimitedStepNotification, total>=self.bonusNumber?@0:@1);
    
}
#pragma mark - 兑换
-(void)exchangeButtonClick{
    
    [ZBHud showActivityWithMessage:@"正在提交订单"];
    //获取订单号
    
    NSDictionary *dic=[PayHandle commitBonusOrderWithMagdata:self.bonusExchangeArray ];
    NSString *orderNumber=dic[@"orderno"];
    
    //红包支付
    [PayHandle payBonusWithOrderNumber:orderNumber amount:self.total finish:^(id object) {
        
        //订单确认
        [PayHandle confirmOrderWithOdernumber:orderNumber complete:^(id obj) {
            
            NSNumber *finish=obj[@"data"][@"finish"];
            switch ([finish integerValue]) {
                case 0:
                    //支付未完成
                    [ZBHud showInfo:@"支付未完成"];
                    break;
                case 1:
                    //完成(iOS、麦豆支付)
                    [ZBHud showSuccessWithMessage:@"兑换成功"];
                    break;
                case 2:
                    //等待支付处理
                    [ZBHud showInfo:@"订单等待处理"];
                    break;
                    
                default:
                    break;
            }
            //兑换完毕直接返回首页
            [self.navigationController popToRootViewControllerAnimated:YES];
        }];
        
    }];
    
}
#pragma mark - 读取历史记录
-(void)loadHistoryData{

    _historyDataArray= [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"searchHistory"]];

}
-(void)createNav{

    //取消按钮
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancel)];
    //输入框
    CGFloat tfW=0.0;
    CGFloat btnW=iPad?80:70;
    if (PORTRAIT) {
        tfW=MINSCREEN-btnW;
    }else{
        tfW=MAXSCREEN-btnW-Margin;
    }
    
    _searchTF=[[UITextField alloc]initWithFrame:CGRectMake(Margin, Margin,tfW, 30)];
    _searchTF.font=FONT;

    _searchTF.delegate = self;

//    _searchTF.borderStyle=UITextBorderStyleNone;
    _searchTF.backgroundColor=BKCOLOR;
    [_searchTF cutCornerRadius:5];
    _searchTF.tintColor=[UIColor blackColor];
    //左视图
    UIImageView *scope=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 30, 20)];

    scope.contentMode=UIViewContentModeScaleAspectFit;

    [scope setImage:[UIImage imageNamed:@"搜索框_搜索"]];

    _searchTF.leftView=scope;

    _searchTF.clearsOnBeginEditing=YES;
    _searchTF.clearButtonMode=UITextFieldViewModeWhileEditing;
    _searchTF.placeholder=@"请输入要搜索的内容";

    _searchTF.leftViewMode=UITextFieldViewModeAlways;

    _searchTF.returnKeyType=UIReturnKeySearch;

    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_searchTF];

  
    [_searchTF becomeFirstResponder];
}
-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
    CGFloat btnW=iPad?80:70;
    if (UIInterfaceOrientationIsPortrait(toInterfaceOrientation)) {
       _searchTF.frame= CGRectMake(Margin, Margin,MINSCREEN-btnW, 30);
    }else{
        _searchTF.frame= CGRectMake(Margin, Margin,MAXSCREEN-btnW-Margin, 30);
    }
}
//点击搜索按钮
-(BOOL)textFieldShouldReturn:(UITextField *)textField{

    [self.view endEditing:YES];
    if (_searchTF.text==nil||_searchTF.text.length==0) {
    [ZBHud showErrorWithMessage:@"搜索内容为空！"];
    }else{
    [self search];
    }
    return YES;
}


#pragma  mark - 搜索按钮点击事件
-(void)search{

    [_searchTF resignFirstResponder];

    //先处理本地数据
    if (_searchTF.text!=nil) {

        //如果数组中已经存在该搜索记录，就先删除旧记录
        for (int i=0; i < _historyDataArray.count; i++) {
            if ([_historyDataArray[i] isEqualToString:_searchTF.text]) {

                [_historyDataArray removeObjectAtIndex:i];

            }
        }

        //再把新的搜索记录放到最前
        [_historyDataArray insertObject:_searchTF.text atIndex:0];

#pragma mark -用NSUSerDefaults进行本地存储

        [[NSUserDefaults standardUserDefaults]setObject:_historyDataArray forKey:@"searchHistory"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    [_historyTB reloadData];


    //再进行网络搜索

    [self loadSeachDataWithString:_searchTF.text];

    //把搜索框置空
    //    _searchTF.text=nil;
    
}
-(void)loadSeachDataWithString:(NSString *)string{

    [SearchHandle searchWithString:string CompletionHandler:^(NSArray *array) {
        if (array) {
            [_historyTB removeFromSuperview];
            _historyTB=nil;
            //创建collectionView
            if (self.isBonus) {
                [self createBonusCV];
                self.bonusVC.dataArray=[NSMutableArray arrayWithArray:array];
            }else{
            [self createSearchCV];
            //加载数据
            self.collectionVC.dataArray=[NSMutableArray arrayWithArray:array];
            }
        }

    }];


}
-(void)cancel{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)createHistoryTableView{

    _historyTB = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];

    _historyTB.delegate = self;

    _historyTB.dataSource = self;

    _historyTB.backgroundColor=[UIColor clearColor];
    _historyTB.tableFooterView=[[UIView alloc]init];

    [self.view addSubview:_historyTB];
    [_historyTB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(0, 0, 0, 0));
    }];

}
-(void)createBonusCV{
    [self createBottomView];
    self.bonusVC=[[BonusSearchViewController alloc]init];
    NSLog(@"self.total-------%@---self.bonusNumber--%d",self.total,self.bonusNumber);
    self.bonusVC.isLimited=[self.total integerValue]<self.bonusNumber;
    
    [self.view addSubview:self.bonusVC.view];
    
    [self.bonusVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT, 0, TAB_HEIGHT, 0));
    }];
    
}
-(void)createBottomView{
    UIButton *exchangeButton=[UIButton buttonWithType:UIButtonTypeCustom];
    //    exchangeButton.frame=CGRectMake(0, SCREEN_HEIGHT-50, SCREEN_WIDTH, 50);
    
     [exchangeButton setTitle:@"请选择要兑换的杂志" forState:UIControlStateDisabled];
    NSArray *countArray=[[self.dataDic allValues] valueForKeyPath:@"quantity"];
    NSLog(@"%@----search.dataDic",self.dataDic);
    NSInteger total=0;
    for (NSNumber *quantity in countArray) {
        total +=[quantity integerValue];
    }
    self.total=@(total);
    NSLog(@"total==========%ld",total);
    if (total>0) {
        exchangeButton.backgroundColor=[UIColor redColor];
        [exchangeButton setTitle:[NSString stringWithFormat:@"确认兑换（%ld）",total] forState:UIControlStateNormal];
        exchangeButton.enabled=YES;
        
    }else{
        exchangeButton.backgroundColor=RGB(200, 200, 200, 1);
        exchangeButton.enabled=NO;
       
    }
    
    [exchangeButton addTarget:self action:@selector(exchangeButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:exchangeButton];
    
    [exchangeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.bottom.equalTo(self.view);
        make.height.mas_equalTo(TAB_HEIGHT);
    }];
    self.exchangeButton=exchangeButton;
}

-(void)createSearchCV{
    self.collectionVC=[[SearchCollectionViewController alloc]init];

    __weak typeof(self)  weakSelf=self;
    self.collectionVC.block=^(MGIssueModel *model){

        if ([AppController sharedController].netWorkStatus) {
            ReadingViewController*vc=[ReadingViewController new];
            vc.model=model;
            
            [weakSelf.navigationController pushViewController:vc animated:YES];
        }else{
            [ZBHud showErrorWithMessage:@"网络连接失败!"];
        }
        
    };

    [self.view addSubview:self.collectionVC.view];
    [self.collectionVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(NAV_HEIGHT, 0, 0, 0));
    }];

}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 44;
}
-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{

    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];


    UILabel *lab;

    if (_historyDataArray.count) {
        if (lab) {
            [lab removeFromSuperview];
        }

        UIButton *button = [self createHistoryFooterButton];
        [footView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(footView);
            make.size.mas_equalTo(CGSizeMake(120, 20));
        }];
        
    }else{
        if (!lab) {
            lab=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
            lab.text=@"无历史记录";
            lab.font=FONT;
            lab.textAlignment=NSTextAlignmentCenter;

        }
        [footView addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(footView);
            make.size.mas_equalTo(CGSizeMake(200, 20));
        }];
    }


    return footView;
}
#pragma mark -创建清除历史记录的尾视图
-(UIButton*)createHistoryFooterButton{


    UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];

    button.frame=CGRectMake((SCREEN_WIDTH-100)/2, 0, 100, 30);

    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.titleLabel.font=FONT;
    [button setTitle:@"清除历史记录" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(clearHistory) forControlEvents:UIControlEventTouchUpInside];

    [button cutCornerRadius:5];

    button.layer.borderWidth=1;

    button.layer.borderColor=[[UIColor grayColor]CGColor];

    return button;

}

#pragma  mark -清除历史记录
-(void)clearHistory{

    [_historyDataArray removeAllObjects];

    [[NSUserDefaults standardUserDefaults]setObject:_historyDataArray forKey:@"searchHistory"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [_historyTB reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _historyDataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{


    static NSString *cellID=@"searchHistoryID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];

    if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
    cell.backgroundColor=[UIColor clearColor];
    cell.textLabel.text=_historyDataArray[indexPath.row];
    cell.textLabel.font=FONT;
    cell.textLabel.textColor=[UIColor blackColor];

    return cell;


}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 44;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [_searchTF resignFirstResponder];
    [self loadSeachDataWithString:_historyDataArray[indexPath.row]];

}
@end
