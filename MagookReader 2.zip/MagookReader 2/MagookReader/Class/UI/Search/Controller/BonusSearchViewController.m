//
//  BonusSearchViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/7.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BonusSearchViewController.h"

#import "ExchangeCell.h"

@interface BonusSearchViewController ()

@end

@implementation BonusSearchViewController

static NSString * const reuseIdentifier = @"ExchangeCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(LimitedStepNotification, @selector(limitDidChange:));
    
    UINib *cellNib = [UINib nibWithNibName:@"ExchangeCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];

}
-(void)limitDidChange:(NSNotification *)noti{
    self.isLimited=[noti.object integerValue];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ExchangeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    if (self.dataArray.count) {
        cell.model=self.dataArray[indexPath.row];
    }
    NSLog(@"self.isLimited=====%d",self.isLimited);
    cell.stepper.incrementButton.enabled=self.isLimited;
    return cell;
}

@end

