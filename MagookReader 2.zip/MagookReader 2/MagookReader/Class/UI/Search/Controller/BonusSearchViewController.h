//
//  BonusSearchViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/11/7.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "SearchCollectionViewController.h"
@interface BonusSearchViewController : SearchCollectionViewController
//@property (nonatomic ,strong) NSMutableArray *dataArray;
@property (nonatomic ,assign) BOOL isLimited;
@end
