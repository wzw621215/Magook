//
//  DefaultPageView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "DefaultPageView.h"
@interface DefaultPageView()


@end
@implementation DefaultPageView

-(id)initWithCoder:(NSCoder *)aDecoder{

    if (self=[super initWithCoder:aDecoder]) {

    }
    return self;
}
-(void)awakeFromNib{
    self.button.layer.borderWidth=1;
    self.button.layer.borderColor=[[UIColor blackColor]CGColor];
    [self.button cutCornerRadius:5];

}

- (IBAction)lookButtonClick:(id)sender {

    //发送跳转到杂志库页面的通知

    POSTER(TranstoMGLibNotification, nil);

}


@end
