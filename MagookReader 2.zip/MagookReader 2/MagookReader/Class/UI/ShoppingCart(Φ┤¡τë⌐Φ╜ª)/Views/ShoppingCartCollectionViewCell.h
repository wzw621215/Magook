//
//  ShoppingCartCollectionViewCell.h
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MGIssueModel;
@interface ShoppingCartCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong)MGIssueModel *model;
@property (nonatomic, copy)void (^block)(MGIssueModel *);
@end
