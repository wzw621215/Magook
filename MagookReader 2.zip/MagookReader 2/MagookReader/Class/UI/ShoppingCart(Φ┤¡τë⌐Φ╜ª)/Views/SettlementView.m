//
//  SettlementView.m
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "SettlementView.h"
#import "ShoppingCartDataManager.h"
@interface SettlementView()
@property (weak, nonatomic) IBOutlet UILabel *totalLab;
@property (weak, nonatomic) IBOutlet UILabel *addUpLab;
@property (weak, nonatomic) IBOutlet UILabel *benefitsLab;
@property (weak, nonatomic) IBOutlet UIButton *settleMentButton;

@end
@implementation SettlementView
- (IBAction)settleMentButtonClick:(UIButton *)sender {
//    NSLog(@"结算%@",[NSNumber numberWithInteger:[self totalPrice]]);
    if (self.settleBlock) {
        self.settleBlock([self totalPrice],[[[ShoppingCartDataManager sharedManager]allData] count]);
    }
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    if (self=[super initWithCoder:aDecoder]) {
        OBSERVER(ShoppingCartDidChangeNotification, @selector(configData));

    }
    return self;
}
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)awakeFromNib{
    [self configData];
   }
-(void)configData{

    NSInteger count =[[[ShoppingCartDataManager sharedManager]allData] count];
    NSInteger totalPrice = [self totalPrice];
    NSInteger addUpPrice = count*30;
//    NSLog(@"%ld,%ld,%ld",count,totalPrice,addUpPrice);
    self.totalLab.text=[NSString stringWithFormat:@"合计：%@元",[NSNumber numberWithInteger:totalPrice]];

    self.addUpLab.text=[NSString stringWithFormat:@"总额：%@元",[NSNumber numberWithInteger:addUpPrice]];

    self.benefitsLab.text=[NSString stringWithFormat:@"优惠：%@元",[NSNumber numberWithInteger:(addUpPrice-totalPrice)]];

    [self.settleMentButton setTitle:[NSString stringWithFormat:@"去结算（%@）",[NSNumber numberWithInteger:count]] forState:UIControlStateNormal];

}
-(NSInteger )totalPrice{
    NSInteger count =[[[ShoppingCartDataManager sharedManager]allData] count];
    NSArray *array=[self caculateFeeWithCount:count];
    NSInteger sum = 0;
    NSInteger a[4]={30,98,188,348};


    for (int i=0; i<array.count; i++) {
        NSInteger n =[array[i] integerValue];

        sum=n*a[i]+sum;

    }

    return sum;

}

//订单金额算法
-(NSArray *)caculateFeeWithCount:(NSInteger)count{
    NSInteger a[4]={20,10,5,1};
    NSInteger b[4];

    NSMutableArray *array =[NSMutableArray new];

    for (int i=0 ;i<4;i++) {

        b[i]= count/a[i];
        count%=a[i];
    }

    for (int i=3; i>=0; i--) {
        [array addObject:@(b[i])];
    }
    return array;
    
}

@end
