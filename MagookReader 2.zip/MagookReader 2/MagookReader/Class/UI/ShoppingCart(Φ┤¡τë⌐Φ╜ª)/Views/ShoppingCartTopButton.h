//
//  ShoppingCartTopButton.h
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShoppingCartTopButton : UIButton
@property (nonatomic, strong) UILabel *lab1;
@property (nonatomic, strong) UILabel *lab2;
@end
