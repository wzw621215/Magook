//
//  ShoppingCartCollectionViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/14.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ShoppingCartCollectionViewController.h"
#import "ShoppingCartCollectionViewCell.h"
#import "MGIssueModel.h"
#import "ShoppingCartDataManager.h"
#define  CELL_WIDTH  ITEM_WIDTH
#define  CELL_HEIGHT (CELL_WIDTH/0.618)+30
@interface ShoppingCartCollectionViewController ()

@end

@implementation ShoppingCartCollectionViewController
static NSString * const reuseIdentifier = @"ShoppingCartCell";
- (void)viewDidLoad {
    [super viewDidLoad];
    OBSERVER(FinishPayNotification, @selector(finishPay));
    UINib *cellNib = [UINib nibWithNibName:@"ShoppingCartCollectionViewCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:reuseIdentifier];

    self.collectionView.showsHorizontalScrollIndicator=NO;
    self.collectionView.showsVerticalScrollIndicator=NO;

    self.collectionView.backgroundColor= BKCOLOR;
    
}
-(void)finishPay{
    [self.dataArray removeAllObjects];
    [self.collectionView reloadData];
}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


-(void)setDataArray:(NSMutableArray *)dataArray{
    _dataArray=dataArray;
    [self.collectionView reloadData];
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return _dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    ShoppingCartCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    //防崩溃保护
    if (self.dataArray.count) {

        cell.model=self.dataArray[indexPath.row];

    }
    //cell的block
    cell.block=^(MGIssueModel *model){

            //删除数据库中的数据

            [[ShoppingCartDataManager sharedManager]deleteDataWithModel:model];

            //界面上删除对应的cell并且刷新界面
            [_dataArray removeObject:model];

            [self.collectionView reloadData];

            //发送购物车数据发生变化通知
        POSTER(ShoppingCartDidChangeNotification, nil);



    };

    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat LabH =30;
    
    CGFloat PurchaseCellPW = (MINSCREEN-(ItemP+1)*Margin)/ItemP;
    CGFloat PurchaseCellPH = PurchaseCellPW/GoldenSection+LabH;
    CGFloat PurchaseCellLW = (MAXSCREEN-(ItemL+1)*Margin)/ItemL;
    CGFloat PurchaseCellLH = PurchaseCellLW/GoldenSection+LabH;
    CGSize size;
    //
    if (UIInterfaceOrientationIsPortrait(UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation))) {
        size=CGSizeMake(PurchaseCellPW, PurchaseCellPH);
   
    }else{
        
        size=CGSizeMake(PurchaseCellLW, PurchaseCellLH);

        
    }
    
    return size;
}


@end
