//
//  SettlementView.h
//  MagookReader
//
//  Created by tailhuang on 15/9/15.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettlementView : UIView
@property (nonatomic, copy) void(^settleBlock)(NSInteger amount,NSInteger number);
@end
