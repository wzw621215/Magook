//
//  ZBActivity.m
//  MagookReader
//
//  Created by tailhuang on 15/10/14.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ZBActivity.h"

@implementation ZBActivity
static UIActivityIndicatorView*indicator=nil;
+(void)showActivityInView:(UIView*)view{

    if (!indicator) {
        indicator=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    }
    indicator.center=[UIApplication sharedApplication].keyWindow.center;

    [view addSubview:indicator];
    [indicator startAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible=YES;
}
+(void)dismiss{
    [indicator stopAnimating];
    [indicator removeFromSuperview];
    indicator=nil;

    [UIApplication sharedApplication].networkActivityIndicatorVisible=NO;
}
@end
