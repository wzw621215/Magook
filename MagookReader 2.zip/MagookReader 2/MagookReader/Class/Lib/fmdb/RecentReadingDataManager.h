//
//  RecentReadingDataManager.h
//  MagookReader
//
//  Created by tailhuang on 15/10/14.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MGIssueModel;
@interface RecentReadingDataManager : NSObject
+(instancetype)sharedManager;
- (BOOL)isExistsDataWithModel:(MGIssueModel *)model;
- (BOOL)insertDataWithModel:(MGIssueModel *)model;
- (BOOL)deleteDataWithModel:(MGIssueModel *)model;
- (NSArray *)allData;
-(void)removeData;
@end
