//
//  ZBHud.m
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "ZBHud.h"
#import "TAOverlay.h"
@implementation ZBHud
+(void)showSuccessWithMessage:(NSString *)message{
//    [TAOverlay setOverlayLabelTextColor:COLOR];
    [TAOverlay showOverlayWithLabel:message Options:TAOverlayOptionOpaqueBackground|TAOverlayOptionAutoHide|TAOverlayOptionOverlayTypeSuccess|TAOverlayOptionOverlaySizeRoundedRect];
}
+(void)showActivityWithMessage:(NSString *)message{

//    [TAOverlay setOverlayLabelTextColor:COLOR];
    [TAOverlay showOverlayWithLabel:message Options:TAOverlayOptionOpaqueBackground|TAOverlayOptionOpaqueBackground|TAOverlayOptionOverlayTypeActivityDefault|TAOverlayOptionOverlaySizeRoundedRect];
}
+(void)showErrorWithMessage:(NSString *)message{
//    [TAOverlay setOverlayLabelTextColor:COLOR];
    [TAOverlay showOverlayWithLabel:message Options:TAOverlayOptionOpaqueBackground|TAOverlayOptionOverlayTypeError|TAOverlayOptionOverlaySizeRoundedRect|TAOverlayOptionOverlayDismissTap|TAOverlayOptionAutoHide];
}
+(void)showInfo:(NSString *)info{
//    [TAOverlay setOverlayLabelTextColor:COLOR];
    [TAOverlay showOverlayWithLabel:info Options:TAOverlayOptionOpaqueBackground|TAOverlayOptionOverlayDismissTap|TAOverlayOptionOverlayTypeInfo|TAOverlayOptionOverlaySizeRoundedRect|TAOverlayOptionAutoHide];//
}
+(instancetype)sharedHud{

    return (ZBHud *)[TAOverlay shared];
}
+(void)dismiss{

    [TAOverlay hideOverlay];
}
@end
