//
//  ZBHud.h
//  MagookReader
//
//  Created by tailhuang on 15/9/10.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZBHud : NSObject
//对三方库进行二次封装

//成功
+(void)showSuccessWithMessage:(NSString *)message;
//加载中
+(void)showActivityWithMessage:(NSString *)message;

//错误
+(void)showErrorWithMessage:(NSString *)message;
//提示
+(void)showInfo:(NSString *)info;
+(instancetype)sharedHud;
+(void)dismiss;
@end
