//
//  NSAttributedString+ZBAttibutedSting.m
//  WPAttributedMarkupDemo
//
//  Created by user on 15/9/8.
//  Copyright (c) 2015年 Nigel Grange. All rights reserved.
//

#import "NSAttributedString+ZBAttibutedSting.h"


@implementation NSAttributedString (ZBAttibutedSting)
+(instancetype)stringWithText:(NSString *)string attributedString:(NSString *)attributedString fontSize:(CGFloat)fontSize color:(UIColor *)color block:(void (^)())action{

    NSRange range= [string rangeOfString:attributedString];
    //前半截
    NSString *st1= [string substringToIndex:range.location];
    //后半截
    NSString *st2 =[string substringFromIndex:range.location+range.length];

//    NSLog(@"%@---%@---%@",st1,attributedString,st2);

//    NSArray *array = [string componentsSeparatedByString:attributedString];

    NSDictionary* style = @{
                            @"body":[UIFont fontWithName:@".HelveticaNeueInterface-Regular" size:fontSize],
                            @"bold":[UIFont fontWithName:@".HelveticaNeueInterface-Regular" size:fontSize],
                             @"action":[WPAttributedStyleAction styledActionWithAction:action],
                             @"link": color};
    
    return [[NSString stringWithFormat:@"%@<action>%@</action>%@",st1,attributedString,st2] attributedStringWithStyleBook:style];
}
@end
