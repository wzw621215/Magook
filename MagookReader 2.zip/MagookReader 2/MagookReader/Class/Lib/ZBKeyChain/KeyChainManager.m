//
//  KeyChainManager.m
//  KeyChain3
//
//  Created by user on 15/9/4.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "KeyChainManager.h"
#import "ZBKeychain.h"

@implementation KeyChainManager

NSString * const KEY_USERNAME_PASSWORD = @"com.magook.app.usernamepassword";
NSString * const KEY_USERNAME = @"com.magook.app.username";
NSString * const KEY_PASSWORD = @"com.magook.app.password";

+(void)saveUserName:(NSString *)userName passWord:(NSString *)passWord{
    NSLog(@"保存用户名密码");

    NSMutableDictionary *usernamepasswordKVPairs = [NSMutableDictionary dictionary];
    [usernamepasswordKVPairs setObject:userName forKey:KEY_USERNAME];
    [usernamepasswordKVPairs setObject:passWord forKey:KEY_PASSWORD];

    [ZBKeychain save:KEY_USERNAME_PASSWORD data:usernamepasswordKVPairs];
    
}
+(NSDictionary *)readUserNameAndPassWord{
    
    NSMutableDictionary *usernamepasswordKVPairs = (NSMutableDictionary *)[ZBKeychain load:KEY_USERNAME_PASSWORD];
    return usernamepasswordKVPairs;
}

+(void)deleteUserNameAndPassword{
    NSLog(@"删除保存的用户名密码");
    [ZBKeychain delete:KEY_USERNAME_PASSWORD];
}
@end
