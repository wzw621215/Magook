//
//  AppController.h
//  MagookReader
//
//  Created by zhoubin on 15/11/10.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworkReachabilityManager.h"
typedef NS_ENUM(NSInteger, NetWorkStatus) {
    NetWorkStatusNotReachable,
    NetWorkStatusWIFI,
    NetWorkStatusWWAN,
    NetWorkStatusUnknow
};
typedef NS_ENUM(NSUInteger, UserPermissionStyle) {
    UserPermissionStyleDoNotPurchased,
    UserPermissionStylePurchased,
    UserPermissionStyleOutOfDate
    
};
@interface AppController : NSObject
@property (nonatomic ,assign) NetWorkStatus netWorkStatus;
@property (nonatomic ,assign) BOOL enablebonus;
@property (nonatomic ,copy) NSString *trackUrl;
@property (nonatomic ,assign) BOOL inReview;
@property (nonatomic ,strong) NSNumber *useridInReview;
@property (nonatomic ,copy) NSString *userHashInReview;
+(instancetype)sharedController;
- (void)checkNetWorkStatus;
+(UserPermissionStyle)checkPermissionWithMagazineID:(NSNumber *)magazineid;
@end
