//
//  AppController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/10.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "AppController.h"
#import "PurchasedModel.h"
@implementation AppController
static AppController *controller=nil;
+(instancetype)sharedController{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (controller==nil) {
            controller = [[self alloc]init];
        }
    });
    
    return controller;
    
}
- (void)checkNetWorkStatus{
    //AFNetworkReachabilityManager 我们需要使用的是这个类
    //得到一个单例
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    //开启检测网络
    [manager startMonitoring];
    //回调...(当你网络状态发生改变的时候 会回调回来)
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*
         AFNetworkReachabilityStatusUnknown          = -1,
         AFNetworkReachabilityStatusNotReachable     = 0,
         AFNetworkReachabilityStatusReachableViaWWAN = 1,
         AFNetworkReachabilityStatusReachableViaWiFi = 2,
         */
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
            {
                NSLog(@"---------未知网络类型----------");
                self.netWorkStatus = NetWorkStatusUnknow;
            }
                break;
            case AFNetworkReachabilityStatusNotReachable:
            {
                NSLog(@"-----------无网络连接----------");
                self.netWorkStatus = NetWorkStatusNotReachable;
            }
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
            {
                NSLog(@"------------2G/3G/4G网络------------");
                self.netWorkStatus = NetWorkStatusWWAN;
            }
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
            {
                //请求数据
                NSLog(@"-------------WIFI------------");
                self.netWorkStatus = NetWorkStatusWIFI;

            }
                break;
                
            default:
                break;
        }
    }];
}

//检查是否在期限内
+(UserPermissionStyle)checkPermissionWithMagazineID:(NSNumber *)magazineid{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyyMMdd"] ;
    NSString *dateStr=[formatter stringFromDate:[NSDate date]];
    NSInteger dateNum=[dateStr integerValue];
    UserModel *user = [UserModel sharedUser];
    if (user.usertoken!=nil||INREVIEW) {
        //        NSLog(@"已登录");
        
        if ([user.iswholelib isEqualToNumber:@1]) {
            //            NSLog(@"全库VIP");
            if ([user.wholelibexpiredate integerValue]>=dateNum) {
                //                NSLog(@"VIP在期限内");
                return UserPermissionStylePurchased;
            }else{
                //                NSLog(@"VIP已过期--%@",self.wholelibexpiredate);
                return UserPermissionStyleOutOfDate;
            }
            
        }else{
            //            NSLog(@"非全库VIP");
            if (user.puchasedArray) {
                //                NSLog(@"已购买数组不为空");
                for (PurchasedModel *model in user.puchasedArray) {
                    if (magazineid==nil) {
                        return UserPermissionStyleDoNotPurchased;
                    }
                    
                    if ([model.magazineid isEqualToNumber:magazineid]) {
                        //                        NSLog(@"已购买该杂志");
                        
                        //开始权限时间
                        NSInteger startdate=[model.startdate integerValue];
                        //结束权限时间
                        NSInteger enddate =[model.enddate integerValue];
                        
                        if (dateNum>=startdate&&dateNum<=enddate) {
                            //                            NSLog(@"已购买的杂志在有效期限内");
                            return UserPermissionStylePurchased;
                        }else{
                            NSLog(@"期限未至或已过期%ld---%ld",startdate,enddate);
                            return UserPermissionStyleOutOfDate;
                        }
                    }
                }
            }else{
                NSLog(@"已购买数据为空");
            }
            
        }
    }else{
        NSLog(@"未登录");
    }
    return UserPermissionStyleDoNotPurchased;
    
}
@end
