//
//  DownloadHandle.h
//  MagookReader
//
//  Created by zhoubin on 15/11/17.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDWebImageManager.h"
#import "UIImage+WebP.h"
@interface DownloadHandle : NSObject
typedef void (^finishBlock)(UIImage *image, NSURL *imageUrl, long long size);
+(SDWebImageCombinedOperation *)downloadWithURL:(NSString *)url directoryName:(NSString *)directoryName fileName:(id)name complete:(finishBlock)finish;
+(void)pauseWithOperation:(SDWebImageCombinedOperation *)operation;
@end
