//
//  LogManager.m
//  MagookReader
//
//  Created by zhoubin on 15/11/10.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "LogManager.h"
#define FileManager [NSFileManager defaultManager]
@implementation LogManager
+(void)logWithViewID:(NSNumber *)viewID action:(NSString *)action info:(NSString *)info{

    if (viewID==nil) {
        return;
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSDate *dateNow=[NSDate date];
        NSDateFormatter *fmt=[[NSDateFormatter alloc]init];
        fmt.dateFormat=@"yyyyMMddHHmmss";
        
        NSString *dateStr                      = [fmt stringFromDate:dateNow];
        
        NSMutableString *logStr=[NSMutableString stringWithFormat:@"%@,%@,%@,%@",dateStr,SESSIONID,[UserModel sharedUser].userid,viewID];
        if (action) {
            
            [logStr appendFormat:@",%@",action];
        }
        if (info) {
            [logStr appendFormat:@",%@",info];
        }
        [logStr appendString:@"\n"];
        
//        NSLog(@"log=====%@",logStr);
        if ([FileManager fileExistsAtPath:LOGPATH]) {
            
            [logStr appendString:[NSString stringWithContentsOfFile:LOGPATH encoding:NSUTF8StringEncoding error:nil]];
        }
        
        [logStr writeToFile:LOGPATH atomically:YES encoding:NSUTF8StringEncoding error:nil];
    });
    
}
+(void)logWithViewID:(NSNumber *)viewID{
    [self logWithViewID:viewID action:nil info:nil];
}
+(void)logWithViewID:(NSNumber *)viewID action:(NSString *)action{
    [self logWithViewID:viewID action:action info:nil];
}
+(void)sendLogToServer{
    NSData *data  = [NSData dataWithContentsOfFile:LOGPATH options:NSDataReadingMappedIfSafe error:nil ];
    if (LOGSERVER==nil||DEVICEID==nil||data==nil) {
        NSLog(@"数据为空，不发送");
        return;
    }

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *url                          = [NSString stringWithFormat:@"%@log/upload",LOGSERVER];
    NSDictionary * param                   = @{
                                 @"device":[DEVICE JSONString],
                                 @"deviceid":DEVICEID,
                                 @"interfaceversion":@"v1.1"
                                 };
    [manager POST:url parameters:param constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {

        [formData appendPartWithFileData:data name:@"file" fileName:@"log.txt" mimeType:@"text/plain"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if([responseObject[@"status"] isEqualToNumber:@1]){
            NSLog(@"发送日志文件成功-------%@",[responseObject JSONString]);
            [self removeLog];
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"发送日志文件失败---------%@",error);
    }];
}

+(void)removeLog{
    NSLog(@"移除日志");
    [FileManager removeItemAtPath:LOGPATH error:nil];
}

@end
