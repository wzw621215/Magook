
#define ExternString(name)    extern  NSString *const  (name)
#define ExternCGFloat(name)   extern const CGFloat     (name)
#define ExternNSInteger(name) extern const NSInteger   (name)

ExternCGFloat(Margin);
ExternCGFloat(GoldenSection);
ExternCGFloat(RightTableW);
ExternCGFloat(LogoW);
ExternCGFloat(LogoH);
ExternCGFloat(logoY);
ExternCGFloat(LoginInputW);
ExternCGFloat(LoginInputH);
ExternCGFloat(APIVersion);
ExternCGFloat(APPTypeID);
ExternCGFloat(TAB_HEIGHT);
ExternCGFloat(NAV_HEIGHT);
ExternCGFloat(TimeOutInterval);

ExternNSInteger(ItemP);
ExternNSInteger(ItemL);
//ExternNSInteger(PlatformTypeIPhone);
//ExternNSInteger(PlatformTypeIPad);
ExternNSInteger(PlatformType);
ExternNSInteger(APPVersion);

ExternString(ORGID);
ExternString(APPTYPEID);
ExternString(DoublePageStatus);
ExternString(DownloadDirectoryName);
ExternString(SYSTEM);
ExternString(UMAPPKEY);
ExternString(MGLIBARCHIVER);
ExternString(MGLIBCATEGORYPLIST);

ExternString(ShoppingCartDidChangeNotification);
ExternString(OrientationWillChangeNotification);
ExternString(TranstoMGLibNotification);
ExternString(LoginSuccessNotification);
ExternString(ScanFinishNotification);
ExternString(ForgetPassWordNotification);
ExternString(RegistUserNotification);
ExternString(FinishPayNotification);
ExternString(LogOutNotification);
ExternString(PullRfreshNotification);
ExternString(PushLoadNotification);
ExternString(LimitedStepNotification);
ExternString(StepValueDidChageNotification);
ExternString(GoToReadingFromBonusHistoryNotification);
ExternString(GoToReadingFromMGShelfNotification);
ExternString(GoToReadingFromBeforeNotification);
ExternString(UpdateDownloadProgressNotification);
ExternString(NewDownloadMissionIsBuildNotification);
ExternString(SingleTapHandleNotification);
ExternString(HasNewBonusNotification);
ExternString(ResetPassWordSuccessNotification);
ExternString(RegistSuccessNotification);
ExternString(GoToShoppingCartFromShelfNotification);
ExternString(ZBSlideViewDidScrollNotification);
ExternString(NoMoreNotification);
