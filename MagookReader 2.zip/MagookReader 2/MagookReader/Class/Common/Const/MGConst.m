

const CGFloat APIVersion                                = 2;
const CGFloat APPTypeID                                 = 0;
const NSInteger APPVersion                              = 1215;
//const NSInteger PlatformTypeIPhone                      = 13;
//const NSInteger PlatformTypeIPad                        = 14;
const NSInteger PlatformType                            = 2;
const CGFloat GoldenSection                             = 0.618;
const CGFloat Margin                                    = 10.0;
const CGFloat TimeOutInterval                           = 30.0;

const CGFloat LogoW                                     = 80.0;
const CGFloat LogoH                                     = 80.0;
const CGFloat logoY                                     = 40.0;

const CGFloat LoginInputW                               = 300.0;
const CGFloat LoginInputH                               = 250.0;

const NSInteger ItemP                                   = 4;
const NSInteger ItemL                                   = 5;
const CGFloat RightTableW                               = 80.0;
const CGFloat TAB_HEIGHT                                = 49.0;
const CGFloat NAV_HEIGHT                                = 64.0;
NSString *const SYSTEM                                  = @"iOS";
NSString *const ORGID                                   = @"magook";
NSString *const APPTYPEID                               = @"0";
NSString *const DoublePageStatus                        = @"DoublePageStatus";
NSString *const DownloadDirectoryName                   = @"下载";
NSString *const UMAPPKEY                                = @"554878fe67e58e5428003981";
NSString *const MGLIBARCHIVER                           = @"MGLibArchiver";
NSString *const MGLIBCATEGORYPLIST                      = @"MGLibCategory.plist";

NSString *const ShoppingCartDidChangeNotification       = @"shoppingCartDidChange";
NSString *const TranstoMGLibNotification                = @"TransToMGlib";
NSString *const LoginSuccessNotification                = @"LoginSuccess";
NSString *const ScanFinishNotification                  = @"scanFinish";
NSString *const ForgetPassWordNotification              = @"forgetPassWord";
NSString *const RegistUserNotification                  = @"registUser";
NSString *const FinishPayNotification                   = @"finishPay";
NSString *const LogOutNotification                      = @"userDidLogout";
NSString *const PullRfreshNotification                  = @"pullRefresh";
NSString *const PushLoadNotification                    = @"pushLoad";
NSString *const LimitedStepNotification                 = @"LimitedStep";
NSString *const StepValueDidChageNotification           = @"stepValueDidChange";
NSString *const GoToReadingFromBonusHistoryNotification = @"GoToReadingFromBonusHistory";
NSString *const GoToReadingFromMGShelfNotification      = @"GoToReadingFromMGShelf";
NSString *const UpdateDownloadProgressNotification      = @"updateDownloadProgress";
NSString *const NewDownloadMissionIsBuildNotification   = @"NewDownloadMissionIsBuild";
NSString *const SingleTapHandleNotification             = @"singleTapHandle";
NSString *const HasNewBonusNotification                 = @"hasNewBonus";
NSString *const OrientationWillChangeNotification       = @"OrientationWillChange";
NSString *const GoToReadingFromBeforeNotification       = @"GoToReadingFromBefore";
NSString *const ResetPassWordSuccessNotification        = @"resetPassWordSuccess";
NSString *const RegistSuccessNotification               = @"registSuccess";
NSString *const GoToShoppingCartFromShelfNotification   = @"goToShoppingCartFromShelf";
NSString *const ZBSlideViewDidScrollNotification        = @"ZBSlideViewDidScroll";
NSString *const NoMoreNotification                      = @"NoMore";


