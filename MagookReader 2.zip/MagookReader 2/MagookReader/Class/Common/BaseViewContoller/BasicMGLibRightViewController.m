//
//  BasicMGLibRightViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/12/4.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicMGLibRightViewController.h"

@interface BasicMGLibRightViewController ()

@end

@implementation BasicMGLibRightViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=BKCOLOR;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    self.dataArray=[NSMutableArray new];
    
    self.tableView.tableFooterView=[[UIView alloc]init];
}
-(void)setDataArray:(NSArray *)dataArray{
    _dataArray=dataArray;
    [self.tableView reloadData];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataArray.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (iPad) {
        return MINSCREEN/11;
    }else{
        return 44;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.selectedIndex=indexPath.row;
    if (self.block) {
        self.block(self.selectedIndex);
    }
    [self.tableView reloadData];
}

@end
