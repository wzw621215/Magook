//
//  BasicMGLibViewController.h
//  MagookReader
//
//  Created by zhoubin on 15/12/3.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicViewController.h"
@class LibDataModel,BasicMGLibCollectionViewController,BasicMGLibRightViewController;
@interface BasicMGLibViewController : BasicViewController
@property (nonatomic, strong) NSMutableDictionary *mainDataDic;
@property (nonatomic ,strong) BasicMGLibCollectionViewController *collectionVC;
@property (nonatomic ,strong) BasicMGLibRightViewController *rightVC;
-(void)createRightViewWithVCClass:(Class)className;
-(void)loadDataWithCategory:(NSNumber *)category Page:(NSNumber *)page finish :(void (^)(LibDataModel *libModel))finish;
-(void)getOringinData;
@end
