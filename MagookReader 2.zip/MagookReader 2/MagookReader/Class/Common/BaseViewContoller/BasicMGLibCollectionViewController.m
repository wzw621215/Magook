//
//  ScanViewController.m
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "BasicMGLibCollectionViewController.h"
#import "MGIssueModel.h"
#import "MGLibCell.h"
#import "MJRefresh.h"
#import "LibDataModel.h"
#import "NSDate+Extension.h"
@interface BasicMGLibCollectionViewController ()

@end

@implementation BasicMGLibCollectionViewController

static NSString * const reuseIdentifier                = @"MGlibCellID";

- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(LogOutNotification, @selector(refresh));
    OBSERVER(LoginSuccessNotification, @selector(refresh));
    OBSERVER(FinishPayNotification, @selector(refresh));
    OBSERVER(NoMoreNotification, @selector(nomore));
    __weak __typeof(self) weakSelf                     = self;
    // 下拉刷新
        self.collectionView.header                         = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            
            POSTER(PullRfreshNotification, self.model);
            // 模拟延迟加载数据
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                // 结束刷新
                [weakSelf.collectionView.header endRefreshing];
            });
        }];
        
        self.collectionView.footer                         = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            
            POSTER(PushLoadNotification, self.model);
            
            // 模拟延迟加载数据
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                // 结束刷新
                [weakSelf.collectionView.footer endRefreshing];
                weakSelf.collectionView.footer.hidden      = YES;
                
            });
        }];

    UINib *cellNib                                     = [UINib nibWithNibName:@"MGLibCell" bundle:nil];
    [self.collectionView registerNib:cellNib forCellWithReuseIdentifier:@"MGlibCellID"];
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.showsVerticalScrollIndicator   = NO;
    self.collectionView.backgroundColor                = BKCOLOR;

    //检测当前日期是否是今天，来决定是否刷新
    [self chekDate];

}
-(void)refresh{
    [self.collectionView reloadData];
}

-(void)chekDate{
    
    NSDate *lastDate=[[NSUserDefaults standardUserDefaults]objectForKey:@"date"];
    if (lastDate==nil||![lastDate isToday]) {
        NSLog(@"上个刷新日期不存在或不是今天,刷新界面");
        [self.collectionView.header beginRefreshing];
        NSDate *dateNow = [NSDate date];
        [[NSUserDefaults standardUserDefaults]setObject:dateNow forKey:@"date"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }else{
        NSLog(@"上个刷新日期是今天，不刷新");
    }
    
    
}
//销毁观察者
-(void)dealloc{
    REMOVEOBSERVER;
}
-(void)nomore{
    [self.collectionView.footer noticeNoMoreData];
    self.collectionView.footer.hidden=YES;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.model.dataArray.count;
}


-(void)setModel:(LibDataModel *)model{
    
    _model=model;
    
    [self.collectionView reloadData];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    MGLibCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    //防崩溃保护
    if (self.model.dataArray.count) {
//    cell.model      = self.dataArray[indexPath.row];
        cell.model=self.model.dataArray[indexPath.row];

    }
    cell.block=^(MGIssueModel *model){
        NSLog(@"跳转");
        self.block(model);
    };
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{

    CGFloat labH    = 60;
    CGFloat itemPW = (MINSCREEN-RightTableW-ItemP*Margin)/(ItemP-1);
    CGFloat itemPH = itemPW/GoldenSection+labH;
    CGFloat itemLW = (MAXSCREEN-RightTableW-(ItemL+1)*Margin)/(ItemL);
    CGFloat itemLH = itemLW/GoldenSection+labH;
    CGSize size;
    
    if (PORTRAIT) {
        size=CGSizeMake(itemPW, itemPH) ;
    }else{
        size=CGSizeMake(itemLW, itemLH);
    }

        return size;
}

@end
