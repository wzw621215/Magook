//
//  BasicCollectionViewController.m
//  MagookReader
//
//  Created by zhoubin on 15/11/23.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicCollectionViewController.h"

@interface BasicCollectionViewController ()

@end

@implementation BasicCollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(OrientationWillChangeNotification, @selector(orientationDidChange));
}
-(void)orientationDidChange{
    [self.collectionViewLayout invalidateLayout];
}
-(instancetype)init{
    UICollectionViewFlowLayout*layout=[[UICollectionViewFlowLayout alloc]init];
    [layout setScrollDirection:UICollectionViewScrollDirectionVertical];
    // 垂直间距
    layout.minimumLineSpacing                          = 10;
    // 水平间距
    layout.minimumInteritemSpacing                     = 10;
    // 内边距
    layout.sectionInset                                = UIEdgeInsetsMake(10, 10, 10, 10);
    
    return [super initWithCollectionViewLayout:layout];
}
@end
