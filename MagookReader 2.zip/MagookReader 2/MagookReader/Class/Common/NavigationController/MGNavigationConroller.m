//
//  MGNavigationConroller.m
//  MagookReader
//
//  Created by tailhuang on 15/9/9.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGNavigationConroller.h"
#import "MGBonusViewController.h"
#import "SearchViewController.h"
#import "ZBScanManager.h"
#import "ShoppingCartDataManager.h"
#import "ScanHandle.h"
#import "ScanViewController.h"
#import "MGIssueModel.h"
#import "ScanResultViewController.h"
#import "VipViewController.h"
#import "SettleViewController.h"
#import "BonusHiddenView.h"
#import "UINavigationController+JZExtension.h"
@interface MGNavigationConroller ()
@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic ,assign) BOOL isFinishPay;
@end

@implementation MGNavigationConroller

- (void)viewDidLoad {
    [super viewDidLoad];

    OBSERVER(FinishPayNotification, @selector(finishPay));
    OBSERVER(TranstoMGLibNotification, @selector(trasToMGlib));
    self.navigationBar.barTintColor                 = COLOR;
    self.fullScreenInteractivePopGestureRecognizer=YES;
    [self.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationBar.tintColor=[UIColor whiteColor];

}
-(void)trasToMGlib{

    if (self.viewControllers.count>1) {
        [self popToRootViewControllerAnimated:YES];
    }

}
//将状态栏高度强制设定为44
-(void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    self. navigationBar.height                      = 44;
}
-(void)finishPay{

    self.isFinishPay                                = YES;
}
-(NSMutableArray *)items{
    if (!_items) {
    _items                                          = [[NSMutableArray alloc]init];
    }

    return _items;
}
//清空数组
-(void)clearItems{
    [self.items removeAllObjects];
}
-(void) addItemWithType:(MGRightItemType)type inVc:(UIViewController *)vc{

    UIBarButtonItem *barButtonItem;

        switch (type) {

                case MGRightItemTypeSearch:
                barButtonItem = [UIBarButtonItem rightItemWithTarget:self action:@selector(searchItemClick) image:@"搜索" highImage:@"搜索_checked"];
                    break;
                case MGRightItemTypeScan:
                barButtonItem = [UIBarButtonItem rightItemWithTarget:self action:@selector(scanItemClick) image:@"扫描" highImage:@"扫描_checked"];
                    break;
                case MGRightItemTypeVIP:
                if (!INREVIEW&&[AppController sharedController].netWorkStatus) {
                barButtonItem = [UIBarButtonItem rightItemWithTarget:self action:@selector(VIPItemClick) image:@"终身VIP" highImage:@"终身VIP_checked"];
                }
                    break;
                default:
                    break;
            }

        if (barButtonItem) {
            [self.items addObject:barButtonItem];
            vc.navigationItem.rightBarButtonItems           = self.items;
        }
}
-(UIViewController *)popViewControllerAnimated:(BOOL)animated{
    [self.items removeAllObjects];

    if ([self.visibleViewController isKindOfClass:[SettleViewController class]]) {
        if (!self.isFinishPay) {
            if(ENABLEBONUS){
            NSLog(@"从麦豆支付页面返回，未支付，显示隐藏红包");
            [BonusHiddenView showWithParentController:self];
            }
        }else{
            NSLog(@"支付成功不显示");
        }

    }
    return [super popViewControllerAnimated:animated];
}

#pragma marl -搜索按钮点击方法
-(void)searchItemClick{
    NSLog(@"搜索");
    SearchViewController *vc                        = [SearchViewController new];
    [self pushViewController:vc animated:YES];
}
#pragma mark - 扫描按钮点击方法
-(void)scanItemClick{
     NSLog(@"扫描");

    [ZBScanManager scanInVC:self complishBlock:^(NSString *url) {

        NSLog(@"扫描结果url=======%@",url);
        //发送跳转到扫描结果

        [ScanHandle handleUrl:url completedBlock:^(id root) {

//            NSLog(@"%@",root);
             ScanViewController *vc                          = [ScanViewController new];

            MGIssueModel *model =[MGIssueModel modelWithDic:[root[@"data"] firstObject]];

            //默认将扫描结果加入购物车

            //如果数据库里面没有并且未购买就加入数据库
            UserPermissionStyle style = [AppController checkPermissionWithMagazineID:model.magazineid];
            
            if (![[ShoppingCartDataManager sharedManager]isExistsDataWithModel:model]&&style==UserPermissionStyleDoNotPurchased) {
                [[ShoppingCartDataManager sharedManager]insertDataWithModel:model];
                POSTER(ShoppingCartDidChangeNotification, nil);
            }
            //给collecTionView数据源赋值
            vc.dataArray=[NSMutableArray arrayWithObject:model];

//            [self pushViewController:vc animated:YES];
            //延时0.5秒，防止ios7崩溃
            [self performSelector:@selector(pushViewController:animated:) withObject:vc afterDelay:0.5];

        }];

    }];
}
#pragma mark -VIP按钮点击方法
-(void)VIPItemClick{
    NSLog(@"VIP");

    VipViewController *vc =[VipViewController new];

    [self pushViewController:vc animated:YES];
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{

    self.isFinishPay                                = NO;



    if (self.viewControllers.count > 0) {
        [self.items removeAllObjects];

        //每个导航栏的次级页面
        /* 自动显示和隐藏tabbar */


    viewController.hidesBottomBarWhenPushed         = YES;



        // 设置左边的返回按钮
    viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(back) image:@"back" highImage:@"back_highlight"];

    }else{

         //每个导航栏的首页
        //红包按钮开关

        if(ENABLEBONUS){
    viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithTarget:self action:@selector(bonus) image:@"hb_btl" highImage:@"hb_btl"];
        }

    }

    [super pushViewController:viewController animated:animated];



}

-(void)bonus{
    MGBonusViewController *vc                       = [MGBonusViewController new];

    vc.title=@"杂志红包";

    [self pushViewController:vc animated:YES];
}
- (void)back
{

    [self popViewControllerAnimated:YES];
}




@end
