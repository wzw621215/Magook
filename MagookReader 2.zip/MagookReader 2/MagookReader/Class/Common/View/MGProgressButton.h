//
//  MGButton.h
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGButton.h"
#import "UAProgressView.h"

@interface MGProgressButton : MGButton
@property (nonatomic, assign) CGFloat  progress;
//是否正在进行中
@property (nonatomic, assign) BOOL     isDownloading;
@end
