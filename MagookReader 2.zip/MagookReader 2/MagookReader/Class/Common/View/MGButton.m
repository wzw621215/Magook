//
//  MGButton.m
//  MagookReader
//
//  Created by tailhuang on 15/9/17.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "MGButton.h"

@implementation MGButton

- (void)setHighlighted:(BOOL)highlighted {}

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imageW = contentRect.size.height * 0.5;
    CGFloat imageH = contentRect.size.height * 0.5;
    CGFloat imageX = 0.5*(contentRect.size.width-imageW);
    return CGRectMake(imageX, 0, imageW, imageH);
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleY = contentRect.size.height * 0.6;

    CGFloat titleW = contentRect.size.width;

    CGFloat titleH = contentRect.size.height - titleY;
    CGFloat titleX = (contentRect.size.width-titleW)/2;

    return CGRectMake(titleX, titleY, titleW, titleH);
}


@end
