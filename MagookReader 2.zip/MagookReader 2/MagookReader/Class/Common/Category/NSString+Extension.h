//
//  NSString+Extension.h
//  MagookReader
//
//  Created by tailhuang on 15/9/7.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)
//判断是否为全数字字符串
-(BOOL)isAllNumber;
//MD5
-(NSString *) md5String;
-(NSString *)hashString;
+(NSString*)sizeFromByte:(NSInteger)cacheSize;
-(NSString *)pageHashWithMagazineID:(NSNumber *)mgzId issueID:(NSNumber *)issueID;
+(BOOL)isValidateEmail:(NSString *)email;
@end
