//
//  UIImage+Color.h
//  MagookReader
//
//  Created by tailhuang on 15/9/22.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Color)
+ (UIImage *)imageWithColor:(UIColor *)color;
@end
