//
//  UIImageView+Extension.m
//  MagookReader
//
//  Created by tailhuang on 15/9/20.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "UIImageView+Extension.h"

//#import "SDWebImageManager.h"
@implementation UIImageView (Extension)
-(void)loadImageWithSmallImage:(NSString *)smallImageUrl bigImage:(NSString *)bigImageUrl progress:(SDWebImageDownloaderProgressBlock)progressBlock completed:(SDWebImageCompletionBlock)completedBlock
{

        //如果缓存中不存在则加载
        [self sd_setImageWithURL:[NSURL URLWithString:smallImageUrl] placeholderImage:[UIImage imageNamed:@"封面"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {

            
            [self sd_setImageWithURL:[NSURL URLWithString:bigImageUrl] placeholderImage:image options:SDWebImageRetryFailed|SDWebImageLowPriority progress:^(NSInteger receivedSize, NSInteger expectedSize) {

                progressBlock(receivedSize, expectedSize);

            } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {

                completedBlock(image,error,cacheType,imageURL);
            }];
        }];


//    }




}
@end
