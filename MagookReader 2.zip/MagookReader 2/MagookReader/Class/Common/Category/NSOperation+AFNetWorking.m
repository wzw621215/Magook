//
//  NSOperation+AFNetWorking.m
//  netTest
//
//  Created by tailhuang on 15/9/8.
//  Copyright (c) 2015年 magook.com. All rights reserved.
//

#import "NSOperation+AFNetWorking.h"

@implementation NSOperation (AFNetWorking)

+ (NSOperation *)GET:(NSString *)URLString
          parameters:(id)parameters
             success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
             failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure{

    
    AFHTTPRequestOperationManager *manager =[AFHTTPRequestOperationManager manager];

    NSMutableURLRequest *request = [manager.requestSerializer requestWithMethod:@"GET" URLString:[[NSURL URLWithString:URLString relativeToURL:manager.baseURL] absoluteString] parameters:parameters error:nil];

    request.timeoutInterval=TimeOutInterval;
    //将——user_agent 和 BundleId 设置为请求头
    [manager.requestSerializer setValue:USERAGENT forHTTPHeaderField:@"useragent"];
    [manager.requestSerializer setValue:BUNDLEID forHTTPHeaderField:@"bundleid"];

    AFHTTPRequestOperation *operation = [manager HTTPRequestOperationWithRequest:request success:success failure:failure];

    [manager.operationQueue addOperation:operation];
    
    return operation;
}
+(NSOperation *)POST:(NSString *)URLString
          parameters:(id)parameters
             success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
             failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure{

    if (URLString==nil) {
        NSLog(@"url为空");
        return nil;
    }
//    if ([AppController sharedController].netWorkStatus==NetWorkStatusNotReachable) {
//        NSLog(@"网络连接失败");
//        return nil;
//    }

    AFHTTPRequestOperationManager *manager =[AFHTTPRequestOperationManager manager];

    [manager.requestSerializer setValue:USERAGENT forHTTPHeaderField:@"useragent"];
    [manager.requestSerializer setValue:BUNDLEID forHTTPHeaderField:@"bundleid"];

    NSMutableURLRequest *request = [manager.requestSerializer requestWithMethod:@"POST" URLString:[[NSURL URLWithString:URLString relativeToURL:manager.baseURL] absoluteString] parameters:parameters error:nil];
    //连接超时
    request.timeoutInterval=TimeOutInterval;

    AFHTTPRequestOperation *operation = [manager HTTPRequestOperationWithRequest:request success:success failure:failure];

    [manager.operationQueue addOperation:operation];

    return operation;
    
}

@end
