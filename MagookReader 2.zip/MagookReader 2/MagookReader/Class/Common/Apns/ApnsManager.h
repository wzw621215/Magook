//
//  ApnsManager.h
//  MagookReader
//
//  Created by zhoubin on 15/10/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ApnsManager : NSObject
+(void)divideUserIntoGroups:(UserModel *)user;
@end
