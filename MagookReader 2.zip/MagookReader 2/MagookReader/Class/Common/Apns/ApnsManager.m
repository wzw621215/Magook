//
//  ApnsManager.m
//  MagookReader
//
//  Created by zhoubin on 15/10/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "ApnsManager.h"
#import "UMessage.h"
static NSString *const USERIDALIASTYPE     = @"MAGOOK_USERID";
static NSString *const USERTYPEALIASTYPE   = @"MAGOOK_USERGROUP";
static NSString *const USERNAMEALIASTYPE   = @"USERNAME";
static NSString *const USERORGIDALIASTYPE  = @"ORGID";
static NSString *const APPVERSIONALIASTYPE = @"APPVERSION";
static NSInteger const RETOK               = 0;
@implementation ApnsManager
+(void)divideUserIntoGroups:(UserModel *)user{

    NSLog(@"userid=======%@",user.userid);
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyyMMdd"] ;
    NSString *dateStr=[formatter stringFromDate:[NSDate date]];
    NSInteger dateNum=[dateStr integerValue];

    NSDictionary *dic=[NSBundle mainBundle].infoDictionary;
    NSString *appVersion                   = dic[@"CFBundleShortVersionString"];



    [self setUserIdAlias:[NSString stringWithFormat:@"%@",user.userid]];
    [self setUserOrgIdAlias:@"magook"];
    [self setAppVersionAlias:appVersion];

    if (user==nil||user.usertoken==nil) {
        //游客
        NSLog(@"游客");
        [self setUserTypeAlias:@"GUEST"];
    }else{
        //已登录
        NSLog(@"用户已登录");
        [self setUserNameAlias:user.username];
        if ([user.iswholelib isEqualToNumber:@1]) {
            NSLog(@"全库VIP");
            if ([user.wholelibexpiredate integerValue]>=dateNum) {
                   NSLog(@"VIP在期限内");
                [self setUserTypeAlias:@"VIP"];
            }else{
                NSLog(@"VIP已过期");
                [self setUserTypeAlias:@"EXVIP"];
            }
        }else{
            NSLog(@"非全库VIP");
        }

    }
    NSLog(@"用户分组完成");

}

+(NSInteger)setUserIdAlias:(NSString *)uid {
    NSParameterAssert(uid);
    NSParameterAssert(uid.length != 0);

    [UMessage addAlias:uid
                  type:USERIDALIASTYPE
              response:^(id respobj, NSError *error) {
//                  LOGDEB(@"setUserIdAlias add alias %@ %@ %@", uid, respobj, error);
              }];
    return RETOK;
}

+(NSInteger)setUserNameAlias:(NSString *)name {
    NSParameterAssert(name);
    NSParameterAssert(name.length != 0);

    [UMessage addAlias:name
                  type:USERNAMEALIASTYPE
              response:^(id respobj, NSError *error) {
//                  LOGDEB(@"setUserNameAlias add alias %@ %@ %@", name, respobj, error);

              }];
    return RETOK;
}

+(NSInteger)setUserTypeAlias:(NSString *)utype {
    NSParameterAssert(utype);
    NSParameterAssert(utype.length);

    [UMessage addAlias:utype
                  type:USERTYPEALIASTYPE
              response:^(id respobj, NSError *error) {
//                  LOGDEB(@"setUserTypeAliase add alias %@ %@ %@", utype, respobj, error);
              }];
    return RETOK;
}

+(NSInteger)setUserOrgIdAlias:(NSString *)orgid {
    NSParameterAssert(orgid);
    NSParameterAssert(orgid.length);

    [UMessage addAlias:orgid
                  type:USERORGIDALIASTYPE
              response:^(id respobj, NSError *error) {
//                  LOGDEB(@"setUserOrgIdAlias add alias %@ %@ %@", ordid, respobj, error);
              }];
    return RETOK;
}

+(NSInteger)setAppVersionAlias:(NSString *)version {
    NSParameterAssert(version);
    NSParameterAssert(version.length);

    [UMessage addAlias:version
                  type:APPVERSIONALIASTYPE
              response:^(id respobj, NSError *error) {
//                  LOGDEB(@"setAppVersionAlias add alias %@ %@ %@", version, respobj, error);
              }];
    return RETOK;
}

@end
