//
//  ApnsModel.h
//  MagookReader
//
//  Created by zhoubin on 15/10/29.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "BasicModel.h"
typedef NS_OPTIONS(NSUInteger, ApnsType) {
    ApnsTypeText,
    ApnsTypeUpdate,
    ApnsTypeNewmagazine,
    ApnsTypeOpenurl,
    ApnsTypeOpenissue,
    ApnsTypeRacknewissue,
    ApnsTypeNewbonus

};
@interface ApnsModel : BasicModel
@property (nonatomic ,copy  ) NSString                 *massageid;
/**
 *  标题
 */
@property (nonatomic ,copy  ) NSString                 *title;
/**
 *  描述
 */
@property (nonatomic ,strong) NSString                 *desc;
/**
 *  类型
 */
@property (nonatomic ,assign) ApnsType                 type;
/**
 *  升级行为
 {
 "version":int,//app版本号
 "upgradeflag": int,//是否需要强制升级0,表示不需要,1表示需要,
 "url":"string",//安装包下载地址
 "notes": "string" //升级信息描述
 }
 */
@property (nonatomic ,strong) NSDictionary             *update;
/**
 *  新刊推送类型
 */
@property (nonatomic ,copy  ) NSDictionary             *newmagazine;
/**
 *  文本通知类型:默认为空字符串
 */
@property (nonatomic ,copy  ) NSString                 *text;
/**
 *  打开目标网址url
 */
@property (nonatomic ,copy  ) NSString                 *openurl;
/**
 *  打开特定期刊类型
 */
@property (nonatomic ,copy  ) NSDictionary             *openissue;
/**
 *  racknewissue
 */
@property (nonatomic ,copy  ) NSDictionary             *racknewissue;
/**
 *  红包激活通知
 */
@property (nonatomic ,copy  ) NSDictionary             *newbonus;
/**
 *  是否处理
 */
@property (nonatomic ,assign) BOOL                     isRead;

+(instancetype)modelWithDic:(NSDictionary *)dic;
+(NSDictionary *)dicWithModel:(ApnsModel *)model;

@end
