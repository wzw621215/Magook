//
//  AppDelegate+APNS.h
//  MagookReader
//
//  Created by zhoubin on 15/11/18.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "AppDelegate.h"
#import "UMessage.h"
#import "ApnsModel.h"
#import "UMFeedback.h"
@interface AppDelegate (APNS)
-(void)UMessage;
@end
