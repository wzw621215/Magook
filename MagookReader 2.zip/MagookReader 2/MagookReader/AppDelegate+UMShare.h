//
//  AppDelegate+UMShare.h
//  MagookReader
//
//  Created by zhoubin on 15/11/18.
//  Copyright © 2015年 Zhoubin. All rights reserved.
//

#import "AppDelegate.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialSinaSSOHandler.h"
#import "UMSocialQQHandler.h"
#import "UMSocialSinaHandler.h"
@interface AppDelegate (UMShare)
-(void)umengShare;
@end
