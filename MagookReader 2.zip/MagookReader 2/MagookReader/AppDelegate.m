//
//  AppDelegate.m
//  MagookReader
//
//  Created by user on 15/9/5.
//  Copyright (c) 2015年 Zhoubin. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "KeyChainManager.h"
#import "LoginHadle.h"
#import "MainTabBarConroller.h"
#import "SDImageCache.h"
#import "ShoppingCartHandle.h"
#import "AppDelegate+UMShare.h"
#import "AppDelegate+APNS.h"

#import "AppController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    [[AppController sharedController]checkNetWorkStatus];
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];

    //防止横屏状态下状态栏消失
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];

    //友盟推送设置
    [UMessage startWithAppkey:UMAPPKEY launchOptions:launchOptions];
    [self UMessage];
    //友盟意见反馈
    [UMFeedback setAppkey:UMAPPKEY];
    
    //初始化接口
    [self superSeverInit];

    //友盟分享设置
    [self umengShare];

    [self.window makeKeyAndVisible];

    [LogManager sendLogToServer];
//    NSLog(@"launchOptions=========%@",launchOptions);


    return YES;
}

#pragma mark -初始化接口
-(void)superSeverInit{

    if ([KeyChainManager readUserNameAndPassWord]) {

        NSDictionary *dic = [KeyChainManager readUserNameAndPassWord];
        NSString *userName = [dic objectForKey:@"com.magook.app.username"];
        NSString *passWord = [dic objectForKey:@"com.magook.app.password"];
        NSLog(@"记住的账号密码---%@---%@",userName,passWord);
        [[GlobalSettings sharedSettings]rootServerInitSuccess:^(BOOL isSuccess){
            if(isSuccess){
                BOOL loginSuccess = [LoginHadle loginWithUserName:userName passWord:passWord isVerify:NO];
                if (loginSuccess) {
                    NSLog(@"用记住账号密码登录成功");
                    MainTabBarConroller *main =[MainTabBarConroller new];
                    self.window.rootViewController=main;
                }else{
                    NSLog(@"用记住账号密码登录失败");
                    [KeyChainManager deleteUserNameAndPassword];
                    LoginViewController *log = [LoginViewController new];
                    self.window.rootViewController = log;
                }
            }else{
                NSLog(@"服务器初始化失败");
                [ZBHud showErrorWithMessage:@"服务器初始化失败"];
                LoginViewController *log = [LoginViewController new];
                self.window.rootViewController = log;
            }
        }];
    }else{
        NSLog(@"无保存的用户名密码");
        [[GlobalSettings sharedSettings]rootServerInitSuccess:^(BOOL isSuccess){
            
                LoginViewController *log = [LoginViewController new];
                self.window.rootViewController = log;
            
        }];
    }
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSLog(@"进入后台");
    [LogManager sendLogToServer];
    //如果已经登录则在进入后台时同步购物车
    if ([UserModel sharedUser].usertoken) {
        [ShoppingCartHandle sendShoppingCartDataToServer];
    }
    
    __block UIBackgroundTaskIdentifier task = [application beginBackgroundTaskWithExpirationHandler:^{
//         当申请的后台运行时间已经结束

//         结束任务
        [application endBackgroundTask:task];
    }];

}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    NSLog(@"applicationIconBadgeNumber==============%ld",application.applicationIconBadgeNumber);

}

-(void)applicationDidReceiveMemoryWarning:(UIApplication *)application{

    //内存警告的时候清理内存
    [[SDImageCache sharedImageCache]clearMemory];
    [[SDImageCache sharedImageCache] setValue:nil forKey:@"memCache"];
    
}
@end
